$(function(){	
	var rollCon=$(".content_1, .content_3, .content_4, .content_5"),
		left=$('#left'),
		right=$('#right'),
		open=$('#open'),
		fold=$('#fold'),
		fold2=document.getElementById('fold'),
		wid=window.outerWidth,
		hei=window.outerHeight;
	if (navigator.userAgent.indexOf('Chrome')>-1){left.removeClass('content_2').addClass('scroll');} 
	
	rollCon.mouseenter(function() {		        
            $(this).find(".mCSB_dragger").fadeIn();
	});
	rollCon.mouseleave(function() {		        
            $(this).find(".mCSB_dragger").fadeOut();
	});

	open.click(function(){
		fold.css('display','block');
		right.css('display','block');
		left.removeClass('max');
		leftSize();
	});
	fold.click(function(){
		$(this).css('display','none');
		right.css('display','none');
		left.addClass('max').attr('style','');
		sizeChange();
		window.resizeTo(wid-1,outerHeight);
	});
				

	$('.comment').click(function(){
		$('.right h2').removeClass('on');
		$(this).addClass('on');
		$('.content_3').css('z-index','-1');
		$('.content_1').css('z-index','9999');
		$('.choice').show();
	});
	$('#right .vod').click(function(){
		$('.right h2').removeClass('on');
		$(this).addClass('on');
		$('.content_1').css('z-index','-1');
		$('.content_3').css('z-index','9999');
		$('.choice').hide();
	});

	$('.bottom_cotent2, .bottom_cotent3').addClass('v_hidden');

	var bttom_tab=$('#bottom_tab'),
		b_tab=bttom_tab.find('a'),
		b_content=$('#bottom_cotent1, #bottom_cotent2, #bottom_cotent3'),
		live_select=$('#live_select'),
		select_box1=live_select.find('a'),
		select_box2=select_box1.next('ul');

	select_box1.click(function(){
		if(select_box2.is(':visible')){
			select_box2.css('display','none');
		}else if(!select_box2.is(':visible')){
			select_box2.css('display','block');
		};
	});	

	b_tab.each(function(i){
		$(this).click(function(){
			wid=window.outerWidth;
			hei=window.outerHeight;
			b_tab.removeClass('on');
			$(this).addClass('on');
			b_content.removeClass('v_hidden').css('display','none');
			if(i == 0){
				$('#bottom_cotent1').css('display','block');
			}else if(i == 1){
				$('#bottom_cotent2').css('display','block');
			}else if(i == 2){
				$('#bottom_cotent3').css('display','block');
			};

			window.resizeTo(wid-1,outerHeight);
		});
	});	
		
		if ($(window).width() >= 800) {
			right.height($(window).height()-200);
			leftSize();
		}

	$(window).resize(function(){
			sizeChange();
			if ($(this).width() >= 800) {
			if (!left.hasClass('max')) {leftSize();}
			$('#bottom_cotent1').css('display','block');
			$('#bottom_cotent2, #bottom_cotent3').css('display','none');
			b_tab.removeClass('on');
			$('#inter').addClass('on');
			}else{				
			left.attr('style','');
			};
	});

	$('.share').click(function(){
			$('.share_box').show();			
	});
	$('.share_close').click(function(){
		$('.share_box').hide();
	});

	$('.team_logo').click(function(){
		$('.selec').show();
	});
	$('.selec_close').click(function(){
		$('.selec').hide();
	});

	$('#btn_prog').click(function(){
		$('.live_popup').show();
	});
	$('.live_close').click(function(){
		$('.live_popup').hide();
	});
	$(window).scroll(function(){
		scollSize();
	});
	
	function scollSize(){
		var $scroll=$(window).scrollTop();
		right.height(($(window).height()-200)+$scroll);
	}
	function leftSize(){
		// left.width($(window).width()-398);
		left.height($(window).height()-175);
	}
	function sizeChange(){		
		var height=right.height(),
		chat=$('#chatContainer_right'),
		vod=$('#vodContainer_right'),
		live=$('#livereContainer_right');
			right.height($(window).height()-200);
			// left.height($(window).height()-175);
			chat.height(height-254);
			vod.height(height-110);
			live.height(height-327);
	}	
});	