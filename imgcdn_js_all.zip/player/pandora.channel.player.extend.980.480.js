					// 2012년7월 수정 박승호
					// 2012년2월 박승호
					// 유투브의 비디오 확장 기능 구현함.
					// 파이어폭스에서는 제이쿼리의 애니메이트를 사용하여 플레이어 박스를 확장시키면
					// 리셋되는 현상이 발생함.
					// 따라서 아래와 같이 setinterval을 사용하여 확장되는 스크립트를 구현하였음.

					var sh_speed =0.2;
					var sh_oval=5; //오차

					var setint_LW = null;
					var setint_LH = null;
					var setint_SW = null;
					var setint_SH = null;

					var twidth = 0;
					var theight = 0;
					var LgWidth = 980;
					var LgHeight = 480;
					var SmWidth = 640;
					var SmHeight = 390;



					function sizeChange( intFlag ){
						try {
							jQuery("#microAdDiv").hide();
							jQuery("#microAdDiv").html("");
							jQuery("#microAdDiv1").hide();
							jQuery("#microAdDiv1").html("");
						} catch(e) {}

						//intFlag : 0 ( 축소 ) , 1 ( 확대 )
						if( cookieSet.GetCookie('extSet') != intFlag && intFlag == 1 ){
							playerL();
						}else if( cookieSet.GetCookie('extSet') != intFlag && intFlag == 0 ){
							playerS();
						}
					}

					function playerL(){
						jQuery("#flvIcf").css("height", "100%");
						//탑 컨텐츠에서 아래내용으로jQuery("#watch-video").css("padding", "15px 0");
						try {
							clearInterval(setint_SH);
							clearInterval(setint_SW);
							clearInterval(setint_LH);
							clearInterval(setint_LW);
						}
						catch (e) {
						}
						cookieSet.SetCookie('extSet', '1', 60*60*3650);
						extArea();
						jQuery("#psh_top").css({"z-index":"3"});
						//탑 컨텐츠에서 필요 없음$("#divPlayer").css("margin","0 auto");
						jQuery(".content_lft").css({"margin-top":"0"});
					}

					function extArea() {
						setint_LW = setInterval(function() {  MoveBox("width", LgWidth ,setint_LW,"LL"); },10);
						setint_LH = setInterval(function() {  MoveBox("height", LgHeight ,setint_LH,"LL"); },10);
						//탑 컨텐츠에서 필요 없음$("#psh_top").addClass("width_s_bg");
						$("#sh_left").stop();
						$("#sh_left").animate({marginTop:"0px"}, 100 ); //오른쪽 영역
					}

					function playerS(){
						jQuery("#watch-video").css("padding", "0");
						try {
							clearInterval(setint_SH);
							clearInterval(setint_SW);
							clearInterval(setint_LH);
							clearInterval(setint_LW);
						}
						catch (e) {
						}
						cookieSet.SetCookie('extSet', '');
						setint_SW = setInterval(function() {  MoveBox("width", SmWidth ,setint_SW,"SS"); },10);
						setint_SH = setInterval(function() {  MoveBox("height", SmHeight ,setint_SH,"SS"); },10);
						$("#psh_top").removeClass("width_s_bg");
						$("#sh_left").stop();
						$("#sh_left").animate({marginTop:"-405px"}, 100 ); //오른쪽 영역
						jQuery(".content_lft").css({"margin-top":"0"});
						$("#watch-video").css({position: 'relative', top: '0'});

						jQuery("#psh_top").css({"z-index":"1"});
						$("#divPlayer").css("margin","0");
					}


					function MoveBox(cssName,targetVal,interName,Type){ //대상스타일속성,목적값,인터벌명
						//console.log(cssName+"   "+targetVal+"   "+interName+"   "+Type);
						//console.log("하하하하");
						var thisVal=parseInt($("#divPlayer").css(cssName));
						var thisVal1=parseInt($("#flvIcf").css(cssName));

						var Pspeed = sh_speed*(targetVal-thisVal);
						if (Math.abs(Pspeed)<0.1) {
						  thisVal = targetVal;
						 }
						var GOVal = thisVal + Pspeed;

						var Fspeed = sh_speed*(targetVal-thisVal1);
						if (Math.abs(Fspeed)<0.1) {
						  thisVal1 = targetVal;
						 }
						var GOVal1 = thisVal1 + Fspeed;

						$("#divPlayer").css(cssName, GOVal);
						$("#flvIcf").css(cssName, GOVal1);
						//	try {console.log($("#flvIcf").css(cssName)) } catch(e) {}

						if(Type == "LL"){
							//console.log("GOVal="+ GOVal +"   "+"targetVal-1= "+targetVal);
							if( GOVal == (targetVal-sh_oval) || GOVal > (targetVal-sh_oval)){//멈춤
								$("#divPlayer").css(cssName,targetVal);
								$("#flvIcf").css(cssName,targetVal);
								//alert("LL="+interName);
								clearInterval(interName);
								interName = null;
							}
						}else if(Type == "SS"){
							//console.log("GOVal="+ GOVal +"   "+"targetVal-1= "+targetVal);
							if( GOVal == targetVal+sh_oval || GOVal < targetVal+sh_oval){//멈춤
								$("#divPlayer").css(cssName,targetVal);
								$("#flvIcf").css(cssName,targetVal);
								//alert("SS="+interName);
								clearInterval(interName);
								interName = null;
							}
						}

					}