// 박승호 2012.6.7
// 왼쪽 가장 마지막 요소에 차례로 실행됨.
// 2013-03-06 smith.oh 추가 - jellycam

jQuery('.cont_rgt').ready(function() {	
	var ImgHtml_a = '<div class="section_link1 gty_pdb15 gty_line_b1"></div>';
	//var target_html= (jQuery(".cont_rgt").children().length);
	//alert( jQuery('.cont_rgt children:gt(1)').html() );
	//alert( jQuery('.cont_rgt div:gt('+target_html+'').html());
	//$("#thum_box .box_s:nth-child("+i+") a")
	//jQuery(".cont_rgt div").last().parent().after(ImgHtml_a);
	jQuery('.cont_rgt .rgt_linkgr').html(ImgHtml_a);
	var ImgHtml_b = "";
	var ImgVal = new Array();
	var dataval ="";

	ImgVal = [
	{url:"http://mobile.pandora.tv",img:"http://imgcdn.pandora.tv/ptv_img/newptv/newhome/app_ico_01.jpg",alt:"판도라TV 모바일"},
	{url:"http://www.jellypod.com/",img:"http://imgcdn.pandora.tv/ptv_img/newptv/newhome/app_ico_07.jpg",alt:"젤리팟"},
	{url:"http://everyon.pandora.tv",img:"http://imgcdn.pandora.tv/ptv_img/newptv/newhome/app_ico_04.jpg",alt:"에브리온TV"},
	{url:"http://www.kmpmedia.net/",img:"http://imgcdn.pandora.tv/ptv_img/newptv/newhome/app_ico_05.jpg",alt:"KMP"}
	];

	for (var i=0; i < 4; i++) {								
	
		dataval = ImgVal[i];
		ImgHtml_b += '<span><a href="'+dataval.url +'" target="_blank" class="btn_link"><img src="'+dataval.img +'" alt ="'+dataval.alt+'"/></a></span>';

	}
							
	jQuery(".section_link1").html(ImgHtml_b);						
});

jQuery('.section_link1').ready(function() {
	var sl_html = '<div class="section_link2">';
	sl_html += '<div class="section_wrap">';
	sl_html += '<h3>모바일 앱다운로드 바로가기</h3>';
	sl_html += '<dl>';
	sl_html += '<dt>판도라TV</dt>';
	sl_html += '<dd><a class="btn_goiph" href="http://itunes.apple.com/kr/app/id402122832" target="_blank">iPhone</a></dd>';
	sl_html += '<dd><a class="btn_goipd" href="http://itunes.apple.com/kr/app/pandoratv-for-ipad/id422504912?mt=8" target="_blank">iPad</a></dd>';
	sl_html += '<dd><a class="btn_goad" href="https://play.google.com/store/apps/details?id=com.PandoraTV" target="_blank">Android</a></dd>';
	sl_html += '</dl>';
	sl_html += '<dl>';
	sl_html += '<dt>에브리온TV</dt>';
	sl_html += '<dd><a class="btn_goiph" href="http://itunes.apple.com/kr/app/id467564273" target="_blank">iPhone</a></dd>';
	sl_html += '<dd><a class="btn_goipd" href="http://itunes.apple.com/kr/app/id494810902" target="_blank">iPad</a></dd>';
	sl_html += '<dd><a class="btn_goad" href="https://play.google.com/store/apps/details?id=com.everyontv&feature=search_result#?t=W251bGwsMSwyLDEsImNvbS5ldmVyeW9udHYiXQ" target="_blank">Android</a></dd>';
	sl_html += '<dd><a class="btn_gowd" href="https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=11&checkda=1&ct=1339056748&rver=6.1.6195.0&wp=MBI&wreply=http:%2F%2Fwww.windowsphone.com%2Fko-KR%2Fapps%2Fc1296121-d603-42d2-b75e-f28a787e9357&lc=1033&id=268289" target="_blank">Windows</a></dd>';
	sl_html += '</dl>';
	sl_html += '<dl>';
	sl_html += '<dt>젤리팟</dt>';
	sl_html += '<dd><a class="btn_goad" href="https://play.google.com/store/apps/details?id=tv.pandora.jellypod" target="_blank">Android</a></dd>';
	sl_html += '</dl>';
	sl_html += '</div>';
	sl_html += '</div>';				
	jQuery(".section_link1").after(sl_html);

});	