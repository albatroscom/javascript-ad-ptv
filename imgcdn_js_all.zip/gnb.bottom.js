/************************************************
*  Name              :  gnb.bottom.js
*  Current Version   :  0.0.0.1
*  Create by Date    :  2011-04-11
*  Create by         :  ray.kim
*  Last Update Date  :  2011-04-11
*  Last Update By    :  ray.kim
*  Description       :
*************************************************/

gnbBottom = {
	_html : '',
	_comHost : 'http://com.pandora.tv/',
	_infoHost : 'http://info.pandora.tv/',
	_apiHost : 'http://interface.pandora.tv/',
	_eventHost : 'http://event.pandora.tv/',
	_sslHost : 'https://ssl.pandora.tv/',
	_bottomLang : null,
	_menuLang : null,
	_clientLang : 'ko',
	_codeLang : '',
	_code : '',
	_menu : '',

	_setLang : function () {
		if(oCookie2.get("clientLang")) this._clientLang = oCookie2.get("clientLang");

		switch (this._clientLang) {
			case "ko" :
				this._bottomLang = ["회사소개", "광고 및 제휴", "이용약관", "<b>개인정보 취급방침</b>", "청소년 보호정책", "저작권", "도움말"];
			break;
			case "cn" :
				this._bottomLang = ["潘多拉TV介绍", "广告", "使用协议", "信息保护协议", "侵权投诉", "使用协议", "帮助", "SITE MAP"];
			break;
			case "jp" :
				this._bottomLang = ["パンドラTVの紹介", "個人情報の取扱い", "著作権侵害", "利用規約", "提携", "広告掲載", "ヘルプ"];
			break;
			default :
				this._bottomLang = ["About Us", "Privacy Policy", "Copyright Notices", "User Agreement", "Partners", "Advertise with Us", "Help"];
			break;
		}

		this._menuLang = ["한국어", "English", "日本語", "中文"];
		this._codeLang = ["ko", "en", "jp", "cn"];
	},

	setNation : function (Lang, path) {
		oCookie2.set("clientLang", Lang, 30*60*60*60);
		//location.reload();
		
		switch (Lang) {
			case "ko" :
				location.href = 'http://www.pandora.tv/';
			break;
			case "cn" :
				location.href = 'http://cn.pandora.tv/';
			break;
			case "jp" :
				location.href = 'http://jp.pandora.tv/';
			break;
			default :
				location.href = 'http://en.pandora.tv/';
			break;
		}
	},

	draw : function (target, path, mode) {
		this._setLang();

		this._bottomLink = [
			this._infoHost + '?m=pandoratv_introduce',	//회사소개
			this._infoHost + '?m=1by1&cs1=1#code1=Q08&code2=01',	//광고문이
			this._infoHost + '?m=service_use_1',		//이용약관
			this._infoHost + '?m=service_use_2',		//개인정보
			this._infoHost + '?m=service_use_4',		//청소년보호
			this._infoHost + '?m=state_right',			//권리침해
			this._infoHost + '?m=faq',				//도움말
			this._apiHost
		];

		for (var i=0; i < this._bottomLang.length; i++) {
				this._menu += '<li><a href="' + this._bottomLink[i] + '">' + this._bottomLang[i] + '</a>';
			if(i != (this._bottomLang.length - 1)) this._menu += '|';

			this._menu += '</li>\n';
		}

		var selectClass = "";
		for (var i=0; i < this._menuLang.length; i++) {
			if (this._clientLang == this._codeLang[i] )
				this._code += '<li><span>' + this._menuLang[i] + '</span>';
			else
				this._code += '<li><a href="javascript:setNation(\'' + this._codeLang[i] + '\', \'' + path + '\');">' + this._menuLang[i] + '</a>';

			if(i != (this._menuLang.length-1)) this._code += '&nbsp;|';

			this._code += '</li>\n';
		}

		this._html+= '<div class="sh_wrap_cont" id="sh_wrap_cont">';
		this._html+= '		<a class="sh_btn_top" href="javascript:sh_footer_top()">TOP</a>';
		this._html+= '		<div class="sh_logo"><a href="http://www.pandora.tv" title="홈으로"><h1 class="blind">홈으로</h1></a></div>';
		this._html+= '		<div class="sh_menu">';
		this._html+= '			<ul>';
		this._html+=				this._menu;
		this._html+= '			</ul>';
		this._html+= '		</div>';
		this._html+= '		<p>Copyright © <span>PANDORA.TV</span> All rights reserved</p>';

		if(this._clientLang == 'ko') {
			this._html+= '	<div class="sh_copy">사업자등록번호 : 220-81-57969 | 통신판매업 신고번호 : 2012-경기성남-0324 | 대표이사 : 최형우 | <a target="_blank" href="http://www.ftc.go.kr/info/bizinfo/communicationList.jsp" style="color:#959595;">사업자등록정보확인</a><br>주소 : 경기도 성남시 분당구 대왕판교로 644번길 49(삼평동,DTC타워 11층) | 대표전화 : 070-4484-7100';
			this._html+= '	</div>';
		}

		this._html+= '		<div class="sh_lang">';
		this._html+= '			<ul>';
		this._html+=				this._code;
		this._html+= '			</ul>';
		this._html+= '		</div>';
		this._html+= '		<div class="f_follow_area">';
		this._html+= '				<span class="follow_ttl02">Follow PandoraTV</span>';
		this._html+= '			<a class="follow_btn_f02" href="https://www.facebook.com/pandoratv" target="_blank" ><img src="http://imgcdn.pandora.tv/ptv_img/newptv/newhome/follow_btn_f02.jpg" alt="페이스북 가기" title="페이스북 가기"></a>';
		this._html+= '			<a class="follow_btn_t02" href="https://twitter.com/PandoratvSNS" target="_blank"><img src="http://imgcdn.pandora.tv/ptv_img/newptv/newhome/follow_btn_t02.jpg" alt="트위터 가기"  title="트위터 가기"></a>';
		this._html+= '			</div>';
		this._html+= '</div>';

		try {
			jQuery('#'+target).html(this._html);
		}
		catch (e) {}
	}
}


jQuery('.sh_footer').ready(function(){
	jQuery(".sh_wrap_cont .sh_btn_top").click(function(){
	jQuery(window).scrollTop(0);
	});
});

function sh_footer_top(){
//	document.getElementById('sh_btn_h1').tabIndex = -1;
//	document.getElementById('sh_btn_h1').focus();
//	return false;
	jQuery(window).scrollTop(0);
}

function setNation(Lang, path)
{
	oCookie2.set("clientLang", Lang, 30*60*60*60);

	switch (Lang) {
		case "ko" :
			location.href = 'http://www.pandora.tv/';
		break;
		case "cn" :
			location.href = 'http://cn.pandora.tv/';
		break;
		case "jp" :
			location.href = 'http://jp.pandora.tv/';
		break;
		default :
			location.href = 'http://en.pandora.tv/';
		break;
	}
}

function IE_Ver()
{
	if(navigator.appName.match(/Explorer/i))
	{
		return navigator.appVersion.match(/MSIE \d+.\d+/)[0].split(" ")[1];
	}
	else return 0;
}

//if (IE_Ver()>=6.0) {
	
	jQuery(document).ready(function(){
		/**
		 var uvOptions = {};
		 (function() {
			var uv = document.createElement('script'); uv.type = 'text/javascript'; uv.async = true;
			uv.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'widget.uservoice.com/pE8aEKxBxNfawdxP2oaA7g.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(uv, s);
		 })();
		 **/
	});
	
//}