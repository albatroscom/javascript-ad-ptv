var gnbJsonLink = "http://www.pandora.tv/";
var searchLink = "http://search.pandora.tv/";
var setGnbRefLot = '';

jQuery('.sh_wrap_cont').ready(function(){
	jQuery('.sh_lst_on').css('display','none');
	jQuery('.sh_lst_dsc').css('display','block');
	jQuery('.sh_btn_lston').css('display','block');
	jQuery('.sh_search_lst').css("display","none");
	jQuery('.sh_gnb_group').css("display","none");
	jQuery('.sh_wrap_cont3').css("display","none");
	jQuery(".sh_btn_topclse").toggle(
		function(){
			jQuery('.sh_top_contact').css("display","none");
		},
		function(){
			jQuery('.sh_top_contact').css("display","block");
		}
	);
});


jQuery(".sh_btn-arrow").ready(function(){
	jQuery(".sh_btn-arrow").toggle(function(){
		jQuery('.sh_h_d').css('display','block');
	},function(){
		jQuery('.sh_h_d').css('display','none');
	})
});


var autoCheckTime	= 1500;
var autoCheckCnt	= 0;
var autoCheckLimit	= 3;

function checkLogin(position){

	if ( position == undefined) {
		position = '';
	}
	if ( jQuery(".sh_wrap_cont3").css('display') == 'none' ) {
		
		if ( jQuery(".sh_header_btm").html() == "" ) {
			
			var member_info_url = gnbJsonLink+'gnb/member_info.ptv?jsoncallback=?&position='+position;
			
			var jqxhr = jQuery.getJSON(member_info_url, function(data) {
			})
			.success(function(data) { 
				jQuery(".sh_header_btm").html(data);
				jQuery(".sh_wrap_cont3").css('display', 'block');
				jQuery(".sh_header_btm").css('display', 'block');
				jQuery(".sh_gnb_btn3").addClass('active');
			 })
			.error(function() { 
				if( autoCheckCnt < autoCheckLimit ) {
					setTimeout(function() {
						checkLogin();
					}, autoCheckTime);
					autoCheckCnt++;
				}
			 });
		} else {
			jQuery(".sh_wrap_cont3").css('display', 'block');
			jQuery(".sh_gnb_btn3").addClass('active');
		}
		oCookieClass.set("pan_myinfo_view", 'V', 86400);
	} else {
		jQuery(".sh_gnb_btn3").removeClass('active');
		jQuery("#popcorn_view").css('display', 'none');
		jQuery(".sh_wrap_cont3").css('display', 'none');
		oCookieClass.set("pan_myinfo_view", 'C', 86400);
	}
	
}

function LogOutConfirm(ref){

	if (ref == undefined || !ref) ref = "";
	
	if ( confirm('오늘 하루도 판도라 TV를 이용해주셔서 감사합니다. 로그아웃 하시겠습니까?') ) {
		oCookieClass.set("pan_myinfo_view", 'V', 86400);
		document.location.href = 'http://member.pandora.tv/global_member/login.ptv?work=logout&retUrl='+encodeURIComponent(window.location.href)+ref;
	}
	
}

function closeMemberInfo(){
	jQuery('.sh_wrap_cont3').css("display","none");
}

//window.document.domain="pandora.tv";

/* 쿠키 */
oCookie2 = {
	initialize : function(){
	},

	/* set cookie value */
	set : function (sName, sValue, expireSeconds) {
		var sDomain = ".pandora.tv";
		var todayDate = new Date();
		var ExpireTime = new Date(todayDate.getTime()+expireSeconds*1000);
		document.cookie = sName + "=" + sValue + ";" + ((expireSeconds) ? "expires=" + ExpireTime.toGMTString() + ";" : "") + "domain=" + sDomain + ";path=/;";
	},

	/* get cookie value */
	get : function (sName) {
		var aCookie = document.cookie.split("; ");
		for (var i=0; i < aCookie.length; i++) {
			var aCrumb = aCookie[i].split("=");
			if (sName == aCrumb[0]) {
				return aCrumb[1];
			}
		}
		return null;
	},

	/* delete cookie */
	destroy : function (sName) {
		this.set(sName, "", 0);
	},

	/* update cookie */
	update : function (expireSeconds) {
		var CookieList = document.cookie.split("; ");
		for(var i=0;i<CookieList.length;i++) {
			var Cookies = CookieList[i].split("=");
			if(Cookies[0] == "SavedID") {
				continue;
			}
			this.set(Cookies[0], Cookies[1], expireSeconds);
		}
	}
};


var LoginAction = {
	
	_retUrl : '',

	_logchk : true,	// 로그인 여러번 호출 막기
	_logchkcnt : 0,	// 로그인 여러번 호출 막기
	_layerName : '#Layer',
	
	initialize : function(){		

	},
	
	
	Login : function () {
		var layerLabel = this._layerName;
		var closeLabel = '#layerClose';
		var loginWindow = jQuery('.mwLayer');
		var loginPop	= this.LoginForm();
		

		jQuery(layerLabel).html(loginPop);
		jQuery(layerLabel).show();

		var x = ((jQuery(window).width() - 641) / 2) + jQuery(window).scrollLeft() + 150;
		var y = ((jQuery(window).height() - 424) / 2) + jQuery(window).scrollTop() + 150;
		//alert(jQuery(window).scrollTop());
		jQuery("#mwLayer_wrap").css({"top":y+"px","left":x+"px"});

		jQuery('.item>.iLabel').css('position','absolute');

		var iText = jQuery('.item>.iLabel').next('.iText');

		if(iText.length > 1) {
			iText.each(function(i) {
				
				jQuery(this).bind('blur', function() {
					if(jQuery(this).val() == ''){
						jQuery(this).prev('.iLabel').css('visibility','visible');
					} else {
						jQuery(this).prev('.iLabel').css('visibility','hidden');
					}
				});
				
				jQuery(this).bind('change', function() {
					if(jQuery(this).val() == ''){
						jQuery(this).prev('.iLabel').css('visibility','visible');
					} else {
						jQuery(this).prev('.iLabel').css('visibility','hidden');
					}
				});
				
				jQuery(this).bind('focus', function() {
					jQuery(this).prev('.iLabel').css('visibility','hidden');
				});
				
				jQuery(this).prev('.iLabel').bind('click', function() {
					jQuery(this).css('visibility','hidden');
					jQuery('#passwd').focus();
				});
			});
		}
		
		jQuery('#uid').focus();
		
		if(oCookie2.get("c_rememberid")) {
			jQuery('#uid').val(oCookie2.get("c_rememberid"));
			jQuery('#rememberidModal').attr("checked","checked");
		}
		
		// ESC Event
		jQuery(document).keydown(function(event){
			if(event.keyCode != 27) return true;
			if (loginWindow.hasClass('open')) {
				loginWindow.removeClass('open');
			}
			return false;
		});
		
		jQuery(closeLabel).click(function() {
			jQuery(layerLabel).html("");
			jQuery(layerLabel).hide();
		});
		
		window.onresize = function(){
			var x = ((jQuery(window).width() - 641) / 2) + jQuery(window).scrollLeft() + 150;
			var y = ((jQuery(window).height() - 424) / 2) + jQuery(window).scrollTop() + 150;
			
			jQuery("#mwLayer_wrap").css({"top":y+"px","left":x+"px"});
		};
		window.onscroll = function(){
			//alert(jQuery(window).scrollTop()+' - '+jQuery(window).scrollTop());
			var x = ((jQuery(window).width() - 641) / 2) + jQuery(window).scrollLeft() + 150;
			var y = ((jQuery(window).height() - 424) / 2) + jQuery(window).scrollTop() + 150;
			//alert(jQuery(window).scrollTop());
			
			jQuery("#mwLayer_wrap").css({"top":y+"px","left":x+"px"});
		};
	},
	
	LoginForm : function () {
		
		//alert(this._ret_url);
		
		var loginHtml = '<div class="mw_bg"></div>';
		loginHtml += '	<div id="mwLayer_wrap" class="gLogin gLogin_0416" style="top: 300px; left:781.5px;">';
		loginHtml += '		<h1 class="title">로그인</h1>';
		loginHtml += '		<div class="gLogin_wrap gLogin_wrap_0416">';
		loginHtml += '				<form name="loginFrm" id="loginFrm" target="modal_login" onsubmit="javascript:return LoginAction.checkIt();" action="https://member.pandora.tv/global_member/login.v1.ptv?'+setGnbRefLot+'" method="post" class="gLogin">';
		loginHtml += '				<input type="hidden" name="work" id="work" value="ajax">';
		loginHtml += '				<input type="hidden" name="retUrl" id="retUrl" value="'+this._retUrl+'">';
		loginHtml += '				<div class="help">';
		loginHtml += '					<p>판도라TV 회원으로 가입하세요~</p>';
		loginHtml += '					<button onclick="javascript:location.href=\'http://www.pandora.tv/sign/signup.ptv\';" class="btn join" type="button">회원가입</button>';
		loginHtml += '					<iframe width="200" scrolling="no" height="200" frameborder="0" marginwidth="0" marginheight="0" topmargin="0" src="http://www.pandora.tv/adver.v1.ko.ptv?adType=LyLogin" id="mLoginAd"></iframe>							';
		loginHtml += '				</div>';
		loginHtml += '				<fieldset class="login_0416">							';
		loginHtml += '					<div style="display:none" id="displayMsg"></div>';
		loginHtml += '					<div class="login_mag">';
		loginHtml += '						<p class="df" id="login_msg1">판도라TV에 오신것을 환영합니다.<br/>로그인을 하시면 보다 다양한 서비스를 경험하실 수 있습니다.</p>';
		loginHtml += '						<p class="error" id="login_msg2" style="display:none;">아이디가 등록되어 있지 않거나, 아이디 또는 비밀번호를<br/>잘못 입력 하였습니다.</p>';
		loginHtml += '					</div>';
		loginHtml += '					<div class="item">';
		loginHtml += '						<label for="uid" class="iLabel" style="position: absolute; visibility: visible;">ID</label>';
		loginHtml += '						<input type="text" name="userid" id="uid" class="iText uid">';
		loginHtml += '					</div>';
		loginHtml += '					<div class="item">';
		loginHtml += '						<label for="upw" class="iLabel" style="position: absolute;">PASSWORD</label>';
		loginHtml += '						<input type="password" name="passwd" id="passwd" class="iText upw">';
		loginHtml += '					</div>';
		loginHtml += '					<p class="keeping">';
		loginHtml += '						<span>';
		loginHtml += '							<input type="checkbox" class="iCheck" value="y" id="autoModal" name="autoModal">';
		loginHtml += '							<label for="autoLogin">자동로그인</label>';
		loginHtml += '						</span>';
		loginHtml += '						<span>';
		loginHtml += '							<input type="checkbox" name="rememberidModal" value="y" class="iCheck" id="rememberidModal">';
		loginHtml += '							<label for="keepid">아이디 저장</label>';
		loginHtml += '						</span>';
		loginHtml += '					</p>';
		loginHtml += '					<p class="btnLogin">';
		loginHtml += '						<input type="submit" id="submit" value="로그인">';
		loginHtml += '					</p>';
		loginHtml += '					<div class="idpw_find">';
		loginHtml += '						<p class="idpw_find_box1"><span>회원 아이디를 잊으셨나요?</span><a href="http://www.pandora.tv/sign/find.ptv">아이디 찾기</a></p>';
		loginHtml += '						<p class="idpw_find_box2"><span>비밀번호를 잊으셨나요?</span><a href="http://www.pandora.tv/sign/find.ptv">비밀번호 찾기</a></p>';
		loginHtml += '					</div>';
		loginHtml += '				</fieldset>';
		loginHtml += '			</form>';
		loginHtml += '		</div>';
		loginHtml += '		<div>';
		loginHtml += '			<iframe width="1" height="1" style="display:none;" id="modal_login" name="modal_login"></iframe>';
		loginHtml += '		</div>';
		loginHtml += '		<a id="layerClose" class="close" title="로그인 레이어 닫기">&nbsp;</a>';
		loginHtml += '	</div>';
		
		return loginHtml;
	},
	
	
	checkIt : function () {
		if( this._logchk == false ){
			return false;
		}

		this._logchk = false;
		if( this._logchkcnt >= 5 ){
			alert('잠시 후 다시 시도해주세요.');
			jQuery(this._layerName).hide();
			this._logchk = true;
			this._logchkcnt = 0;
			return false;

		}
		jQuery('#login_msg1').show();
		jQuery('#login_msg2').hide();
		if (jQuery('#uid').val() == "") {
			alert('아이디를 입력해 주세요');
			jQuery('#uid').focus();
			return false;
		} else if (jQuery('#passwd').val() == "") {
			alert('비밀번호를 입력해 주세요');
			jQuery('#passwd').focus();
			return false;
		}

		
	},
		
	LoginFail : function () {
		jQuery('#login_msg1').hide();
		jQuery('#login_msg2').show();
		this._logchk = true;
		this._logchkcnt++;
		//jQuery('#displayMsg').html("<font color=red>아이디 또는 패스워드가 일치 하지 않습니다.</font>");
		//jQuery('#displayMsg').show();
	},
	
	adult : function () {
		if(confirm("로그인이 필요한 서비스 입니다.로그인을 하시겠습니까?") == true) {
			this.Login();
		}
	},
	
	close : function (act) {
		jQuery(act).html("");
		jQuery(act).hide();
	}
};


/* cookie Class */
var oCookieClass = {
	initialize : function(){
	},
	
	/* set cookie value */
	set : function (sName, sValue, expireSeconds) {
		var sDomain = ".pandora.tv";
		var todayDate = new Date();
		var ExpireTime = new Date(todayDate.getTime()+expireSeconds*1000);
		document.cookie = sName + "=" + sValue + ";" + ((expireSeconds) ? "expires=" + ExpireTime.toGMTString() + ";" : "") + "domain=" + sDomain + ";path=/;";
	},
	
	/* get cookie value */
	get : function (sName) {
		var aCookie = document.cookie.split("; ");
		for (var i=0; i<aCookie.length; i++) {
			var aCrumb = aCookie[i].split("=");
			if (sName == aCrumb[0]) {
				return aCrumb[1];
			}
		}
		return null;
	},
	
	/* delete cookie */
	destroy : function (sName) {
		this.set(sName, "", 0);
	},
	
	/* update cookie */
	update : function (expireSeconds) {
		var CookieList = document.cookie.split("; ");
		for(var i=0;i<CookieList.length;i++) {
			var Cookies = CookieList[i].split("=");
			if(Cookies[0] == "SavedID") {
				continue;
			}
			this.set(Cookies[0], Cookies[1], expireSeconds);
		}
	}
};

/* storage Class start */
var storageClass = {
	_local : null,
	_temp : [],
	_run : false,
	
	_getLocal : function(){
		return this._local;
	},
	
	appendData : function(obj){
		if (this._local == null) {
			this._local = obj;
		} else {
			jQuery.merge(this._local,obj);
		}
	},
	
	appendHash : function(key, value){
		jQuery.merge(this._local, {key:null} );
		this._local[key] = value;
		return this._local[key];
	},
	
	getChild : function(child){
		return this._getLocal()[child];
	},
	
	isKey : function(key){
		if (this._run == false) {
			this._run = true;
			var keyv = this._getLocal();
			
			if(keyv == null || keyv[key] == undefined) {
				this._run = false;
				return false;
			} else {
				this._run = false;
				return true;
			}
		}
	},
	
	size : function(){
		return this._getLocal().keys().length;
	},
	
	update : function(dest, value){
		this._local[dest] = value;
	},
	
	update2 : function(key, iterator, cond, value){
		var target = this._getLocal()[key][iterator];
		for(var i=0; i<target.length; i++){
			if(target[i]['prg_id'].toString() == cond) target[i]['ment_cnt'] = value;
		}
	},
	
	update3 : function(value) {
		var stKeys = this._getLocal().keys();
		for(var i=0;i<stKeys.length;i++) {
			if(stKeys[i].indexOf("page") > -1 && stKeys[i].indexOf("prg_id") > -1) {
				if(stKeys[i]['prgList']) {
					for(var j=0;i<stKeys[i]['prgList'].length;j++) {
						if(stKeys[i]['prgList'][j]['prg_id'] == value['prg_id']) {
							Object.extend(stKeys[i]['prgList'][j], value);
							break;
						}
					}
				}
			}
		}
	},
	
	remove : function(dest){
		this._getLocal().remove(dest);
	},
	
	clear : function(){
		this._local = null;
		this.initialize();
	}
};

var loadJsClass = {
	loadJS : function (path, charset1, id) {
		if (charset1 == undefined) {
			charset1 = "utf-8";
		}
//		try {
//			jQuery("#"+id).attr('src', path);
//		} catch (e) {
//			alert('dd');
			var oScript = document.createElement("SCRIPT");
			with(oScript) {
				setAttribute("type", "text/javascript");
				setAttribute("language", "javascript");
				setAttribute("charset", charset1);
				setAttribute("src", path);
				if(id!=undefined){
					setAttribute("id", id);
				}
			}
			document.getElementsByTagName('head')[0].appendChild(oScript);
//		}
	}
};

var inputAdver = false;
var autoKeyword = null;	/* 검색어 자동완성 요청을 할지 말지 결정*/
var autoKeywordTime = 100;	/* 검색어 자동 완성 timeout 시간*/

function setNation(nation) {
	var lang = nation;
	
	oCookieClassJP.set("clientLang", lang, 30*60*60*60);
	oCookieClassJP.set("v_listlang", lang, 86400);

	switch (lang) {
		case "ko" :
			location.href = 'http://www.pandora.tv/';
		break;
		case "cn" :
			location.href = 'http://cn.pandora.tv/';
		break;
		case "jp" :
			location.href = 'http://jp.pandora.tv/';
		break;
		default :
			location.href = 'http://en.pandora.tv/';
		break;
	}
}

function cupiInfoToggle(){
	if ( jQuery('#popcorn_view').css("display") == 'block' ) {
		jQuery('#popcorn_view').css("display","none");
	} else {
		jQuery("#popcorn_view").css('display', 'block');
	}
}

function cagegoryToggle(){
	if ( jQuery('.sh_gnb_group').css("display") == 'block' ) {
		jQuery('.sh_gnb_btn2').removeClass("active");
		jQuery('.sh_gnb_group').css("display","none");
	} else {
		jQuery('.sh_gnb_btn2').addClass("active");
		jQuery(".sh_gnb_group").css('display', 'block');
		
	}
}

var categoryBtnClick = false;
var arrowBtnClick = false;
/* 시작 */
function searchEventSet() {
	
	jQuery('.sh_gnb_btn1_new').click( function (evt) { categoryBtnClick = true; cagegoryToggle(); } );
	jQuery('.sh_gnb_btn2').click( function (evt) { categoryBtnClick = true; cagegoryToggle(); } );
	jQuery('.newmenu_icon').click( function (evt) { categoryBtnClick = true; cagegoryToggle(); } );
	
	jQuery('#AKCArrow').click( function (evt) { arrowBtnClick = true;  akcClass.arrowClick(evt); } );
	jQuery('#searchBtn').click( function(evt){ arrowBtnClick = true; searchGo(evt); } );
	jQuery('#query').click( function(evt){ 
		arrowBtnClick = true; 
	});
	jQuery('#query').focusin( function(evt){ 
		arrowBtnClick = true; 
	});
	jQuery('#query').keydown( function(evt){ searchAction(evt); } );
	jQuery('#query').keyup( function(evt){ searchAction(evt); } );
	jQuery('body').click( function(evt){ 
		if ( arrowBtnClick == false ) { 
			akcClass.akc_hide(); 
		} else { 
			arrowBtnClick = false; 
		} 
		if ( categoryBtnClick == false ) { 
			if( jQuery('.sh_gnb_group').css("display") != "none") { 
				cagegoryToggle();
			}
		} else { 
			categoryBtnClick = false; 
		} 
	});
	//jQuery('#query').blur( function(){ alert('sss'); } );
	//jQuery('#searchBtn').click( function(){ searchAction(); } );
	//jQuery('.search').blur( function(){ jQuery(".search_lst").css('display', 'none'); } );
	
}

/* 검색 광고 때문에 클래스를 하나 만듦 */
var oSearch = {
	displayAdverInput : function() {
		if (arguments[0] && arguments[1]) { /* && chInfoJson['keyword'] == "") { */
			var imgSource = arguments[0];
			searchLink = arguments[1];

			jQuery("#query").val("");
			jQuery("#query").css('background-image', "url('" + imgSource + "')");
			jQuery("#query").style.backgroundRepeat = "no-repeat";
			jQuery("#query").style.backgroundPosition = "left";

			inputAdver = true;
		}
	},
	loadAkc : function(json) {
		akcClass.loadAkc(json);
	}
};

function keywordTimeOut () {
	try { clearTimeout(autoKeyword); }
	catch (e) {}
}

var searchBtnClick = false;
function searchGo() {
	
	if (inputAdver == undefined || inputAdver == false) { /* no Adver */
		//alert('2');
		var url = searchLink+"?&query="+encodeURIComponent(jQuery('#query').val()) + "&sq="+oCookieClass.get("ipCountry")+setGnbRefLot;
		document.location.href = url;
		return;
	} else {
		//alert('3');
		document.location.href = searchLink+"?"+setGnbRefLot;
		return;
	}
	
}
/* 검색 관련 JS Start */
/* 기본 변수 셋팅 */
var searchClick = 0;
var keyaccesstype = "keydown"; /* 누르고 있을때 어떤것만 인정 할껏인가임 */

/* functions */
function searchAction(evt) {
	return;
	
	var code = "";
	
	//evt = this.event;
	
	//alert(evt.type);
	//alert(evt.id);
	try { code = evt.keyCode; } catch (e) { code = evt.charCode; }
//		var el = Event.element(evt);
//		var el = evt.element;
//		alert(el.name);
//		return;
	
	if ( (evt.type == "keydown") &&  (code == 13)) {
		searchGo();
		return;
		
	} else {
	
		if (searchClick < 1) {
			searchClick++;
		}
		inputAdver = false;
		
		/* 자동 완성 시작 */
		if ( (evt.type == "keyup" || evt.type == "keydown" || evt.type == "click" || evt.type == "keypress") ) {
//				try {
//					Event.stopObserving(document.body, "click", function(evt) {
//						var el = Event.element(evt);
//						if (el.id != "query" && el.id != "AKCArrow" && !Position.within(jQuery("#AKCResult"), Event.pointerX(evt), Event.pointerY(evt))) {
//							akcClass.akc_hide();
//						}
//					}.bind(this));
//				} catch (e) {}
//
//				Event.observe(document.body, "click", function(evt) {
//					var el = Event.element(evt);
//					if (el.id != "query" && el.id != "AKCArrow" && !Position.within(jQuery("#AKCResult"), Event.pointerX(evt), Event.pointerY(evt))) {
//						akcClass.akc_hide();
//					}
//				}.bind(this));

			var sendQuery = jQuery("#query").val();
			sendQuery = sendQuery.replace(/^ +/g, "");
			sendQuery = sendQuery.replace(/ +$/g, " ");
			sendQuery = sendQuery.replace(/ +/g, " ");

			if (evt.type == "click" || evt.type == "keydown" || evt.type == "keyup") {
				//jQuery('#query').css('background-image', "");
			}

			switch(code) {
				case 9: /* 탭 */
					if (evt.type == "keyup") {
						return;
					}

					if(sendQuery != "" && jQuery("#AKCResult").css('display') != "none") {
						jQuery('#query').css('background-image', "");
						try {
							evt.returnValue = false;
						} catch(e) {
							try {
								evt.preventDefault();
							}
							catch (e) { }
						}

						if(evt.shiftKey) {
							if (evt.type == keyaccesstype) {
								akcClass.akc_up(); /* shieft + tab 위로 올리자 */
							}
						} else {
							if (evt.type == keyaccesstype) {
								akcClass.akc_down(); /* tab 만 하면 아래로 내리자 */
							}
						}
					}

				break;

				case 13: /* 엔터*/
					/*	this.akc_hide(); // 레이어 숨기기*/
				break;

				case 38:	/* 위쪽 화살표 */
					if (evt.type == keyaccesstype) {
						jQuery('#query').css('background-image', "");
						akcClass.akc_up(); /* 위로 올리기 */
					}
				break;

				case 40:	/* 아래쪽 화살표 */
					if (evt.type == keyaccesstype) {
						jQuery('#query').css('background-image', "");
						akcClass.akc_down();
					}
				break;

				default:
					if(code == 9 || code == 16 || code == 27 || code == 37 || code == 38 || code == 40 || code == 18) {
						return;
					}
					if (sendQuery.length > 0 || code == 8) {
						//alert(sendQuery.length + ' ' + code);
						
						if (autoKeyword != null) {
							keywordTimeOut();
						}

						if (akcClass.akc_yn == null || akcClass.akc_yn == "y") {
							
							jQuery('#query').css('background-image', ""); /*akc_rmbackimg(); */
							
							akcClass.akc_pointerNum = -1;
							
							if ( storageClass.isKey("akcStorage_" + sendQuery ) ) {
								akcClass.loadAkc( storageClass.getChild("akcStorage_" + sendQuery) );
							} else {
								autoKeyword = setTimeout(function() {
									loadJsClass.loadJS("http://search.pandora.tv/akc/akc_utf.ptv?q="+encodeURIComponent(sendQuery), '', 'akc');/* + evt.type);*/
									//loadJsClass.loadJS("alert('ddddd');", '', 'akc');/* + evt.type);*/
								}, autoKeywordTime);
								
							}
						}
					} else {
						akcClass.akc_hide();
					}
				break;
			}
		}
	}
}

/* popup layer Class Start */
var gnbPopLayer = {
	eventId : null,
	
	bodyClick : function(evt) {
		var pointerX = Event.pointerX(evt);
		var pointerY = Event.pointerY(evt);
		if(jQuery(this.eventId) && !Position.within(jQuery(this.eventId), pointerX, pointerY)) {
			this.layerClose();
		}
	},
	
	eventSet : function() {
		Event.observe(document.body, "mousedown", this.bodyClick.bind(this));
	},
	
	eventErase : function() {
		Event.stopObserving(document.body, "mousedown", this.bodyClick.bind(this));
	}
};

/* 자동 완성 class Start */
var akcClass = {
	akc_orgquery : "",
	akc_yn : null,
	akc_pointerNum : -1,
	akcJson : {"QUERY":"", "LIST":""},
	loadAkc : function(json) {
		this.akc_orgquery = jQuery("#query").val();
		this.akcJson = json;
		if (this.akcJson["LIST"].length <= 0) {
			/* return; */
		}
		
		if (this.akc_yn == null || this.akc_yn == "y") {
			if (this.akcJson["LIST"].length == 0) {
				var obj = "{'akcStorage_" + this.akcJson["QUERY"] + "':" + jQuery.parseJSON(this.akcJson) + "}";
				storageClass.appendData(obj);
				this.akc_hide();
			} else {
				if( !storageClass.isKey("akcStorage_" + this.akcJson["QUERY"]) ) {
					var obj = "{'akcStorage_" + this.akcJson["QUERY"] + "':" + jQuery.parseJSON(this.akcJson) + "}";
					storageClass.appendData(obj);
				}
				this.akc_show();
			}
		}
	},
	
	akc_setCookie : function() {
		switch (oCookieClass.get("akcYN")) {
			case "n":
				oCookieClass.set("akcYN", "y", 0);
				this.akc_yn = "y";
				this.akc_show();
			break;

			default :
				oCookieClass.set("akcYN", "n", 0);
				this.akc_yn = "n";
				this.akc_hide();
			break;
		}
	},

	arrowClick : function() {
		return;
		if (jQuery(".sh_search_lst").css('display') == 'block' || jQuery(".sh_search_lst").css('display') == "") {
			//jQuery('#joinch_'+ch_id).removeClass('active');
			//jQuery('#joinch_'+ch_id).addClass('active');
			this.akc_hide();
		} else {
			//jQuery('#joinch_'+ch_id).removeClass('active');
			//jQuery('#joinch_'+ch_id).addClass('active');
			this.akc_show();
		}
	},

	akc_up : function() {
		if(this.akc_pointerNum <= 0 || this.akcJson["LIST"].length == 0) {
			jQuery("#query").val(this.akc_orgquery);
			this.akc_hide();
			this.akc_pointerNum = -1;
			return;
		}

		var choicNum = this.akc_pointerNum - 1;
		jQuery("#query").val(this.akcJson["LIST"][choicNum]["KEYWORD"]);

		this.akc_show(); /* 레이어 보여 주고 이미지 처리 */
		this.akc_curstyle(choicNum, this.akc_pointerNum);
		this.akc_pointerNum = choicNum;
	},

	akc_down : function() {
		if (this.akc_pointerNum+1 >= this.akcJson["LIST"].length || this.akcJson["LIST"].length == 0) {
			return;
		}

		var choicNum = this.akc_pointerNum + 1;
		jQuery("#query").val(this.akcJson["LIST"][choicNum]["KEYWORD"]);

		this.akc_show(); /* 레이어 보여 주고 이미지 처리 */
		this.akc_curstyle(choicNum, this.akc_pointerNum);
		this.akc_pointerNum = choicNum;
	},

	akc_hide : function() {
		return;
		try {
			if(jQuery(".sh_search_lst").css('display') == 'block') {
				jQuery(".sh_search_lst").css('display', 'none');
			}
		} catch (e) {
		}
		this.akc_chgbtn(0);

		/* 카테고리 언어 셀렉트 박스 none으로 변경 */
		try {
			jQuery("#contentsLang").css('display', 'block');
		} catch (e) { }
	},

	akc_show : function() {
		return;
		if (this.akc_yn == "n") {
			
			jQuery("#akcUse").html("자동완성 기능켜기");
			jQuery(".sh_lst_dsc").html("검색어 자동완성 기능을 사용해 보세요.<br>검색어 입력이 보다 편리해 집니다.");
			jQuery("#AKCIDiv").html("");
			
		} else if ( jQuery("query").value == "" ) { 
			
			jQuery("#akcUse").html("자동완성 기능끄기");
			jQuery(".sh_lst_dsc").html("");
			jQuery("#AKCIDiv").html("");
			
		} else if ( this.akcJson["LIST"].length == 0 ) { 
			
			jQuery("#akcUse").html("자동완성 기능끄기");
			jQuery(".sh_lst_dsc").html("");
			jQuery("#AKCIDiv").html("");
			
		} else {
			jQuery("#akcUse").html("자동완성 기능끄기");
			jQuery(".sh_lst_dsc").html("");
			
			try {
				jQuery("#akcUL").height("0px");;
			} catch (e) { }

			var akcText = "";
			var akcHtml = "<ul id=\"akcUL\">";
			for (var i = 0; i < this.akcJson["LIST"].length; i++) {
				akcText = this.akcJson["LIST"][i]["KEYWORD"].replace(this.akcJson["QUERY"], "<span>" + this.akcJson["QUERY"] + "</span>");

				akcHtml += "<li id='akcKwd_"+i+"'><a href=\""+searchLink+"?&query=" + encodeURIComponent(this.akcJson["LIST"][i]["KEYWORD"]) + setGnbRefLot + "\">" + akcText + "</a></li>";
			}
			akcHtml += "</ul>";
		
			if (akcHtml) {
				jQuery("#AKCIDiv").html(akcHtml);
				if (akcJson["LIST"].length > 5) {
					jQuery("#akcUL").height("120px");
				}
			} else {
				jQuery("#AKCIDiv").html(akcUse.toString());/* = akcHtml; */
			}
			this.akc_chgbtn(1);
		}

		if(jQuery("#AKCResult").css('display') == 'none') {
			jQuery("#AKCResult").css('display', 'block');
		}

		if(jQuery(".sh_search_lst").css('display') == 'none') {
			jQuery(".sh_search_lst").css('display', 'block');
		}

		/* 카테고리 언어 셀렉트 박스 none으로 변경 */
		try {
			jQuery("#contentsLang").css('display', 'none');;
		} catch (e) { }
		this.akc_chgbtn(1);
	},

	akc_chgbtn : function(bool) {
		if(bool) {
			/*jQuery("AKCArrow").className = "redrop";*/
			jQuery("#AKCArrow").addClass("active");
		} else {
			/*jQuery("AKCArrow").className = "drop";*/
			jQuery("#AKCArrow").removeClass("active");
		}
	},

	akc_curstyle : function(pos, oldpos) {
		try {
			jQuery("#akcKwd_"+oldpos).css('background-color', "#FFFFFF");
		} catch(e) { }
		jQuery("#akcKwd_"+pos+" a").css('background-color', "#F5F5F5");
		jQuery("#a_"+pos).focus();
		jQuery("#query").focus();
	}
};

function setJoinCh( ch_id ) {
	
	//alert('sss');
	var mode = jQuery('#joinch_'+ch_id).attr('join_mode');
	//alert(mode);
	var member_info_url = gnbJsonLink+'gnb/member_info.ptv?jsoncallback=?&join_ch_mode='+mode+'&ch_id='+ch_id;
	
	var jqxhr = jQuery.getJSON(member_info_url, function(data) {
	})
	.success(function(data) { 
		
		if( mode == 'F' ) {
			jQuery('#joinch_'+ch_id).attr('join_mode', 'T');
			jQuery('#joinch_'+ch_id).removeClass('active');
		} else {
			jQuery('#joinch_'+ch_id).attr('join_mode', 'F');
			jQuery('#joinch_'+ch_id).addClass('active');
		}
		//alert(ch_id);
		
		//alert(data);
		//jQuery(".header_btm").html(data);
		//jQuery(".header_btm").css('display', 'block');
	 })
	.error(function() { 
		if( autoCheckCnt < autoCheckLimit ) {
			setTimeout(function() {
				setJoinCh();
			}, autoCheckTime);
			autoCheckCnt++;
		}
	 });
	
}

var autoGNBTime		= 1500;
var autoGNBCnt		= 0;
var autoGNBLimit	= 3;

function getNewGNB(position ,query){
	var cate_position = '';
	if (arguments[2]) {
		cate_position = arguments[2];
	}
	if ( position == undefined) {
		position = 'all';
	}
	if ( query == undefined) {
		var gnb_url = gnbJsonLink+"gnb/gnb_etc.ptv?jsoncallback=?&position="+position+"&cate_position="+cate_position;
	} else {
		var gnb_url = gnbJsonLink+"gnb/gnb_etc.ptv?jsoncallback=?&query="+query+"&cate_position="+cate_position+"&position="+position;
	}
	
	var gnbSet = jQuery.getJSON(gnb_url, function(data) {
	})
	.success(function(data) { 
		//alert(data);
		jQuery("#sh_header").html(data);
		jQuery("#sh_header").show();
	 })
	.error(function() { 
		if( autoGNBCnt < autoGNBLimit ) {
			setTimeout(function() {
				getNewGNB();
			}, autoGNBTime);
			autoGNBCnt++;
		}
	 });
}

function popLayerClose(setName, setDate){
	setDateCnt = 60*60*24*parseInt(setDate, 10);
	document.getElementById(setName).style.display="none";
	oCookieClass.set(setName, "1", setDateCnt);
}
function popLayerStart(setName){
	document.getElementById(setName).style.display="block";
}
function popCookieGet(setName){
	var aCookie = document.cookie.split("; ");
	for (var i=0; i<aCookie.length; i++) {
		var aCrumb = aCookie[i].split("=");
		if (setName == aCrumb[0]) {
			return aCrumb[1];
		}
	}
}

var TopContentsType = '';
var TopContentsId1 = '';
var TopContentsId2 = '';

function playTopContentsObj (type, id1, id2, section) {
	
	TopContentsType = type;
	TopContentsId1 = id1;
	TopContentsId2 = id2;
	var _playObj = "";
	
	var Url			= "";
	if(TopContentsType == "L"){ //라이브 
		//Url = "http://imgcdn.pandora.tv/gplayer/live/pandora_LiveTplayer.swf?liveid="+id1+"&skin=1&countryChk=ko&autoplay=true&share=";
		Url = "http://imgcdn.pandora.tv/gplayer/newPlayer_2012/tvboxLive.swf?liveid="+TopContentsId1+"&section="+section;
	} else {
		//Url = "http://imgcdn.pandora.tv/gplayer/pandora_EGplayer.swf?userid="+id1+"&prgid="+id2+"&skin=1&countryChk=ko&autoPlay=true&share=";
		//Url = "http://imgcdn.pandora.tv/gplayer/newPlayer_2012/mainplayer.swf?userid="+TopContentsId1+"&prgid="+TopContentsId2+"";
		Url = "http://imgcdn.pandora.tv/gplayer/newPlayer_2012/pandora_TopPlayer.swf?userid="+TopContentsId1+"&prgid="+TopContentsId2+"&section="+section;
		
	}
	
	//_playObj = '<div class="tvboxmov_btn2" style="background-image:url(\''+bgUrl+'\');">';
	var _wmode = "transparent";
	
	if(jQuery.browser.msie) {
		
		_playObj += '<object id="topContentsObj" style="visibility:visible" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,2,0,0" width="382px" height="214px" align="middle" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" >';
		_playObj += '<param name="movie" value="'+Url+'" />';
		_playObj += '<param name="quality" value="high" />';
		_playObj += '<param name="play" value="true" />';
		_playObj += '<param name="loop" value="true" />';
		_playObj += '<param name="scale" value="noScale" />';
		_playObj += '<param name="wmode" value="'+_wmode+'" />';
		_playObj += '<param name="devicefont" value="false" />';
		_playObj += '<param name="bgcolor" value="#FFFFFF" />';
		_playObj += '<param name="menu" value="true" />';
		_playObj += '<param name="allowFullScreen" value="true" />';
		_playObj += '<param name="allowScriptAccess" value="always" />';
		_playObj += '<param name="salign" value="T" />';
		_playObj += '</object>';
		
	} else {
		
		_playObj += '<embed name="topContentsObj" id="topContentsObj" style="visibility:visible" pluginspage="http://www.macromedia.com/go/getflashplayer" width="382px" height="214px" align="middle"';
		_playObj += 'src="'+Url+'"';
		_playObj += 'quality="high"';
		_playObj += 'play="true"';
		_playObj += 'loop="true"';
		_playObj += 'scale="noScale"';
		_playObj += 'wmode="'+_wmode+'"';
		_playObj += 'devicefont="false"';
		_playObj += 'bgcolor="#FFFFFF"';
		_playObj += 'menu="true"';
		_playObj += 'allowFullScreen="true"';
		_playObj += 'allowScriptAccess="always"';
		_playObj += 'salign="T" type="application/x-shockwave-flash">';
		_playObj += '</embed>';
		
	}
	
	//TopContentsPlayObj = _playObj;
	
	return _playObj;
}

function palyTopContents(type, id1, id2, section){
	
	var _playObj = playTopContentsObj(type, id1, id2, section);
	
	jQuery('#top_contect_video').html(_playObj);
	
}

function setTopContentsLinkUrl(){
	
	var LinkUrl = jQuery('#top_contect_video').attr('link_url');
	if( LinkUrl ) {
		location.href = LinkUrl;
	}
}

var vTopObj = null;
function smartPlayTopContentsObj (os, Source, bgUrl, log_url, lot) {
	
	var _playObj = "";
	
	if (os == 'ios') {
		_playObj += '	<div style="position:absolute;width:380px;height:214px;" class="video-content loading" id="divPlayer" rrr="">';
		_playObj += '		<video id=\'topContents\' autobuffer preload="auto" style="width:380px; height:214px;" controls="controls" poster="'+bgUrl+'">';
		_playObj += '			<source src="' + Source + '" type="video/mp4">';
		_playObj += '		</video>';
		_playObj += '	</div>';
	} else { 
		_playObj += '	<div style="position:absolute;width:380px; height:214px; z-index:100;top:0px;left:0px;padding:0;marging:0;" class="video-content loading" id="divPlayer" attt="">';
		_playObj += '		<video id=\'topContents\' autoplay="autoplay" autobuffer preload="auto" style="width:0%; height:0%;" controls="controls">';
		_playObj += '			<source src="' + Source + '">';
		_playObj += '		</video>';
		_playObj += '		<img src="'+bgUrl+'" style="position:absolute;left:0px;top:0;width:380px; height:214px;display:block;" id="playThumb">';
		_playObj += '	</div>';
		_playObj += '	<div id="play" style="height: 170px; width: 170px; position: absolute; margin-top: 10px; margin-left: 65px;z-index:101" >';
		
		if( lot == 'T' ) {
			_playObj += '		<a href="javascript:TopContentsAction(\'play\', \''+log_url+'\',\'' + Source + '\')" onfocus="this.blur()"><img src="http://imgcdn.pandora.tv/ptv_img/ch/ch2010/playerBTN.png" /></a>';
		} else {
			_playObj += '		<a href="javascript:TopContentsAction(\'play\', \''+log_url+'\')" onfocus="this.blur()"><img src="http://imgcdn.pandora.tv/ptv_img/ch/ch2010/playerBTN.png" /></a>';
		}
		_playObj += '	</div>';
	} 
	//alert(_playObj);
//							$("playerDiv").innerHTML = html;
//							
	return _playObj;
	
}

var topPlayOK = false;
var topReCnt = 0;
var topLogOk = false;
var topEndLogOk = false;

function top_contents_set_log(os, log_url) {
	
//					== 미디어 요소의 이벤트 처리(데이터 로딩 시)
//					emptied : 이전의 데이터 비움
//					loadstart : 데이터 로딩 시작
//					progress : 데이터 로딩 중(간헐적으로 발생)
//					loadedmetadata : 미디어의 메타데이터를 읽음
//					loadeddata : 데이터 로딩 완료
//					canplay : 재생을 시작할 수 있음
//					canplaythrough : 다운로드가 유지된다면 마지막 까지 재생할 수 있는 시점에 발생
//					load : 데이터 다운로드 완료
//					stalled : 데이터 다운로드가 느려짐
//					suspend : 데이터 다운로드가 중지됨(에러 아님)
//					abort : 데이터 다운로드가 중지됨(에러 발생)
//					error : 에러 발생
//					loadend : 데이터 로딩 완료(load, abort, error 뒤에 발생)
//					
//					== 미디어 요소의 이벤트 처리(미디어 재생 시)
//					play : 재생 시작 알림
//					playing : 재생이 시작됨
//					pause : 재생 일시 정지
//					timeupdate : 재생 중(여러 번 발생)
//					waiting : 다음 프레임의 다운로드 대기 중
//					ended : 재생 종료

	try {
		// android iphone
		vTopObj.addEventListener('play', function() {
			if (os == "ios" && topLogOk == false) { // 아이폰, 패드, 팟 
//				alert("event os :: "+os+" , "+ log_url+"&mode=pd");
				document.getElementById('top_contents_log').src = log_url+"&mode=pd";
				topLogOk = true;
			}
		});
		
		// android iphone
		vTopObj.addEventListener('ended', function() {
			//alert('video play end');
			if (topEndLogOk == false) {
				//document.getElementById('log').src = log_url+"&mode=se";;
				topEndLogOk = true;
			}
		});
		
		// iphone
		vTopObj.addEventListener('suspend', function() {
			topPlayOK = true;
			//alert('iphone video progress ');
		});
		
		// android iphone
		vTopObj.addEventListener('progress', function() {
			topPlayOK = true;
			//alert('android video progress ');
		});
		
		// iphone
		vTopObj.addEventListener('loadstart', function() {
			//alert('android loadstart ok');
			topPlayOK = true;
		});
		
		// android iphone
		vTopObj.addEventListener('stalled', function() {
			topPlayOK = true;
			//alert('android video stalled  ');
		});
		
		// android iphone
		vTopObj.addEventListener('loadedmetadata', function() {
			//alert('video loadedmetadata ');
		});
		
		// android iphone
		vTopObj.addEventListener('loadeddata', function() {
			//alert('video loadeddata');
		});

		// android iphone
		vTopObj.addEventListener('playing', function() {
			//alert('video playing ');
		});

		// android iphone
		vTopObj.addEventListener('canplay', function() {
			//alert('video canplay ');
		});
		
		// iphone
		vTopObj.addEventListener('seeking', function() {
			//alert('video seeking  ');
		});
		
		// iphone
		vTopObj.addEventListener('seeked', function() {
			//alert('video seeked  ');
		});
		
		//
		vTopObj.addEventListener('dureationchange', function() {
			alert('video dureationchange  ');
		});
		
		//
		vTopObj.addEventListener('abort', function() {
			//alert('video abort  ');
		});

		// android iphone
		vTopObj.addEventListener('waiting', function() {
			//alert('video waiting');
		});
	} catch(e) {
		
	}
}

function TopContentsAction(act, log_url) {
	
	//alert(act+" |||| "+log_url);
	
	if (arguments[2]) {
		
		if (topLogOk == false) {
//			alert(" argument :: "+log_url+"&mode=pd");
			document.getElementById('top_contents_log').src = log_url+"&mode=pd";
			topLogOk = true;
		}
		location.href = arguments[2];
		
		return;
		
	} else {
		
		if (topPlayOK == false) {
			
			if (topReCnt < 400) {
				
				topReCnt++;
				setTimeout(function () {
					TopContentsAction(act, log_url);
				}, 10);
				
			} else {
				
				if (topLogOk == false) {
//					alert("play ok :: "+log_url+"&mode=se");
					document.getElementById('top_contents_log').src = log_url+"&mode=se";
					topLogOk = true;
				}
				
			}
			
			return;
			
		}
		
		switch (act) {
			case "play" :
				if (topLogOk == false) {
//						alert("play act :: "+log_url+"&mode=pd");
					document.getElementById('top_contents_log').src = log_url+"&mode=pd";
					topLogOk = true;
				}
				vTopObj.play();
			break;
			case "pause" :
				vTopObj.pause();
			break;
			case "stop" :
				vTopObj.stop();
			break;
		}
	}
}

function smartPalyTopContents(os, Source, bgUrl, log_url, lot){
	
	var _playObj = smartPlayTopContentsObj(os, Source, bgUrl, log_url, lot);
	
	jQuery('#top_contect_video').html(_playObj);
	
	setTimeout(function() {
		vTopObj = document.getElementById('topContents');
	}, 100);
	
	setTimeout(function() {
		top_contents_set_log(os, log_url);
	}, 100);
	
}

var logFlag = "y";
function topContentsLog(service, type, prgid) {
	if( logFlag == 'y' ) {
		//로그
		var path = "http://log.sv.pandora.tv/toppv?service=" + service + "&type=" + type + "&prgid=" + prgid;		
		loadJsClass.loadJS(path, 'utf-8', '');
		logFlag = 'n';
		
	}	
}

function getMainTopContents(position, view_type, cate_position){
	
	var top_contents_url = gnbJsonLink+"gnb/top_contents.ptv?jsoncallback=?&position="+position+"&view_type="+view_type+"&cate_position="+cate_position;
	
	var jqxhr = jQuery.getJSON(top_contents_url, function(data) {
	})
	.success(function(data) { 
		if( view_type == 'C' ) {
			jQuery("#topContentAreaNew").html('');
			jQuery("#topContentAreaNew").css('display', 'none');
		} else if( data && view_type == 'D') {
			jQuery("#topContentAreaNew").html(data);
			jQuery("#topContentAreaNew").css('display', 'block');
		} else if( data && view_type == 'O') {
			jQuery("#topContentAreaNew").html(data);
			jQuery("#topContentAreaNew").css('display', 'block');
		} else {
			if( data ) {
				jQuery("#topContentAreaNew").html(data);
				jQuery("#topContentAreaNew").css('display', 'block');
			} else {
				jQuery("#topContentAreaNew").html('');
				jQuery("#topContentAreaNew").css('display', 'none');
			}
		}
	})
	.error(function() { 
		if( autoCheckCnt < autoCheckLimit ) {
			setTimeout(function() {
				getMainTopContents(position, view_type, cate_position);
			}, autoCheckTime);
			autoCheckCnt++;
		}
	});
}

function getIssueJson(position) {
	
	if ( position == undefined) {
		position = '';
	}
	var issue_url = gnbJsonLink+'gnb/issue.ptv?jsoncallback=?&position='+position;
	
	jQuery.getJSON(issue_url, function(data) {
	})
	.success(function(data) { 
		lineNews.item = eval(data);
		lineNews.initialize();
	 })
	.error(function() { 
		lineNews.item = [];
	 });
	
}

var lineNews = {
	
	item : null,
	interval : null,
	rollSec : 3000,
	resetSec : 2,
	itemCnt : 0,
	setLinkRef : '',
	
	initialize : function() {
		if (  this.item != null && this.item.length > 0 ) {
			//alert(lineNews.item.length);
			this.formaction();
			this.rollingstart();
		}
	}, 
	
	formaction : function() {
		//alert(lineNews.itemCnt);
		data = this.item[this.itemCnt];
		var cate_type		= data.cate_type;
		var cate_name		= data.cate_name;
		var cate_img		= data.cate_img;
		var vod_id1			= data.vod_id1;
		var vod_id2			= data.vod_id2;
		var nickname		= data.nickname;
		var title			= data.title;
		var link_url		= data.link_url;
		var view_option1	= data.view_option1;
		var view_option2	= data.view_option2;
		
		var style_tag1 = "";
		var style_tag2 = "";
		var cate_name_tag = "";
		
		if( cate_type == 'I' ) { 
			
			cate_name_tag = "<img src='"+cate_img+"' border='0'>";
			
		} else {
			
			if ( view_option1 == 'red') {
				style_tag1 = "style='color:#F72B2C;font-weight:normal'";
			} else if ( view_option1 == 'blue') {
				style_tag1 = "style='color:#1A4CCB;font-weight:normal'";
			} else if ( view_option1 == 'bold') {
				style_tag1 = "style='color:#000000;font-weight:bold'";
			} else {
				style_tag1 = "style='color:#000000;font-weight:normal'";
			}
			
			if ( view_option2 == 'red') {
				style_tag2 = "style='color:#F72B2C;font-weight:normal'";
			} else if ( view_option2 == 'blue') {
				style_tag2 = "style='color:#1A4CCB;font-weight:normal'";
			} else if ( view_option2 == 'bold') {
				style_tag2 = "style='color:#000000;font-weight:bold'";
			} else {
				style_tag2 = "style='color:#000000;font-weight:normal'";
			}
			cate_name_tag = "["+cate_name+"]";
		}
		
		var line_news = "<li><a href=\""+link_url+"\" target=\"_blank\" class = \"sh_linenews_a\"><span "+style_tag1+">"+cate_name_tag+"</span> <span "+style_tag2+">"+title+"</span></a>";
		if( vod_id1 != '' ) {
			line_news += " <a href=\"http://channel.pandora.tv/channel/video.ptv?ch_userid="+vod_id1+"&prgid="+vod_id2+""+setGnbRefLot+"\" class = \"sh_linenews_b\" target=\"_blank\">("+nickname+" 님의 채널)</a>";
		}
		line_news += "</li>";
		//var line_news = "<li>dddd</li>";
		//alert(line_news);
		jQuery("#issue_area").html(line_news);
		//this.itemCnt++;
		
	},
	
	rollingstart : function() {
		this.interval = setInterval(
			function () {
				if (lineNews.itemCnt >= lineNews.item.length-1) {
					//clearInterval(this.interval);
					lineNews.itemCnt = 0;
					lineNews.formaction();
				} else {
					lineNews.itemCnt++;
					lineNews.formaction();
				}
			},
		lineNews.rollSec);
	}
	
};

