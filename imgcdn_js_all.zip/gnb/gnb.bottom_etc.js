/************************************************
*  Name              :  gnb.bottom.js
*  Current Version   :  0.0.0.1
*  Create by Date    :  2011-04-11
*  Create by         :  ray.kim
*  Last Update Date  :  2011-04-11
*  Last Update By    :  ray.kim
*  Description       :
*************************************************/

gnbBottom = {
	_html : '',
	_comHost : 'http://com.pandora.tv/',
	_infoHost : 'http://info.pandora.tv/',
	_apiHost : 'http://interface.pandora.tv/',
	_eventHost : 'http://event.pandora.tv/',
	_sslHost : 'https://ssl.pandora.tv/',
	_bottomLang : null,
	_menuLang : null,
	_clientLang : 'ko',
	_codeLang : '',
	_code : '',
	_menu : '',

	_setLang : function () {
		if(oCookie2.get("clientLang")) this._clientLang = oCookie2.get("clientLang");

		switch (this._clientLang) {
			case "ko" :
				this._bottomLang = ["ȸ��Ұ�", "���� �� ����", "�̿���", "<b>�������� ��޹�ħ</b>", "û�ҳ� ��ȣ��å", "���۱�", "����"];
			break;
			case "cn" :
				this._bottomLang = ["������TV˿?", "?ͱ", "����??", "������???", "��?��?", "����??", "?�", "SITE MAP"];
			break;
			case "jp" :
				this._bottomLang = ["�ѫ�ɫ�TV����˿", "������������Ю�", "?������?��", "����Ю�", "���", "?ͱ?�", "�ث��"];
			break;
			default :
				this._bottomLang = ["About Us", "Privacy Policy", "Copyright Notices", "User Agreement", "Partners", "Advertise with Us", "Help"];
			break;
		}

		this._menuLang = ["�ѱ���", "English", "������", "����"];
		this._codeLang = ["ko", "en", "jp", "cn"];
	},

	setNation : function (Lang, path) {
		oCookie2.set("clientLang", Lang, 30*60*60*60);
		//location.reload();
		location.href = 'http://www.pandora.tv/';
	},

	draw : function (target, path, mode) {
		this._setLang();

		this._bottomLink = [
			this._infoHost + '?m=pandoratv_introduce',	//ȸ��Ұ�
			this._infoHost + '?m=1by1&cs1=1#code1=Q08&code2=01',	//��������
			this._infoHost + '?m=service_use_1',		//�̿���
			this._infoHost + '?m=service_use_2',		//��������
			this._infoHost + '?m=service_use_4',		//û�ҳ⺸ȣ
			this._sslHost + '/info/?m=state_right',			//�Ǹ�ħ��
			this._infoHost + '?m=faq',				//����
			this._apiHost
		];


		for (var i=0; i < this._bottomLang.length; i++) {
				this._menu += '<li><a href="' + this._bottomLink[i] + '">' + this._bottomLang[i] + '</a>';
			if(i != (this._bottomLang.length - 1)) this._menu += '|';

			this._menu += '</li>\n';
		}

		var selectClass = "";
		for (var i=0; i < this._menuLang.length; i++) {
			if (this._clientLang == this._codeLang[i] )
				this._code += '<li><span>' + this._menuLang[i] + '</span>';
			else
				this._code += '<li><a onclick="gnbBottom.setNation(\'' + this._codeLang[i] + '\', \'' + path + '\');">' + this._menuLang[i] + '</a>';

			if(i != (this._menuLang.length-1)) this._code += '&nbsp;|';

			this._code += '</li>\n';
		}

		this._html+= '<div class="sh_wrap_cont">';
		this._html+= '		<a class="sh_btn_top" >TOP</a>';
		this._html+= '		<div class="sh_logo"><a href="http://www.pandora.tv"></a></div>';
		this._html+= '		<div class="sh_menu">';
		this._html+= '			<ul>';
		this._html+=				this._menu;
		this._html+= '			</ul>';
		this._html+= '		</div>';
		this._html+= '		<p>Copyright �� <span>PANDORA.TV</span> All rights reserved</p>';
		this._html+= '		<div class="sh_lang">';
		this._html+= '			<ul>';
		this._html+=				this._code;
		this._html+= '			</ul>';
		this._html+= '		</div>';
		this._html+= '</div>';

		try {
			jQuery('#'+target).html(this._html);
		}
		catch (e) {}
	}
}


jQuery('.sh_footer').ready(function(){
	jQuery(".sh_wrap_cont .sh_btn_top").click(function(){
	jQuery(window).scrollTop(0);
	});
});

function IE_Ver()
{
	if(navigator.appName.match(/Explorer/i))
	{
		return navigator.appVersion.match(/MSIE \d+.\d+/)[0].split(" ")[1];
	}
	else return 0;
}

//if (IE_Ver()>=6.0) {
	
	jQuery(document).ready(function(){
		/**
		 var uvOptions = {};
		 (function() {
			var uv = document.createElement('script'); uv.type = 'text/javascript'; uv.async = true;
			uv.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'widget.uservoice.com/pE8aEKxBxNfawdxP2oaA7g.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(uv, s);
		 })();
		 **/
	});
	
//}