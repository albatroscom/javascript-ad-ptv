var gnbJsonLink = "http://jp.pandora.tv/";
var searchLink = "http://jp.search.pandora.tv/";
var setGnbRefLot = '';
/*
jQuery('.sh_wrap_cont2').ready(function(){
	jQuery('.sh_lst_on').css('display','none');
	jQuery('.sh_lst_dsc').css('display','block');
	jQuery('.sh_btn_lston').css('display','block');
	jQuery('.sh_search_lst').css("display","none");
	jQuery('.sh_gnb_group').css("display","none");
	jQuery('.sh_wrap_cont3').css("display","none");
	jQuery(".sh_btn_topclse").toggle(
		function(){
			jQuery('.sh_top_contact').css("display","none");
		},
		function(){
			jQuery('.sh_top_contact').css("display","block");
		}
	);
});


jQuery(".sh_btn-arrow").ready(function(){
	jQuery(".sh_btn-arrow").toggle(function(){
		jQuery('.sh_h_d').css('display','block');
	},function(){
		jQuery('.sh_h_d').css('display','none');
	})
});
*/

var autoCheckTime	= 1500;
var autoCheckCnt	= 0;
var autoCheckLimit	= 3;

function checkLogin(position){
	
	if ( position == undefined) {
		position = '';
	}
	if ( jQuery(".sh_wrap_cont3").css('display') == 'none' ) {
		
		if ( jQuery(".sh_header_btm").html() == "" ) {
			
			var member_info_url = gnbJsonLink+'gnb/member_info.ptv?jsoncallback=?&position='+position;
			
			var jqxhr = jQuery.getJSON(member_info_url, function(data) {
			})
			.success(function(data) { 
				jQuery(".sh_header_btm").html(data);
				jQuery(".sh_wrap_cont3").css('display', 'block');
				jQuery(".sh_header_btm").css('display', 'block');
				jQuery(".sh_gnb_btn3").addClass('active');
			 })
			.error(function() { 
				if( autoCheckCnt < autoCheckLimit ) {
					setTimeout(function() {
						checkLogin();
					}, autoCheckTime);
					autoCheckCnt++;
				}
			 });
		} else {
			jQuery(".sh_wrap_cont3").css('display', 'block');
			jQuery(".sh_gnb_btn3").addClass('active');
		}
		oCookieClassJP.set("pan_myinfo_view", 'V', 86400);
	} else {
		jQuery(".sh_gnb_btn3").removeClass('active');
		jQuery("#popcorn_view").css('display', 'none');
		jQuery(".sh_wrap_cont3").css('display', 'none');
		oCookieClassJP.set("pan_myinfo_view", 'C', 86400);
	}
	
}

function LogInConfirm(){
	
	document.location.href = 'http://www.pandora.tv/sign/agree.ptv?retUrl='+encodeURIComponent(window.location.href);
	
}
function LogOutConfirm(ref){
	
	if (ref == undefined || !ref) ref = "";
	
	document.location.href = 'https://ssl.pandora.tv/global_member/login.ptv?work=logout&retUrl='+encodeURIComponent(window.location.href)+ref;
	
}

function closeMemberInfo(){
	jQuery('.sh_wrap_cont3').css("display","none");
}

window.document.domain="pandora.tv";

/* 쿠키 */
oCookie2 = {
	initialize : function(){
	},

	/* set cookie value */
	set : function (sName, sValue, expireSeconds) {
		var sDomain = ".pandora.tv";
		var todayDate = new Date();
		var ExpireTime = new Date(todayDate.getTime()+expireSeconds*1000);
		document.cookie = sName + "=" + sValue + ";" + ((expireSeconds) ? "expires=" + ExpireTime.toGMTString() + ";" : "") + "domain=" + sDomain + ";path=/;";
	},

	/* get cookie value */
	get : function (sName) {
		var aCookie = document.cookie.split("; ");
		for (var i=0; i < aCookie.length; i++) {
			var aCrumb = aCookie[i].split("=");
			if (sName == aCrumb[0]) {
				return aCrumb[1];
			}
		}
		return null;
	},

	/* delete cookie */
	destroy : function (sName) {
		this.set(sName, "", 0);
	},

	/* update cookie */
	update : function (expireSeconds) {
		var CookieList = document.cookie.split("; ");
		for(var i=0;i<CookieList.length;i++) {
			var Cookies = CookieList[i].split("=");
			if(Cookies[0] == "SavedID") {
				continue;
			}
			this.set(Cookies[0], Cookies[1], expireSeconds);
		}
	}
};


var LoginAction = {
	
	_retUrl : null,
	_logingPageType : null,
	
	initialize : function(){
	},
	
	
	Login : function () {
		var layerLabel = '#Layer';
		var closeLabel = '#layerClose';
		var loginWindow = jQuery('.mwLayer');
		//var loginPop	= this.LoginForm();
		if( jQuery(layerLabel).css('display') != 'none' ) {
			return;
		}
		if (arguments[0]) {
			this.logingPageType = "jp_channel";
		}
		var loginPop	= this.LoginFormJp();
		
		
		jQuery(layerLabel).html(loginPop);
		jQuery(layerLabel).show();

		var x = ((jQuery(window).width() - 641) / 2) + jQuery(window).scrollLeft() + 150;
		var y = ((jQuery(window).height() - 424) / 2) + jQuery(window).scrollTop() + 150;
		//alert(jQuery(window).scrollTop());
		jQuery("#mwLayer_wrap").css({"top":y+"px","left":x+"px"});

		jQuery('.item>.iLabel').css('position','absolute');

		var iText = jQuery('.item>.iLabel').next('.iText');

		if(iText.length > 1) {
			iText.each(function(i) {
				
				jQuery(this).bind('blur', function() {
					if(jQuery(this).val() == ''){
						jQuery(this).prev('.iLabel').css('visibility','visible');
					} else {
						jQuery(this).prev('.iLabel').css('visibility','hidden');
					}
				});
				
				jQuery(this).bind('change', function() {
					if(jQuery(this).val() == ''){
						jQuery(this).prev('.iLabel').css('visibility','visible');
					} else {
						jQuery(this).prev('.iLabel').css('visibility','hidden');
					}
				});
				
				jQuery(this).bind('focus', function() {
					jQuery(this).prev('.iLabel').css('visibility','hidden');
				});
				
				jQuery(this).prev('.iLabel').bind('click', function() {
					jQuery(this).css('visibility','hidden');
					jQuery('#passwd').focus();
				});
			});
		}
		
		jQuery('#uid').focus();
		
		if(oCookie2.get("c_rememberid")) {
			jQuery('#uid').val(oCookie2.get("c_rememberid"));
			jQuery('#rememberidModal').attr("checked","checked");
		}
		
		// ESC Event
		jQuery(document).keydown(function(event){
			if(event.keyCode != 27) return true;
			if (loginWindow.hasClass('open')) {
				loginWindow.removeClass('open');
			}
			return false;
		});
		
//		jQuery(closeLabel).click(function() {
//			try {
//				json["kind"] = '1';
//			} catch (e) {
//				var json = Array;
//				json["kind"] = '1';
//			}
//			alert('2');
//			loginEndingAction(json);
//			//jQuery('#divPlayer').html('');
//			jQuery(layerLabel).html("");
//			jQuery(layerLabel).hide();
//		});
		
		window.onresize = function(){
			var x = ((jQuery(window).width() - 641) / 2) + jQuery(window).scrollLeft() + 150;
			var y = ((jQuery(window).height() - 424) / 2) + jQuery(window).scrollTop() + 150;
			
			jQuery("#mwLayer_wrap").css({"top":y+"px","left":x+"px"});
		};
		window.onscroll = function(){
			//alert(jQuery(window).scrollTop()+' - '+jQuery(window).scrollTop());
			var x = ((jQuery(window).width() - 641) / 2) + jQuery(window).scrollLeft() + 150;
			var y = ((jQuery(window).height() - 424) / 2) + jQuery(window).scrollTop() + 150;
			//alert(jQuery(window).scrollTop());
			
			jQuery("#mwLayer_wrap").css({"top":y+"px","left":x+"px"});
		};
	},
	

//////////////////////
Login1 : function () {
		var layerLabel = '#Layer';
		var closeLabel = '#layerClose';
		var loginWindow = jQuery('.mwLayer');
		//var loginPop	= this.LoginForm();
		if( jQuery(layerLabel).css('display') != 'none' ) {
			return;
		}
		if (arguments[0]) {
			this.logingPageType = "jp_channel";
		}
		var loginPop1	= this.LoginFormJp1();
		
		
		jQuery(layerLabel).html(loginPop1);
		jQuery(layerLabel).show();

		var x = ((jQuery(window).width() - 641) / 2) + jQuery(window).scrollLeft() + 150;
		var y = ((jQuery(window).height() - 424) / 2) + jQuery(window).scrollTop() + 150;
		//alert(jQuery(window).scrollTop());
		jQuery("#mwLayer_wrap").css({"top":y+"px","left":x+"px"});

		jQuery('.item>.iLabel').css('position','absolute');

		var iText = jQuery('.item>.iLabel').next('.iText');

		if(iText.length > 1) {
			iText.each(function(i) {
				
				jQuery(this).bind('blur', function() {
					if(jQuery(this).val() == ''){
						jQuery(this).prev('.iLabel').css('visibility','visible');
					} else {
						jQuery(this).prev('.iLabel').css('visibility','hidden');
					}
				});
				
				jQuery(this).bind('change', function() {
					if(jQuery(this).val() == ''){
						jQuery(this).prev('.iLabel').css('visibility','visible');
					} else {
						jQuery(this).prev('.iLabel').css('visibility','hidden');
					}
				});
				
				jQuery(this).bind('focus', function() {
					jQuery(this).prev('.iLabel').css('visibility','hidden');
				});
				
				jQuery(this).prev('.iLabel').bind('click', function() {
					jQuery(this).css('visibility','hidden');
					jQuery('#passwd').focus();
				});
			});
		}
		
		jQuery('#uid').focus();
		
		if(oCookie2.get("c_rememberid")) {
			jQuery('#uid').val(oCookie2.get("c_rememberid"));
			jQuery('#rememberidModal').attr("checked","checked");
		}
		
		// ESC Event
		jQuery(document).keydown(function(event){
			if(event.keyCode != 27) return true;
			if (loginWindow.hasClass('open')) {
				loginWindow.removeClass('open');
			}
			return false;
		});
		
//		jQuery(closeLabel).click(function() {
//			try {
//				json["kind"] = '1';
//			} catch (e) {
//				var json = Array;
//				json["kind"] = '1';
//			}
//			alert('2');
//			loginEndingAction(json);
//			//jQuery('#divPlayer').html('');
//			jQuery(layerLabel).html("");
//			jQuery(layerLabel).hide();
//		});
		
		window.onresize = function(){
			var x = ((jQuery(window).width() - 641) / 2) + jQuery(window).scrollLeft() + 150;
			var y = ((jQuery(window).height() - 424) / 2) + jQuery(window).scrollTop() + 150;
			
			jQuery("#mwLayer_wrap").css({"top":y+"px","left":x+"px"});
		};
		window.onscroll = function(){
			//alert(jQuery(window).scrollTop()+' - '+jQuery(window).scrollTop());
			var x = ((jQuery(window).width() - 641) / 2) + jQuery(window).scrollLeft() + 150;
			var y = ((jQuery(window).height() - 424) / 2) + jQuery(window).scrollTop() + 150;
			//alert(jQuery(window).scrollTop());
			
			jQuery("#mwLayer_wrap").css({"top":y+"px","left":x+"px"});
		};
	},
	
//////////////////////


	LoginForm1 : function () {
		
		//alert(this._ret_url);
		
		var loginHtml = '	<div class="mw_bg"></div>';
			loginHtml += '	<div class="gLogin" id="mwLayer_wrap">';
			loginHtml += '		<h1 class="title">로그인</h1>';
			loginHtml += '		<div class="gLogin_wrap">';
			loginHtml += '				<form name="loginFrm" id="loginFrm" target="modal_login" onsubmit="javascript:return LoginAction.checkIt();" action="https://ssl.pandora.tv/global_member/login.v1.ptv" method="post" class="gLogin">';
			loginHtml += '				<input type="hidden" name="work" id="work" value="ajax">';
			loginHtml += '				<input type="hidden" name="retUrl" id="retUrl" value="'+this._retUrl+'">';
			loginHtml += '				<div class="help" style="padding: 25px 0 0 0;">';
			loginHtml += '					<p>판도라TV 회원으로 가입하세요~</p>';
			loginHtml += '					<p class="btn_area"><button type="button" class="btn join" onclick="location.href=\'http://www.pandora.tv/sign/signup.ptv\'">회원가입</button></p>';
			loginHtml += '					<p style="padding:15px 0px;"><iframe id="mLoginAd" src="http://www.pandora.tv/adver.adingo.ptv?adType=LyLogin" width="200" height="200" frameborder="0" topmargin="0" marginheight="0" marginwidth="0" scrolling="no"></iframe></p>';
			loginHtml += '				</div>';
			loginHtml += '				<fieldset>';
			loginHtml += '				<p class="keeping"><span><input type="checkbox" name="autoModal" id="autoModal" value="y" class="iCheck"><label for="autoLogin">자동로그인</label></span><span><div id="displayMsg" style="display:none"></div></span></p>';
			loginHtml += '				<legend>Login</legend>';
			loginHtml += '				<div class="item">';
			loginHtml += '					<label class="iLabel" for="uid">ID</label><input type="text" class="iText uid" id="uid" name="userid" />';
			loginHtml += '				</div>';
			loginHtml += '				<div class="item">';
			loginHtml += '					<label class="iLabel" for="upw">PASSWORD</label><input type="password" class="iText upw" id="passwd" name="passwd" />';
			loginHtml += '				</div>';
			loginHtml += '				<p class="keeping"><input type="checkbox" id="rememberidModal" class="iCheck" value="y" name="rememberidModal"><label for="keepid">아이디 저장</label></p>';
			loginHtml += '				<p class="find"><a href="http://www.pandora.tv/sign/find.ptv">아이디/비밀번호가 기억나지 않으세요?</a></p>';
			loginHtml += '				<span class="btnLogin"><input type="submit" value="로그인" id="submit" /></span>';
			loginHtml += '				</fieldset>';
			loginHtml += '			</form>';
			loginHtml += '		</div>';
			loginHtml += '		<div><iframe name="modal_login" id="modal_login" width="1" height="1" style="display:none;"></iframe></div>';
			loginHtml += '		<a title="로그인 레이어 닫기" class="close" id="layerClose">&nbsp;</a>';
			loginHtml += '	</div>';
			
		return loginHtml;
	},
	
	LoginFormJp1 : function () {
		
		//alert(this._ret_url);
		
		var loginHtml = '<div class="mw_bg" style="position:fixed;"></div>';
		loginHtml += '	<div id="mwLayer_wrap" class="gLogin gLogin_0416" style="top: 300px; left:781.5px;">';
		loginHtml += '		<h1 class="title"></h1>';
		loginHtml += '		<div class="gLogin_wrap gLogin_wrap_0416">';
		loginHtml += '				<form name="loginFrm" id="loginFrm" target="modal_login" onsubmit="javascript:return LoginAction.checkIt();" action="https://ssl.pandora.tv/global_member/login.v1.ptv?'+setGnbRefLot+'" method="post" class="gLogin">';
		loginHtml += '				<input type="hidden" name="work" id="work" value="ajax">';
		loginHtml += '				<input type="hidden" name="retType" id="retType" value="'+this.logingPageType+'">';
		loginHtml += '				<input type="hidden" name="retUrl" id="retUrl" value="'+this._retUrl+'">';
		loginHtml += '				<div class="help">';
		loginHtml += '					<p><img src="http://imgcdn.pandora.tv/ptv_img/global/new_premium/pre_login_ban.jpg" alt="img"></p>';
		loginHtml += '				</div>';
		loginHtml += '				<fieldset class="login_0416">							';
		loginHtml += '					<div style="display:none" id="displayMsg"></div>';
		loginHtml += '					<div class="login_mag">';
		loginHtml += '						<p class="df" id="login_msg1">PANDORA.TVへようこそ！<br/>PANDORA.TVをご利用頂くには、ログインが必要となります。</p>';
		loginHtml += '						<p class="error" id="login_msg2" style="display:none;">入力したID、またはパスワードが間違っています。</p>';
		loginHtml += '					</div>';
		loginHtml += '					<div class="item">';
		loginHtml += '						<label for="uid" class="iLabel" style="position: absolute; visibility: visible;">ID</label>';
		loginHtml += '						<input type="text" name="userid" id="uid" class="iText uid">';
		loginHtml += '					</div>';
		loginHtml += '					<div class="item">';
		loginHtml += '						<label for="upw" class="iLabel" style="position: absolute;">PASSWORD</label>';
		loginHtml += '						<input type="password" name="passwd" id="passwd" class="iText upw">';
		loginHtml += '					</div>';
		loginHtml += '					<p class="keeping">';
		loginHtml += '						<span>';
		loginHtml += '							<input type="checkbox" class="iCheck" value="y" id="autoModal" name="autoModal">';
		loginHtml += '							<label for="autoLogin">次回から自動的にログイン</label>';
		loginHtml += '						</span>';
		loginHtml += '						<span>';
		loginHtml += '							<input type="checkbox" name="rememberidModal" value="y" class="iCheck" id="rememberidModal">';
		loginHtml += '							<label for="keepid">ID保存</label>';
		loginHtml += '						</span>';
		loginHtml += '					</p>';
		loginHtml += '					<p class="btnLogin">';
		loginHtml += '						<input type="submit" id="submit" value="ログイン">';
		loginHtml += '					</p>';
		loginHtml += '					<div class="idpw_find">';
		loginHtml += '						<p class="idpw_find_box1"></span><a href="http://www.pandora.tv/sign/find.ptv">IDをお忘れになりましたか？</a></p>';
		loginHtml += '						<p class="idpw_find_box2"><a href="http://www.pandora.tv/sign/find.ptv">パスワードをお忘れになりましたか？</a></p>';
		loginHtml += '					</div>';
		loginHtml += '				</fieldset>';
		loginHtml += '			</form>';
		loginHtml += '		</div>';
		loginHtml += '		<div style="width:650px;height:60px;text-align:center;padding-top:5px;">';
		//loginHtml += '			<script src="http://a.t.webtracker.jp/js/a.js" type="text/javascript" charset="utf-8"></script><div class="ad_frame sid_1b99da61a27fa4bf25c775ef28b5f5f5b3cfa96d360f97b6 container_div color_#0000CC-#444444-#FFFFFF-#0000FF-#009900"></div>';
	//	loginHtml += '			<a href="http://www.pandora.tv/sign/complete.ptv?step=cmain" target="_self"><img src="http://imgcdn.pandora.tv/pan_img/banner/201305/130514_pre_468X60_01.jpg" border="0" alt="jp.pandora.tv"></a>';
		loginHtml += '			<a href="http://mobile.pandora.tv/" target="_blank"><img src="http://imgcdn.pandora.tv/ptv_img/japan/top/top_mini_3.png" border="0" alt="jp.pandora.tv"></a>';

		loginHtml += '		</div>';
		loginHtml += '		<div>';
		loginHtml += '			<iframe width="1" height="1" style="display:none;" id="modal_login" name="modal_login"></iframe>';
		loginHtml += '		</div>';
		loginHtml += '		<a id="layerClose" class="close" title="閉じる" href="javascript:LoginAction.closeLayer();">&nbsp;</a>';
		loginHtml += '	</div>';
		
		return loginHtml;
	},
	
	
/////////////////////




	LoginForm : function () {
		
		//alert(this._ret_url);
		
		var loginHtml = '	<div class="mw_bg"></div>';
			loginHtml += '	<div class="gLogin" id="mwLayer_wrap">';
			loginHtml += '		<h1 class="title">로그인</h1>';
			loginHtml += '		<div class="gLogin_wrap">';
			loginHtml += '				<form name="loginFrm" id="loginFrm" target="modal_login" onsubmit="javascript:return LoginAction.checkIt();" action="https://ssl.pandora.tv/global_member/login.v1.ptv" method="post" class="gLogin">';
			loginHtml += '				<input type="hidden" name="work" id="work" value="ajax">';
			loginHtml += '				<input type="hidden" name="retUrl" id="retUrl" value="'+this._retUrl+'">';
			loginHtml += '				<div class="help" style="padding: 25px 0 0 0;">';
			loginHtml += '					<p>판도라TV 회원으로 가입하세요~</p>';
			loginHtml += '					<p class="btn_area"><button type="button" class="btn join" onclick="location.href=\'http://www.pandora.tv/sign/signup.ptv\'">회원가입</button></p>';
			loginHtml += '					<p style="padding:15px 0px;"><iframe id="mLoginAd" src="http://www.pandora.tv/adver.adingo.ptv?adType=LyLogin" width="200" height="200" frameborder="0" topmargin="0" marginheight="0" marginwidth="0" scrolling="no"></iframe></p>';
			loginHtml += '				</div>';
			loginHtml += '				<fieldset>';
			loginHtml += '				<p class="keeping"><span><input type="checkbox" name="autoModal" id="autoModal" value="y" class="iCheck"><label for="autoLogin">자동로그인</label></span><span><div id="displayMsg" style="display:none"></div></span></p>';
			loginHtml += '				<legend>Login</legend>';
			loginHtml += '				<div class="item">';
			loginHtml += '					<label class="iLabel" for="uid">ID</label><input type="text" class="iText uid" id="uid" name="userid" />';
			loginHtml += '				</div>';
			loginHtml += '				<div class="item">';
			loginHtml += '					<label class="iLabel" for="upw">PASSWORD</label><input type="password" class="iText upw" id="passwd" name="passwd" />';
			loginHtml += '				</div>';
			loginHtml += '				<p class="keeping"><input type="checkbox" id="rememberidModal" class="iCheck" value="y" name="rememberidModal"><label for="keepid">아이디 저장</label></p>';
			loginHtml += '				<p class="find"><a href="http://www.pandora.tv/sign/find.ptv">아이디/비밀번호가 기억나지 않으세요?</a></p>';
			loginHtml += '				<span class="btnLogin"><input type="submit" value="로그인" id="submit" /></span>';
			loginHtml += '				</fieldset>';
			loginHtml += '			</form>';
			loginHtml += '		</div>';
			loginHtml += '		<div><iframe name="modal_login" id="modal_login" width="1" height="1" style="display:none;"></iframe></div>';
			loginHtml += '		<a title="로그인 레이어 닫기" class="close" id="layerClose">&nbsp;</a>';
			loginHtml += '	</div>';
			
		return loginHtml;
	},
	
	LoginFormJp : function () {
		
		//alert(this._ret_url);
		
		var loginHtml = '<div class="mw_bg" style="position:fixed;"></div>';
		loginHtml += '	<div id="mwLayer_wrap" class="gLogin gLogin_0416" style="top: 300px; left:781.5px;">';
		loginHtml += '		<h1 class="title"></h1>';
		loginHtml += '		<div class="gLogin_wrap gLogin_wrap_0416">';
		loginHtml += '				<form name="loginFrm" id="loginFrm" target="modal_login" onsubmit="javascript:return LoginAction.checkIt();" action="https://ssl.pandora.tv/global_member/login.v1.ptv?'+setGnbRefLot+'" method="post" class="gLogin">';
		loginHtml += '				<input type="hidden" name="work" id="work" value="ajax">';
		loginHtml += '				<input type="hidden" name="retType" id="retType" value="'+this.logingPageType+'">';
		loginHtml += '				<input type="hidden" name="retUrl" id="retUrl" value="'+this._retUrl+'">';
		loginHtml += '				<div class="help">';
		loginHtml += '					<p>PANDORA.TVの会員になりませんか？</p>';
		loginHtml += '					<button onclick="javascript:location.href=\'http://www.pandora.tv/sign/signup.ptv?step=1\';" class="btn join" type="button">無料会員登録</button>';
		loginHtml += '					<iframe width="200" scrolling="no" height="200" frameborder="0" allowtransparency="true" marginheight="0" marginwidth="0" leftmargin="0" topmargin="0" name="adGoogle" src="http://ads.pandora.tv/NetInsight/text/pandora_jp/sub/sub@jp_login" id="mLoginAd"></iframe>';
		loginHtml += '				</div>';
		loginHtml += '				<fieldset class="login_0416">							';
		loginHtml += '					<div style="display:none" id="displayMsg"></div>';
		loginHtml += '					<div class="login_mag">';
		loginHtml += '						<p class="df" id="login_msg1">PANDORA.TVへようこそ！<br/>PANDORA.TVをご利用頂くには、ログインが必要となります。</p>';
		loginHtml += '						<p class="error" id="login_msg2" style="display:none;">入力したID、またはパスワードが間違っています。</p>';
		loginHtml += '					</div>';
		loginHtml += '					<div class="item">';
		loginHtml += '						<label for="uid" class="iLabel" style="position: absolute; visibility: visible;">ID</label>';
		loginHtml += '						<input type="text" name="userid" id="uid" class="iText uid">';
		loginHtml += '					</div>';
		loginHtml += '					<div class="item">';
		loginHtml += '						<label for="upw" class="iLabel" style="position: absolute;">PASSWORD</label>';
		loginHtml += '						<input type="password" name="passwd" id="passwd" class="iText upw">';
		loginHtml += '					</div>';
		loginHtml += '					<p class="keeping">';
		loginHtml += '						<span>';
		loginHtml += '							<input type="checkbox" class="iCheck" value="y" id="autoModal" name="autoModal">';
		loginHtml += '							<label for="autoLogin">次回から自動的にログイン</label>';
		loginHtml += '						</span>';
		loginHtml += '						<span>';
		loginHtml += '							<input type="checkbox" name="rememberidModal" value="y" class="iCheck" id="rememberidModal">';
		loginHtml += '							<label for="keepid">ID保存</label>';
		loginHtml += '						</span>';
		loginHtml += '					</p>';
		loginHtml += '					<p class="btnLogin">';
		loginHtml += '						<input type="submit" id="submit" value="ログイン">';
		loginHtml += '					</p>';
		loginHtml += '					<div class="idpw_find">';
		loginHtml += '						<p class="idpw_find_box1"></span><a href="http://www.pandora.tv/sign/find.ptv">IDをお忘れになりましたか？</a></p>';
		loginHtml += '						<p class="idpw_find_box2"><a href="http://www.pandora.tv/sign/find.ptv">パスワードをお忘れになりましたか？</a></p>';
		loginHtml += '					</div>';
		loginHtml += '				</fieldset>';
		loginHtml += '			</form>';
		loginHtml += '		</div>';
		loginHtml += '		<div style="width:650px;height:60px;text-align:center;padding-top:5px;">';
		//loginHtml += '			<script src="http://a.t.webtracker.jp/js/a.js" type="text/javascript" charset="utf-8"></script><div class="ad_frame sid_1b99da61a27fa4bf25c775ef28b5f5f5b3cfa96d360f97b6 container_div color_#0000CC-#444444-#FFFFFF-#0000FF-#009900"></div>';
	//	loginHtml += '			<a href="http://www.pandora.tv/sign/complete.ptv?step=cmain" target="_self"><img src="http://imgcdn.pandora.tv/pan_img/banner/201305/130514_pre_468X60_01.jpg" border="0" alt="jp.pandora.tv"></a>';
	//	loginHtml += '			<a href="http://game.pandora.tv" target="_blank"><img src="http://cdn.pandora.tv/ongame/lol/images/jp_wing_140213.jpg" border="0" alt="jp.pandora.tv"></a>';
	//	loginHtml += '			<a href="/sign/complete.campaign.ptv?step=cmain" target="_blank"><img src="http://imgcdn.pandora.tv/ptv_img/banner/jp_login_bottom_banner.png" border="0" alt="jp.pandora.tv"></a>';
		loginHtml += '		</div>';
		loginHtml += '		<div>';
		loginHtml += '			<iframe width="1" height="1" style="display:none;" id="modal_login" name="modal_login"></iframe>';
		loginHtml += '		</div>';
		loginHtml += '		<a id="layerClose" class="close" title="閉じる" href="javascript:LoginAction.closeLayer();">&nbsp;</a>';
		loginHtml += '	</div>';
		
		return loginHtml;
	},






//////////////////////

	closeLayer : function () {
		try {
			json["kind"] = '1';
		} catch (e) {
			var json = Array;
			json["kind"] = '1';
		}
		jQuery('#Layer').html("");
		jQuery('#Layer').hide();
		
		try {
			loginEndingAction(json);
		} catch (e) {
		}
		//jQuery('#divPlayer').html('');
	},
	
	checkIt : function () {
		jQuery('#login_msg1').show();
		jQuery('#login_msg2').hide();
		if (jQuery('#uid').val() == "") {
			alert('IDを入力してください。');
			jQuery('#uid').focus();
			return false;
		} else if (jQuery('#passwd').val() == "") {
			alert('パスワードを入力してください。');
			jQuery('#passwd').focus();
			return false;
		}
	},
		
	LoginFail : function () {
		jQuery('#login_msg1').hide();
		jQuery('#login_msg2').show();
		//jQuery('#displayMsg').html("<font color=red>아이디 또는 패스워드가 일치 하지 않습니다.</font>");
		//jQuery('#displayMsg').show();
	},
	
	adult : function () {
		if(confirm("로그인이 필요한 서비스 입니다.로그인을 하시겠습니까?") == true) {
			this.Login();
		}
	},
	
	close : function (act) {
		//jQuery(act).html("");
		//jQuery(act).hide();
	}
};


/* cookie Class */
var oCookieClassJP = {
	initialize : function(){
	},
	
	/* set cookie value */
	set : function (sName, sValue, expireSeconds) {
		var sDomain = ".pandora.tv";
		var todayDate = new Date();
		var ExpireTime = new Date(todayDate.getTime()+expireSeconds*1000);
		document.cookie = sName + "=" + sValue + ";" + ((expireSeconds) ? "expires=" + ExpireTime.toGMTString() + ";" : "") + "domain=" + sDomain + ";path=/;";
	},
	
	/* get cookie value */
	get : function (sName) {
		var aCookie = document.cookie.split("; ");
		for (var i=0; i<aCookie.length; i++) {
			var aCrumb = aCookie[i].split("=");
			if (sName == aCrumb[0]) {
				return aCrumb[1];
			}
		}
		return null;
	},
	
	/* delete cookie */
	destroy : function (sName) {
		this.set(sName, "", 0);
	},
	
	/* update cookie */
	update : function (expireSeconds) {
		var CookieList = document.cookie.split("; ");
		for(var i=0;i<CookieList.length;i++) {
			var Cookies = CookieList[i].split("=");
			if(Cookies[0] == "SavedID") {
				continue;
			}
			this.set(Cookies[0], Cookies[1], expireSeconds);
		}
	}
};

/* storage Class start */
var storageClass = {
	_local : null,
	_temp : [],
	_run : false,
	
	_getLocal : function(){
		return this._local;
	},
	
	appendData : function(obj){
		if (this._local == null) {
			this._local = obj;
		} else {
			jQuery.merge(this._local,obj);
		}
	},
	
	appendHash : function(key, value){
		jQuery.merge(this._local, {key:null} );
		this._local[key] = value;
		return this._local[key];
	},
	
	getChild : function(child){
		return this._getLocal()[child];
	},
	
	isKey : function(key){
		if (this._run == false) {
			this._run = true;
			var keyv = this._getLocal();
			
			if(keyv == null || keyv[key] == undefined) {
				this._run = false;
				return false;
			} else {
				this._run = false;
				return true;
			}
		}
	},
	
	size : function(){
		return this._getLocal().keys().length;
	},
	
	update : function(dest, value){
		this._local[dest] = value;
	},
	
	update2 : function(key, iterator, cond, value){
		var target = this._getLocal()[key][iterator];
		for(var i=0; i<target.length; i++){
			if(target[i]['prg_id'].toString() == cond) target[i]['ment_cnt'] = value;
		}
	},
	
	update3 : function(value) {
		var stKeys = this._getLocal().keys();
		for(var i=0;i<stKeys.length;i++) {
			if(stKeys[i].indexOf("page") > -1 && stKeys[i].indexOf("prg_id") > -1) {
				if(stKeys[i]['prgList']) {
					for(var j=0;i<stKeys[i]['prgList'].length;j++) {
						if(stKeys[i]['prgList'][j]['prg_id'] == value['prg_id']) {
							Object.extend(stKeys[i]['prgList'][j], value);
							break;
						}
					}
				}
			}
		}
	},
	
	remove : function(dest){
		this._getLocal().remove(dest);
	},
	
	clear : function(){
		this._local = null;
		this.initialize();
	}
};

var loadJsClass = {
	loadJS : function (path, charset1, id) {
		if (charset1 == undefined) {
			charset1 = "utf-8";
		}
//		try {
//			jQuery("#"+id).attr('src', path);
//		} catch (e) {
//			alert('dd');
			var oScript = document.createElement("SCRIPT");
			with(oScript) {
				setAttribute("type", "text/javascript");
				setAttribute("language", "javascript");
				setAttribute("charset", charset1);
				setAttribute("src", path);
				if(id!=undefined){
					setAttribute("id", id);
				}
			}
			document.getElementsByTagName('head')[0].appendChild(oScript);
//		}
	}
};

var inputAdver = false;
var autoKeyword = null;	/* 검색어 자동완성 요청을 할지 말지 결정*/
var autoKeywordTime = 100;	/* 검색어 자동 완성 timeout 시간*/

function setNation(nation) {
	var lang = nation;

	oCookieClassJP.set("clientLang", lang, 30*60*60*60);
	oCookieClassJP.set("v_listlang", lang, 86400);

	switch (lang) {
		case "ko" :
			location.href = 'http://www.pandora.tv/';
		break;
		case "cn" :
			location.href = 'http://cn.pandora.tv/';
		break;
		case "jp" :
			location.href = 'http://jp.pandora.tv/';
		break;
		default :
			location.href = 'http://en.pandora.tv/';
		break;
	}
}

function cupiInfoToggle(){
	if ( jQuery('#popcorn_view').css("display") == 'block' ) {
		jQuery('#popcorn_view').css("display","none");
	} else {
		jQuery("#popcorn_view").css('display', 'block');
	}
}

function cagegoryToggle(){
	if ( jQuery('.sh_gnb_group').css("display") == 'block' ) {
		jQuery('.sh_gnb_btn2').removeClass("active");
		jQuery('.sh_gnb_group').css("display","none");
	} else {
		jQuery('.sh_gnb_btn2').addClass("active");
		jQuery(".sh_gnb_group").css('display', 'block');
		
	}
}

function infoToggle(){
	if ( jQuery('.jp_box').css("display") == 'block' ) {
		jQuery('.jp_box').css("display","none");
	} else {
		jQuery(".jp_box").css('display', 'block');
		
	}
}

var categoryBtnClick = false;
var arrowBtnClick = false;
/* 시작 */
function searchEventSet() {
	
	jQuery('.sh_gnb_btn1_new').click( function (evt) { categoryBtnClick = true; cagegoryToggle(); } );
	jQuery('.sh_gnb.gnbbox').click( function (evt) { categoryBtnClick = true; cagegoryToggle(); } );
	jQuery('.sh_gnb_btn2').click( function (evt) { categoryBtnClick = true; cagegoryToggle(); } );
	jQuery('#AKCArrow').click( function (evt) { arrowBtnClick = true;  akcClass.arrowClick(evt); } );
	jQuery('#searchBtn').click( function(evt){ arrowBtnClick = true; searchGo(evt); } );
	jQuery('#query').click( function(evt){ 
		arrowBtnClick = true; 
	});
	jQuery('#query').focusin( function(evt){ 
		arrowBtnClick = true; 
	});
	jQuery('#query').keydown( function(evt){ searchAction2(evt); } );
	jQuery('#query').keyup( function(evt){ searchAction2(evt); } );
	jQuery('body').click( function(evt){ 
		if ( arrowBtnClick == false ) { 
			akcClass.akc_hide(); 
		} else { 
			arrowBtnClick = false; 
		} 
		if ( categoryBtnClick == false ) { 
			if( jQuery('.sh_gnb_group').css("display") != "none") { 
				cagegoryToggle();
			}
		} else { 
			categoryBtnClick = false; 
		} 
	});
	//jQuery('#query').blur( function(){ alert('sss'); } );
	//jQuery('#searchBtn').click( function(){ searchAction2(); } );
	//jQuery('.search').blur( function(){ jQuery(".search_lst").css('display', 'none'); } );
	
}

/* 검색 광고 때문에 클래스를 하나 만듦 */
var oSearch2 = {
	displayAdverInput : function() {
		if (arguments[0] && arguments[1]) { /* && chInfoJson['keyword'] == "") { */
			var imgSource = arguments[0];
			searchLink = arguments[1];

			jQuery("#query").val("");
			jQuery("#query").css('background-image', "url('" + imgSource + "')");
			jQuery("#query").style.backgroundRepeat = "no-repeat";
			jQuery("#query").style.backgroundPosition = "left";

			inputAdver = true;
		}
	},
	loadAkc : function(json) {
		akcClass.loadAkc(json);
	}
};

function keywordTimeOut () {
	try { clearTimeout(autoKeyword); }
	catch (e) {}
}

var searchBtnClick = false;
function searchGo() {
	
	if (inputAdver == undefined || inputAdver == false) { /* no Adver */
		//alert('2');
		var url = searchLink+"?&query="+encodeURIComponent(jQuery('#query').val()) + "&sq="+oCookieClassJP.get("ipCountry")+setGnbRefLot;
		document.location.href = url;
		return;
	} else {
		//alert('3');
		document.location.href = searchLink+"?"+setGnbRefLot;
		return;
	}
	
}
/* 검색 관련 JS Start */
/* 기본 변수 셋팅 */
var searchClick = 0;
var keyaccesstype = "keydown"; /* 누르고 있을때 어떤것만 인정 할껏인가임 */

/* functions */
function searchAction2(evt) {
	
	var code = "";
	
	//evt = this.event;
	
	//alert(evt.type);
	//alert(evt.id);
	try { code = evt.keyCode; } catch (e) { code = evt.charCode; }
//		var el = Event.element(evt);
//		var el = evt.element;
//		alert(el.name);
//		return;
	
	if ( (evt.type == "keydown") &&  (code == 13)) {
		searchGo();
		return;
		
	} else {
	
		if (searchClick < 1) {
			searchClick++;
		}
		inputAdver = false;
		
		/* 자동 완성 시작 */
		if ( (evt.type == "keyup" || evt.type == "keydown" || evt.type == "click" || evt.type == "keypress") ) {
//				try {
//					Event.stopObserving(document.body, "click", function(evt) {
//						var el = Event.element(evt);
//						if (el.id != "query" && el.id != "AKCArrow" && !Position.within(jQuery("#AKCResult"), Event.pointerX(evt), Event.pointerY(evt))) {
//							akcClass.akc_hide();
//						}
//					}.bind(this));
//				} catch (e) {}
//
//				Event.observe(document.body, "click", function(evt) {
//					var el = Event.element(evt);
//					if (el.id != "query" && el.id != "AKCArrow" && !Position.within(jQuery("#AKCResult"), Event.pointerX(evt), Event.pointerY(evt))) {
//						akcClass.akc_hide();
//					}
//				}.bind(this));

			var sendQuery = jQuery("#query").val();
			sendQuery = sendQuery.replace(/^ +/g, "");
			sendQuery = sendQuery.replace(/ +$/g, " ");
			sendQuery = sendQuery.replace(/ +/g, " ");

			if (evt.type == "click" || evt.type == "keydown" || evt.type == "keyup") {
				//jQuery('#query').css('background-image', "");
			}

			switch(code) {
				case 9: /* 탭 */
					if (evt.type == "keyup") {
						return;
					}

					if(sendQuery != "" && jQuery("#AKCResult").css('display') != "none") {
						jQuery('#query').css('background-image', "");
						try {
							evt.returnValue = false;
						} catch(e) {
							try {
								evt.preventDefault();
							}
							catch (e) { }
						}

						if(evt.shiftKey) {
							if (evt.type == keyaccesstype) {
								akcClass.akc_up(); /* shieft + tab 위로 올리자 */
							}
						} else {
							if (evt.type == keyaccesstype) {
								akcClass.akc_down(); /* tab 만 하면 아래로 내리자 */
							}
						}
					}

				break;

				case 13: /* 엔터*/
					/*	this.akc_hide(); // 레이어 숨기기*/
				break;

				case 38:	/* 위쪽 화살표 */
					if (evt.type == keyaccesstype) {
						jQuery('#query').css('background-image', "");
						akcClass.akc_up(); /* 위로 올리기 */
					}
				break;

				case 40:	/* 아래쪽 화살표 */
					if (evt.type == keyaccesstype) {
						jQuery('#query').css('background-image', "");
						akcClass.akc_down();
					}
				break;

				default:
					if(code == 9 || code == 16 || code == 27 || code == 37 || code == 38 || code == 40 || code == 18) {
						return;
					}
					if (sendQuery.length > 0 || code == 8) {
						//alert(sendQuery.length + ' ' + code);
						
						if (autoKeyword != null) {
							keywordTimeOut();
						}

						if (akcClass.akc_yn == null || akcClass.akc_yn == "y") {
							
							jQuery('#query').css('background-image', ""); /*akc_rmbackimg(); */
							
							akcClass.akc_pointerNum = -1;
							
							if ( storageClass.isKey("akcStorage_" + sendQuery ) ) {
								akcClass.loadAkc( storageClass.getChild("akcStorage_" + sendQuery) );
							} else {
								autoKeyword = setTimeout(function() {
									loadJsClass.loadJS("http://search.pandora.tv/konan/akc/akc_utf.ptv?q="+encodeURIComponent(sendQuery), '', 'akc');/* + evt.type);*/
									//loadJsClass.loadJS("alert('ddddd');", '', 'akc');/* + evt.type);*/
								}, autoKeywordTime);
								
							}
						}
					} else {
						akcClass.akc_hide();
					}
				break;
			}
		}
	}
}

/* popup layer Class Start */
var gnbPopLayer = {
	eventId : null,
	
	bodyClick : function(evt) {
		var pointerX = Event.pointerX(evt);
		var pointerY = Event.pointerY(evt);
		if(jQuery(this.eventId) && !Position.within(jQuery(this.eventId), pointerX, pointerY)) {
			this.layerClose();
		}
	},
	
	eventSet : function() {
		Event.observe(document.body, "mousedown", this.bodyClick.bind(this));
	},
	
	eventErase : function() {
		Event.stopObserving(document.body, "mousedown", this.bodyClick.bind(this));
	}
};

/* 자동 완성 class Start */
var akcClass = {
	akc_orgquery : "",
	akc_yn : null,
	akc_pointerNum : -1,
	akcJson : {"QUERY":"", "LIST":""},
	loadAkc : function(json) {
		this.akc_orgquery = jQuery("#query").val();
		this.akcJson = json;
		if (this.akcJson["LIST"].length <= 0) {
			/* return; */
		}
		
		if (this.akc_yn == null || this.akc_yn == "y") {
			if (this.akcJson["LIST"].length == 0) {
				var obj = "{'akcStorage_" + this.akcJson["QUERY"] + "':" + jQuery.parseJSON(this.akcJson) + "}";
				storageClass.appendData(obj);
				this.akc_hide();
			} else {
				if( !storageClass.isKey("akcStorage_" + this.akcJson["QUERY"]) ) {
					var obj = "{'akcStorage_" + this.akcJson["QUERY"] + "':" + jQuery.parseJSON(this.akcJson) + "}";
					storageClass.appendData(obj);
				}
				this.akc_show();
			}
		}
	},
	
	akc_setCookie : function() {
		switch (oCookieClassJP.get("akcYN")) {
			case "n":
				oCookieClassJP.set("akcYN", "y", 0);
				this.akc_yn = "y";
				this.akc_show();
			break;

			default :
				oCookieClassJP.set("akcYN", "n", 0);
				this.akc_yn = "n";
				this.akc_hide();
			break;
		}
	},

	arrowClick : function() {
		if (jQuery(".sh_search_lst").css('display') == 'block' || jQuery(".sh_search_lst").css('display') == "") {
			//jQuery('#joinch_'+ch_id).removeClass('active');
			//jQuery('#joinch_'+ch_id).addClass('active');
			this.akc_hide();
		} else {
			//jQuery('#joinch_'+ch_id).removeClass('active');
			//jQuery('#joinch_'+ch_id).addClass('active');
			this.akc_show();
		}
	},

	akc_up : function() {
		if(this.akc_pointerNum <= 0 || this.akcJson["LIST"].length == 0) {
			jQuery("#query").val(this.akc_orgquery);
			this.akc_hide();
			this.akc_pointerNum = -1;
			return;
		}

		var choicNum = this.akc_pointerNum - 1;
		jQuery("#query").val(this.akcJson["LIST"][choicNum]["KEYWORD"]);

		this.akc_show(); /* 레이어 보여 주고 이미지 처리 */
		this.akc_curstyle(choicNum, this.akc_pointerNum);
		this.akc_pointerNum = choicNum;
	},

	akc_down : function() {
		if (this.akc_pointerNum+1 >= this.akcJson["LIST"].length || this.akcJson["LIST"].length == 0) {
			return;
		}

		var choicNum = this.akc_pointerNum + 1;
		jQuery("#query").val(this.akcJson["LIST"][choicNum]["KEYWORD"]);

		this.akc_show(); /* 레이어 보여 주고 이미지 처리 */
		this.akc_curstyle(choicNum, this.akc_pointerNum);
		this.akc_pointerNum = choicNum;
	},

	akc_hide : function() {
		try {
			if(jQuery(".sh_search_lst").css('display') == 'block') {
				jQuery(".sh_search_lst").css('display', 'none');
			}
		} catch (e) {
		}
		this.akc_chgbtn(0);

		/* 카테고리 언어 셀렉트 박스 none으로 변경 */
		try {
			jQuery("#contentsLang").css('display', 'block');
		} catch (e) { }
	},

	akc_show : function() {
		if (this.akc_yn == "n") {
			
			jQuery("#akcUse").html("キーワード自動完成機能を有効にする");
			jQuery(".sh_lst_dsc").html("キーワード事項完成機能を使うと.<br>楽にキーワードを入力できます.");
			jQuery("#AKCIDiv").html("");
			
		} else if ( jQuery("query").value == "" ) { 
			
			jQuery("#akcUse").html("キーワード自動完成機能を無効にする");
			jQuery(".sh_lst_dsc").html("");
			jQuery("#AKCIDiv").html("");
			
		} else if ( this.akcJson["LIST"].length == 0 ) { 
			
			jQuery("#akcUse").html("キーワード自動完成機能を無効にする");
			jQuery(".sh_lst_dsc").html("");
			jQuery("#AKCIDiv").html("");
			
		} else {
			jQuery("#akcUse").html("キーワード自動完成機能を無効にする");
			jQuery(".sh_lst_dsc").html("");
			
			try {
				jQuery("#akcUL").height("0px");;
			} catch (e) { }

			var akcText = "";
			var akcHtml = "<ul id=\"akcUL\">";
			for (var i = 0; i < this.akcJson["LIST"].length; i++) {
				akcText = this.akcJson["LIST"][i]["KEYWORD"].replace(this.akcJson["QUERY"], "<span>" + this.akcJson["QUERY"] + "</span>");

				akcHtml += "<li id='akcKwd_"+i+"'><a href=\""+searchLink+"?&query=" + encodeURIComponent(this.akcJson["LIST"][i]["KEYWORD"]) + setGnbRefLot + "\">" + akcText + "</a></li>";
			}
			akcHtml += "</ul>";
		
			if (akcHtml) {
				jQuery("#AKCIDiv").html(akcHtml);
				if (akcJson["LIST"].length > 5) {
					jQuery("#akcUL").height("120px");
				}
			} else {
				jQuery("#AKCIDiv").html(akcUse.toString());/* = akcHtml; */
			}
			this.akc_chgbtn(1);
		}

		if(jQuery("#AKCResult2").css('display') == 'none') {
			jQuery("#AKCResult2").css('display', 'block');
		}

		if(jQuery(".sh_search_lst").css('display') == 'none') {
			jQuery(".sh_search_lst").css('display', 'block');
		}

		/* 카테고리 언어 셀렉트 박스 none으로 변경 */
		try {
			jQuery("#contentsLang").css('display', 'none');;
		} catch (e) { }
		this.akc_chgbtn(1);
	},

	akc_chgbtn : function(bool) {
		if(bool) {
			/*jQuery("AKCArrow").className = "redrop";*/
			jQuery("#AKCArrow").addClass("active");
		} else {
			/*jQuery("AKCArrow").className = "drop";*/
			jQuery("#AKCArrow").removeClass("active");
		}
	},

	akc_curstyle : function(pos, oldpos) {
		try {
			jQuery("#akcKwd_"+oldpos).css('background-color', "#FFFFFF");
		} catch(e) { }
		jQuery("#akcKwd_"+pos+" a").css('background-color', "#F5F5F5");
		jQuery("#a_"+pos).focus();
		jQuery("#query").focus();
	}
};

function setJoinCh( ch_id ) {
	
	//alert('sss');
	var mode = jQuery('#joinch_'+ch_id).attr('join_mode');
	//alert(mode);
	var member_info_url = gnbJsonLink+'gnb/member_info.ptv?jsoncallback=?&join_ch_mode='+mode+'&ch_id='+ch_id;
	
	var jqxhr = jQuery.getJSON(member_info_url, function(data) {
	})
	.success(function(data) { 
		
		if( mode == 'F' ) {
			jQuery('#joinch_'+ch_id).attr('join_mode', 'T');
			jQuery('#joinch_'+ch_id).removeClass('active');
		} else {
			jQuery('#joinch_'+ch_id).attr('join_mode', 'F');
			jQuery('#joinch_'+ch_id).addClass('active');
		}
		//alert(ch_id);
		
		//alert(data);
		//jQuery(".header_btm").html(data);
		//jQuery(".header_btm").css('display', 'block');
	 })
	.error(function() { 
		if( autoCheckCnt < autoCheckLimit ) {
			setTimeout(function() {
				setJoinCh();
			}, autoCheckTime);
			autoCheckCnt++;
		}
	 });
	
}

var autoGNBTime		= 1500;
var autoGNBCnt		= 0;
var autoGNBLimit	= 3;

function getNewGNB(position ,query,adult_chk_age){
	var cate_position = '';
	if (arguments[2]) {
		set_leng = arguments[2];
	} else {
		set_leng = 'jp';
	}
	if ( position == undefined) {
		position = 'all';
	}
	if ( query == undefined) {
		var gnb_url = gnbJsonLink+"gnb/gnb_jp.v2.ptv?jsoncallback=?&position="+position+"&adult_chk_age="+adult_chk_age;
	} else {
		var gnb_url = gnbJsonLink+"gnb/gnb_jp.v2.ptv?jsoncallback=?&query="+query+"&position="+position+"&adult_chk_age="+adult_chk_age;
	}
	
	var gnbSet = jQuery.getJSON(gnb_url, function(data) {
	})
	.success(function(data) { 
		//alert(data);
		jQuery("#sh_header").html(data);
		jQuery("#sh_header").show();
	 })
	.error(function() { 
		if( autoGNBCnt < autoGNBLimit ) {
			setTimeout(function() {
				getNewGNB(position ,query);
			}, autoGNBTime);
			autoGNBCnt++;
		}
	 });
}

var autoFooterTime		= 1500;
var autoFooterCnt		= 0;
var autoFooterLimit	= 3;

function getNewFooter(position){
	var cate_position = '';
	if (arguments[2]) {
		cate_position = arguments[2];
	}
	if ( position == undefined) {
		position = 'all';
	}
	var gnb_url = gnbJsonLink+"gnb/footer_jp.ptv?jsoncallback=?&position="+position+"&cate_position="+cate_position;
	
	var gnbSet = jQuery.getJSON(gnb_url, function(data) {
	})
	.success(function(data) { 
		//alert(data);
		jQuery("#new_footer").html(data);
		jQuery("#new_footer").show();
	 })
	.error(function() { 
		if( autoFooterCnt < autoFooterLimit ) {
			setTimeout(function() {
				getNewFooter();
			}, autoFooterTime);
			autoFooterCnt++;
		}
	 });
}

function popLayerClose(setName, setDate){
	setDateCnt = 60*60*24*parseInt(setDate, 10);
	document.getElementById(setName).style.display="none";
	oCookieClassJP.set(setName, "1", setDateCnt);
}
function popLayerStart(setName){
	document.getElementById(setName).style.display="block";
}
function popCookieGet(setName){
	var aCookie = document.cookie.split("; ");
	for (var i=0; i<aCookie.length; i++) {
		var aCrumb = aCookie[i].split("=");
		if (setName == aCrumb[0]) {
			return aCrumb[1];
		}
	}
}

function popLogAction( targetId, targetDay, logNumber, targetUrl, targetType ) {

	var path = "http://log.sv.pandora.tv/FullScreen?mode=" + logNumber;
	loadJsClass.loadJS(path, 'utf-8', '');

	if (targetType == "close") {
		popLayerClose(targetId,targetDay);	
	} else {
		//location.href = targetUrl;
		window.open(targetUrl);
		document.getElementById(targetId).style.display = "none";
	}
}

