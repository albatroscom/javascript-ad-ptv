/*********************************************
*	Name				:	
*	Current Version		:	0.0.1
*	Create by Date		:	
*	Last Update_Date	:	
*	Create by			:	Oh Hyun Sub
*	Description			:	
**********************************************/

// 최근 본 영상
var freeRecent = {
	vData : "",
	data : [],
	view : false,
	set : function(total_num) {
		this.data = '';
		try { this.data = eval(SharedObject.getItem("vMovie")).reverse(); } catch (e) { }
		
		var totCnt = this.data.length;
		if (totCnt ) {
			this.view = true;
			this.vData = "";
			this.vData += "<div class=\"section_list pdt22\" style=\"z-index:2\">";
			this.vData += "<h3>再生履歴</h3>";
			//this.vData += "<a href=\"javascript:watchedVideo_all_DEL('vMovie');\" title=\"삭제하기\" class=\"btn_main_del2\">삭제하기</a>";
			this.vData += "	<div class=\"thmb_group\">";
			for(var i=0; i<total_num; i++){
				if(this.data[i] && this.data[i].length > 0) {
					if (this.data[i].length==5) {
						var thumb = getVodThumbnail(this.data[i][2],this.data[i][1]);
					}
					else {
						var pData = this.data[i][5];
						var thumb = getVodThumbnail(pData.chuserid, pData.prgid);
					}
					
					this.vData += "<div class=\"thmb\" style=\"z-index:4\">";
					this.vData += "	<div class=\"thmb_a140x80\">";
					this.vData += "	<div class=\"th_img_area\">";
					this.vData += "		<p class=\"th_img\" ><img src=\""+thumb+"\" onerror=\"javascript:imgError(this,'http://imgcdn.pandora.tv/static/newprg_thumb.gif');\"></p>";
					this.vData += "			<p class=\"th_num\">" + this.data[i][3] + "</p>";
					this.vData += "		<a href=\"http://channel.pandora.tv/channel/video.ptv?ch_userid=" + this.data[i][2] + "&amp;prgid=" + this.data[i][1] + "&amp;ref=main&amp;lot=recent_1\" class=\"th_btn\" title=\""+this.data[i][0]+"\"><img src=\"http://imgcdn.pandora.tv/ptv_img/newptv/blind_img.gif\" width=\"100\" height=\"62\" onerror=\"javascript:imgError(this,'http://imgcdn.pandora.tv/static/newprg_thumb.gif');\" alt=\""+this.data[i][0]+"\"></a> <a href=\"javascript:\" class=\"th_add\"><span class=\"blind\">공유하기</span></a> <div id=\"recent_del"+i+"\" style=\"display:none;\"><a href=\"javascript:watchedVideo_DEL(" + this.data[i][1] + ",'vMovie');\" class=\"th_del\"><span class=\"blind\" prgid=\""+this.data[i][1]+"\"></span></a></div> </div>";
					this.vData += "		<dl>";
					this.vData += "			<dt class=\"th_h\"><a href=\"http://channel.pandora.tv/channel/video.ptv?ch_userid=" + this.data[i][2] + "&amp;prgid=" + this.data[i][1] + "&amp;ref=main&amp;lot=recent_2\" title=\""+this.data[i][0]+"\">"+this.data[i][0].replace(/\\/g, '')+"</a></dt>";
					this.vData += "			<dd class=\"th_ch\"><a href=\"http://channel.pandora.tv/channel/video.ptv?ch_userid=" + this.data[i][2] + "&amp;prgid=" + this.data[i][1] + "&amp;ref=main&amp;lot=recent_3\" title=\""+this.data[i][2]+"\">"+this.data[i][2]+"</a></dd>";
					this.vData += "		</dl>";
					this.vData += "	</div>";
					this.vData += "</div>";
				}
			}
			this.vData += "	</div>";
			this.vData += "</div>";
			
			jQuery("#vodRecentList").html(this.vData);
		
		} else if ( this.view == true ) {
			
			this.vData = "";
			this.vData += "<div class=\"section_list pdt22\" style=\"z-index:2\">";
			this.vData += "<h3>再生履歴</h3>";
			this.vData += "<div class=\"voderror\">";
			this.vData += "		<div class=\"voderror_box mag_delev\"></div>";
			this.vData += "	</div>";
			this.vData += "</div>";
			jQuery("#vodRecentList").html(this.vData);
			
		} else {

			this.view = true;
			this.vData += "<div class=\"section_list pdt22\" style=\"z-index:2\">";
			this.vData += "<h3>再生履歴</h3>";
			//this.vData += "<a href=\"javascript:watchedVideo_all_DEL('vMovie');\" title=\"삭제하기\" class=\"btn_main_del2\">삭제하기</a>";
			this.vData += "	<div class=\"thmb_group\">";
			this.vData += "		<div class=\"thmb_group\">";
			this.vData += "	<img src=\"http://imgcdn.pandora.tv/ptv_img/global/new_premium/pre_no_videoimg.jpg\" alt=\"img\">";
			this.vData += "</div>";
			jQuery("#vodRecentList").html(this.vData);
		}
		
	}
}


/*
<!-- 최근 본 영상 -->
					<div class=\"section_list pdt22\" style=\"z-index:2\">
						<!-- 제목 -->
						<h3><a href=\"\">再生履歴</a></h3>
						<!-- //제목 -->
						<!-- 썸네일영역 -->
						<div class=\"thmb_group\">
							<!-- 루프 -->
							<div class=\"thmb\" style=\"z-index:4\">
								<div class=\"thmb_a140x80\">
									<div class=\"th_img_area\">
										<p class=\"th_img\"><img src=\"http://imgcdn.pandora.tv/static/global/recommend_1381472218.jpg\" onerror=\"javascript:imgError(this,'http://imgcdn.pandora.tv/static/prg_thumb.gif');\"></p>
										<p class=\"th_num\">05:32</p>
										<a href=\"javascript:\" class=\"th_btn\"><img src=\"http://imgcdn.pandora.tv/ptv_img/japan/top/blind_img.gif\" width=\"140\" height=\"80\"></a> <a href=\"javascript:\" class=\"th_add\"><span class=\"blind\">共有する</span></a> </div>
									<dl>
										<dt class=\"th_h\"><a href=\"\">クレジットカード自動決済の</a></dt>
										<!-- 메달추가 medal_icon 클래스 넣기빼기  -->
										<dd class=\"th_ch\"><a href=\"\">プレイリストに追加</a></dd>
										<dd class=\"th_like\"><a class=\"btn_like\">いいね</a><span>12131223132</span></dd>
									</dl>
								</div>
							</div>
							<!-- //루프 -->
							<!-- 루프 -->
							<div class=\"thmb\" style=\"z-index:3\">
								<div class=\"thmb_a140x80\">
									<div class=\"th_img_area\">
										<p class=\"th_img\"><img src=\"http://imgcdn.pandora.tv/ptv_img/newptv/thmb_example_160-120.jpg\" onerror=\"javascript:imgError(this,'http://imgcdn.pandora.tv/static/prg_thumb.gif');\"></p>
										<p class=\"th_num\">05:32</p>
										<a href=\"javascript:\" class=\"th_btn\"><img src=\"http://imgcdn.pandora.tv/ptv_img/japan/top/blind_img.gif\" width=\"140\" height=\"80\"></a> <a href=\"javascript:\" class=\"th_add\"><span class=\"blind\">共有する</span></a> </div>
									<dl>
										<dt class=\"th_h\"><a href=\"\">見た目は子供だが実は中年のベテラン刑事と</a></dt>
										<dd class=\"th_ch\"><a href=\"\">プレイリストに追加</a></dd>
										<dd class=\"th_like\"><a class=\"btn_like\">いいね</a><span>12131223132</span></dd>
									</dl>
								</div>
							</div>
							<!-- //루프 -->
							<!-- 루프 -->
							<div class=\"thmb\" style=\"z-index:2\">
								<div class=\"thmb_a140x80\">
									<div class=\"th_img_area\">
										<p class=\"th_img\"><img src=\"http://imgcdn.pandora.tv/ptv_img/newptv/thmb_example_160-120.jpg\" onerror=\"javascript:imgError(this,'http://imgcdn.pandora.tv/static/prg_thumb.gif');\"></p>
										<p class=\"th_num\">05:32</p>
										<p class=\"icon_hd\"></p>
										<a href=\"javascript:\" class=\"th_btn\"><img src=\"http://imgcdn.pandora.tv/ptv_img/japan/top/blind_img.gif\" width=\"140\" height=\"80\"></a> <a href=\"javascript:\" class=\"th_add\"><span class=\"blind\">共有する</span></a> </div>
									<dl>
										<dt class=\"th_h\"><a href=\"\">クレジットカード自動決済の</a></dt>
										<dd class=\"th_ch\"><a href=\"\">プレイリストに追加</a></dd>
										<dd class=\"th_like\"><a class=\"btn_like\">いいね</a><span>12131223132</span></dd>
									</dl>
								</div>
							</div>
							<!-- //루프 -->
							<!-- 루프 -->
							<div class=\"thmb\" style=\"z-index:2\">
								<div class=\"thmb_a140x80\">
									<div class=\"th_img_area\">
										<p class=\"th_img\"><img src=\"http://imgcdn.pandora.tv/ptv_img/newptv/thmb_example_160-120.jpg\" onerror=\"javascript:imgError(this,'http://imgcdn.pandora.tv/static/prg_thumb.gif');\"></p>
										<p class=\"th_num\">05:32</p>
										<a href=\"javascript:\" class=\"th_btn\"><img src=\"http://imgcdn.pandora.tv/ptv_img/japan/top/blind_img.gif\" width=\"140\" height=\"80\"></a> <a href=\"javascript:\" class=\"th_add\"><span class=\"blind\">共有する</span></a> </div>
									<dl>
										<dt class=\"th_h\"><a href=\"\">クレジットカード自動決済の</a></dt>
										<dd class=\"th_ch\"><a href=\"\">プレイリストに追加</a></dd>
										<dd class=\"th_like\"><a class=\"btn_like\">いいね</a><span>12131223132</span></dd>
									</dl>
								</div>
							</div>
							<!-- //루프 -->
						</div>
						<!-- //썸네일영역 -->
					</div>
					<!-- //최근 본 영상 -->
					<div class=\"section_list pdt22\" style=\"z-index:2;display:none\">
						<!-- 제목 -->
						<h3><a href=\"\">再生履歴</a></h3>
						<!-- //제목 -->
						<!-- 썸네일영역 -->
						<div class=\"thmb_group\">
							<img src=\"http://imgcdn.pandora.tv/ptv_img/global/new_premium/pre_no_videoimg.jpg\" alt=\"img\">
						</div>
						<!-- //썸네일영역 -->
					</div>



*/





/* 최근본 동영상에 삭제 */
function watchedVideo_DEL(prgid,obj) {
	var tmp = getSharedObject(obj);

	for(var i=0; i<tmp.length; i++) {
		if(tmp[i][1] == prgid || tmp[i][0] == prgid) {
			tmp.splice(i, 1);
		}
		else {
		}
	}

	SharedObject.setItem(obj,jQuery.toJSON(tmp));
	freeRecent.set(6);
}

/* 최근본 동영상에 삭제 */
function getSharedObject(key) {
	return eval(SharedObject.getItem(key)) || [];
}

/* 최근본 동영상에 전체삭제 */
function watchedVideo_all_DEL(obj) {
	
	SharedObject.removeItem(obj);
	
	freeRecent.set(6);
}

function vmov_playall() {
	
	if ( oRecentCookieClass.get("glb_mem[userid]") ){
		window.location.href = "http://channel.pandora.tv/channel/playlist.ptv?ref=vMovie_playAll&ch_userid=" + oRecentCookieClass.get("glb_mem[userid]") + "#SAWC.1";
	} else {
		if(confirm('재생은 로그인 후 이용하실 수 있습니다.\n로그인 하시겠습니까?')) {
			LoginAction.Login();
		}
	}
	
}

var oRecentCookieClass = {
	initialize : function(){
	},

	/* set cookie value */
	set : function (sName, sValue, expireSeconds) {
		var sDomain = ".pandora.tv";
		var todayDate = new Date();
		var ExpireTime = new Date(todayDate.getTime()+expireSeconds*1000);
		document.cookie = sName + "=" + sValue + ";" + ((expireSeconds) ? "expires=" + ExpireTime.toGMTString() + ";" : "") + "domain=" + sDomain + ";path=/;";
	},

	/* get cookie value */
	get : function (sName) {
		var aCookie = document.cookie.split("; ");
		for (var i=0; i<aCookie.length; i++) {
			var aCrumb = aCookie[i].split("=");
			if (sName == aCrumb[0]) {
				return aCrumb[1];
			}
		}
		return null;
	},

	/* delete cookie */
	destroy : function (sName) {
		this.set(sName, "", 0);
	},

	/* update cookie */
	update : function (expireSeconds) {
		var CookieList = document.cookie.split("; ");
		for(var i=0;i<CookieList.length;i++) {
			var Cookies = CookieList[i].split("=");
			if(Cookies[0] == "SavedID") {
				continue;
			}
			this.set(Cookies[0], Cookies[1], expireSeconds);
		}
	}
};

function getVodThumbnail(argUserid, argPrgid) {
	argUserid = argUserid.toLowerCase();
	var noPrgid = 30800000 ; /* 로컬 통합 정책시 적용되는 기준 프로그램 아이디...*/
	var arrSizeDir = new Array("_channel_img_sm", "_channel_img");
	var path = "http://imguser.pandora.tv/pandora/";

	if(arguments[2] != undefined && (arguments[2].toUpperCase() == "M")) {
		path += arrSizeDir[1] + "/";
	} else {
		path += arrSizeDir[0] + "/";
	}

	if(argUserid && argPrgid) {
		for(var i=0;i<2;i++) {
			path += argUserid.substr(i, 1) + "/";
		}

		path += argUserid + "/";
		if(argPrgid > noPrgid) {
			var leng = String(argPrgid).length;
			path += String(argPrgid).substring(leng, leng-2) + "/";
		}
		path += "vod_thumb_" + argPrgid + ".jpg";

	} else {
		path += "g/u/guest/guest.gif";
	}
	return path;
}


var m = {
		'\b': '\\b',
		'\t': '\\t',
		'\n': '\\n',
		'\f': '\\f',
		'\r': '\\r',
		'"' : '\\"',
		'\\': '\\\\'
	},
	s = {
		'array': function (x) {
			var a = ['['], b, f, i, l = x.length, v;
			for (i = 0; i < l; i += 1) {
				v = x[i];
				f = s[typeof v];
				if (f) {
					v = f(v);
					if (typeof v == 'string') {
						if (b) {
							a[a.length] = ',';
						}
						a[a.length] = v;
						b = true;
					}
				}
			}
			a[a.length] = ']';
			return a.join('');
		},
		'boolean': function (x) {
			return String(x);
		},
		'null': function (x) {
			return "null";
		},
		'number': function (x) {
			return isFinite(x) ? String(x) : 'null';
		},
		'object': function (x) {
			if (x) {
				if (x instanceof Array) {
					return s.array(x);
				}
				var a = ['{'], b, f, i, v;
				for (i in x) {
					v = x[i];
					f = s[typeof v];
					if (f) {
						v = f(v);
						if (typeof v == 'string') {
							if (b) {
								a[a.length] = ',';
							}
							a.push(s.string(i), ':', v);
							b = true;
						}
					}
				}
				a[a.length] = '}';
				return a.join('');
			}
			return 'null';
		},
		'string': function (x) {
			if (/["\\\x00-\x1f]/.test(x)) {
				x = x.replace(/([\x00-\x1f\\"])/g, function(a, b) {
					var c = m[b];
					if (c) {
						return c;
					}
					c = b.charCodeAt();
					return '\\u00' +
						Math.floor(c / 16).toString(16) +
						(c % 16).toString(16);
				});
			}
			return '"' + x + '"';
		}
	};

jQuery.toJSON = function(v) {
	var f = isNaN(v) ? s[typeof v] : s['number'];
	if (f) return f(v);
};

//jQuery.parseJSON = function(v, safe) {
//	if (safe === undefined) safe = jQuery.parseJSON.safe;
//	if (safe && !/^("(\\.|[^"\\\n\r])*?"|[,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t])+?$/.test(v)){
//		return undefined;
//	}
//	return eval('('+v+')');
//};
//
//jQuery.parseJSON.safe = false;