if (consumer_seq == undefined)		var consumer_seq	= "244";	// 고정
if (livere_seq == undefined)		var livere_seq		= "7667";	// 고정 모바일 : 8235
if (smartlogin_seq == undefined)	var smartlogin_seq	= "273";	// 고정

var livereReply = "";
var liveReClass = {
	test			: "",
	title			: "",
	selector		: "",
	title			: "",
	videoSrc		: "",
	videoThumb		: "",

	title			: "",
	refer			: "",
	site			: "",
	description 	: "",
	livereGroupId	: "",
	isListFolded	: false,
	__init			: false,

	liveReInit : function (title, selector) {
		if (this.__init == true) {
			liveReClass.liveReExec('1');
			return;
		}

		if (!livere_seq) { liveReClass.logView("livere_seq 값 누락"); return; }
		if (!this.refer) { liveReClass.logView("refer 값 누락"); return; }
		if (!this.title) { liveReClass.logView("title 값 누락"); return; }

		$.ajax({
			url : "http://101.livere.co.kr/js/livere_lib.js", //"http://assets.livere.co.kr:8080/js/livere_lib.js",
			dataType : "script",
			crossDomain : true,
			success : function () {
				$.ajax({
					url : "http://assets.livere.co.kr:8080/js/livere.js",
					dataType : "script",
					crossDomain : true,
					success : function () {
						liveReClass.__init = true;
						liveReClass.liveReExec();
					}
				});
			}
		});
	},

	liveReExec : function (type) {
		if (type) {
			livereReply.isListFolded		= this.isListFolded;	// 댓글 기본으로 열고 닫기 기능

			livereReply.site				= this.site;			// 라이브리 페이지 url 키값
			livereReply.description 		= this.description ;	// 내용 설명 문구
			livereReply.videosrc			= this.videoSrc;		//embedUrl;	//동영상URL
			livereReply.videothumb			= this.videoThumb;		//동영상섬네일
			livereReply.livereGroupId		= this.livereGroupId;

			livereLib.renewLivere( this.refer , this.title );
		} else {
			livereReply						= new Livere( livere_seq , this.refer , this.title );

			livereReply.isListFolded		= this.isListFolded;	// 댓글 기본으로 열고 닫기 기능

			livereReply.site				= this.site;			// 라이브리 페이지 url 키값
			livereReply.description 		= this.description ;	// 내용 설명 문구
			livereReply.videosrc			= this.videoSrc;		//embedUrl;	//동영상URL
			livereReply.videothumb			= this.videoThumb;		//동영상섬네일
			livereReply.livereGroupId		= this.livereGroupId;

			livereLib.start();
		}
	},

	logView : function (msg) {
		if (this.test == 1) {
			try {
				console.log(msg);
			} catch (e) {
				alert(msg);
			}
			return;
		}

		try {
			console.log(msg);
		} catch (e) {}
	}
};
