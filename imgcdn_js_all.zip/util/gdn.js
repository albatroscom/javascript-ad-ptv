// Copyright 2013 Google Inc. All Rights Reserved.
// You may study, modify, and use this example for any purpose.
// Note that this example is provided "as is", WITHOUT WARRANTY
// of any kind either expressed or implied.


var PlayerController = function() {
	this.contentPlayer = document.getElementById('video_player');
	this.adContainer = document.getElementById('adcontainer');
	this.videoPlayerContainer = document.getElementById('videoJs');

	try {
		this.width = jQuery("#videoJs .nx_player").width();//"100%";
		this.height = jQuery("#videoJs .nx_player").height();//200;
	} catch (e) {
		this.width = this.videoPlayerContainer.childNodes[0].offsetWidth;
		this.height = this.videoPlayerContainer.childNodes[0].offsetHeight;
	}

  this.adPlaying = false;
};

PlayerController.prototype.setAdPlaying = function(adPlaying) {
  this.adPlaying = adPlaying;
};

PlayerController.prototype.preloadContent = function(contentLoadedAction) {
  // If this is the initial user action on iOS or Android device,
  // simulate playback to enable the video element for later program-triggered
  // playback.
  if (this.isMobilePlatform()) {
    this.contentPlayer.addEventListener(
        'loadedmetadata',
        contentLoadedAction,
        false);
//    this.contentPlayer.load();
  } else {
    contentLoadedAction();
  }
};

PlayerController.prototype.play = function() {
  this.contentPlayer.play();
};

PlayerController.prototype.pause = function() {
  this.contentPlayer.pause();
};

PlayerController.prototype.isMobilePlatform = function() {
  return this.contentPlayer.paused &&
      (navigator.userAgent.match(/(iPod|iPhone|iPad)/) ||
       navigator.userAgent.toLowerCase().indexOf('android') > -1);
};

PlayerController.prototype.resize = function(
    position, top, left, width, height) {
/*
//  console.log('videoPlayerContainer :: ' + this.videoPlayerContainer);
  this.videoPlayerContainer.style.position = position;
  this.videoPlayerContainer.style.top = top + 'px';
  this.videoPlayerContainer.style.left = left + 'px';
//  console.log('width :: ' + width);
  this.videoPlayerContainer.style.width = (width == "100%" ? width  : width + 'px');
  this.videoPlayerContainer.style.height = height + 'px';
  this.contentPlayer.style.width = width + 'px';
  this.contentPlayer.style.height = height + 'px';
*/
};

PlayerController.prototype.getVideoPlayer = function() {
  return this.contentPlayer;
};

PlayerController.prototype.registerVideoEndedCallback = function(callback) {
  this.contentPlayer.addEventListener(
      'ended',
      callback,
      false);
};

// Copyright 2013 Google Inc. All Rights Reserved.
// You may study, modify, and use this example for any purpose.
// Note that this example is provided "as is", WITHOUT WARRANTY
// of any kind either expressed or implied.

var MainController = function(playerController) {
	this.console = document.getElementById('console');
	this.playButton = document.getElementById('big_play');
	this.bradient_bg = document.getElementById('gradient_bg');
	this.screen = document.getElementById('screen');
	this.smallPlayButton = document.getElementById('playBtn');



	this.playButton.addEventListener('click', this.bind(this, this.onClick), false);
	this.smallPlayButton.addEventListener('click', this.bind(this, this.onClick), false);

	this.bradient_bg.addEventListener('click', this.bind(this, this.onClick), false);
	this.screen.addEventListener('click', this.bind(this, this.onClick), false);

	this.fullscreenButton = document.getElementById('video-fullscreen');
	this.fullscreenButton.addEventListener(
      'click',
      this.bind(this, this.onFullscreenClick),
      false);

  this.fullscreenWidth = null;
  this.fullscreenHeight = null;

  var fullScreenEvents = [
      'fullscreenchange',
      'mozfullscreenchange',
      'webkitfullscreenchange'];
  for (key in fullScreenEvents) {
    document.addEventListener(
        fullScreenEvents[key],
        this.bind(this, this.onFullscreenChange),
        false);
  }

  this.playing = false;
  this.adsActive = false;
  this.adsDone = false;
  this.fullscreen = false;

  this.playerController = playerController;
  this.adsController = new AdsController(this, this.playerController);
  this.adTagUrl = 'http://googleads.g.doubleclick.net/pagead/ads?ad_type=text&client=pub-1915678166967029&channel=1222644821&hl=ko&description_url=' + encodeURIComponent(location.href);
//  this.adTagUrl = 'http://googleads.g.doubleclick.net/pagead/ads?ad_type=text&client=pub-1915678166967029&channel=2488738420&max_ad_duration=120000&sdmax=120000&description_url=' + encodeURIComponent(location.href);

  this.playerController.registerVideoEndedCallback(
      this.bind(this, this.onContentEnded));
};

MainController.prototype.bind = function(thisObj, fn) {
  return function() {
    fn.apply(thisObj, arguments);
  };
};

MainController.prototype.onClick = function() {
  if (!this.adsDone) {

    // The user clicked/tapped - inform the ads controller that this code
    // is being run in a user action thread.
    this.adsController.initialUserAction();
    // At the same time, initialize the content player as well.
    // When content is loaded, we'll issue the ad request to prevent it
    // from interfering with the initialization.
    // See https://developers.google.com/interactive-media-ads/docs/sdks/html5/v3/ads#iosvideo
    // for more information.
//	alert('maincrontrol onclick');
	this.playerController.preloadContent(this.bind(this, this.loadAds));

    this.adsDone = true;
    return;
  }

/*
  if (this.adsActive) {
    if (this.playing) {
      this.adsController.pause();
    } else {
      this.adsController.resume();
    }
  } else {
    if (this.playing) {
      this.playerController.pause();
    } else {
      this.playerController.play();
    }
  }
  */

  this.playing = !this.playing;

  this.updateChrome();
};

MainController.prototype.onFullscreenClick = function() {
return;
  if (this.fullscreen) {
    // The video is currently in fullscreen mode
    var cancelFullscreen = document.exitFullScreen ||
        document.webkitCancelFullScreen ||
        document.mozCancelFullScreen;
    if (cancelFullscreen) {
      cancelFullscreen.call(document);
    } else {
      this.onFullscreenChange();
    }
  } else {
    // Try to enter fullscreen mode in the browser
    var requestFullscreen = document.documentElement.requestFullScreen ||
        document.documentElement.webkitRequestFullScreen ||
        document.documentElement.mozRequestFullScreen;
    if (requestFullscreen) {
      this.fullscreenWidth = window.screen.width;
      this.fullscreenHeight = window.screen.height;
      requestFullscreen.call(document.documentElement);
    } else {
      this.fullscreenWidth = window.innerWidth;
      this.fullscreenHeight = window.innerHeight;
      this.onFullscreenChange();
    }
  }
  //requestFullscreen.call(document.documentElement);
};

MainController.prototype.updateChrome = function() {
return;
  if (this.playing) {
    this.playButton.textContent = 'II';
  } else {
    // Unicode play symbol.
    this.playButton.textContent = String.fromCharCode(9654);
  }
};

MainController.prototype.log = function(message) {
  console.log(message);
//  this.console.innerHTML = this.console.innerHTML + '<br/>' + message;
};

MainController.prototype.resumeAfterAd = function() {
//  this.playerController.play();
  this.adsActive = false;
  this.updateChrome();
};

MainController.prototype.pauseForAd = function() {
  this.adsActive = true;
  this.playing = true;
//  this.playerController.pause();
  this.updateChrome();
};

MainController.prototype.adClicked = function() {
  this.playing = false;
  this.updateChrome();
};

MainController.prototype.loadAds = function() {
  this.adsController.requestAds(this.adTagUrl);
};

MainController.prototype.onFullscreenChange = function() {
  if (this.fullscreen) {
    // The user just exited fullscreen
    // Resize the ad container
    this.adsController.resize(
        this.playerController.width,
        this.playerController.height);
    // Return the video to its original size and position
    this.playerController.resize('relative','','',this.playerController.width,this.playerController.height);
    this.fullscreen = false;
  } else {
    // The fullscreen button was just clicked
    // Resize the ad container
    var width = this.fullscreenWidth;
    var height = this.fullscreenHeight;
    this.makeAdsFullscreen();
    // Make the video take up the entire screen
    this.playerController.resize('absolute', 0, 0, width, height);
    this.fullscreen = true;
  }
};

MainController.prototype.makeAdsFullscreen = function() {
  this.adsController.resize(
      this.fullscreenWidth,
      this.fullscreenHeight);
};

MainController.prototype.onContentEnded = function() {
  this.adsController.contentEnded();
};


// Copyright 2013 Google Inc. All Rights Reserved.
// You may study, modify, and use this example for any purpose.
// Note that this example is provided "as is", WITHOUT WARRANTY
// of any kind either expressed or implied.

var AdsController = function(controller, player) {
  this.controller = controller;
  this.player = player;
  this.contentCompleteCalled = false;
  this.adDisplayContainer = new google.ima.AdDisplayContainer(this.player.adContainer);
  this.adsLoader = new google.ima.AdsLoader(this.adDisplayContainer);
  this.adsManager = null;

  this.adsLoader.addEventListener(
      google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
      this.onAdsManagerLoaded,
      false,
      this);
  this.adsLoader.addEventListener(
      google.ima.AdErrorEvent.Type.AD_ERROR,
      this.onAdError,
      false,
      this);
};

// On iOS and Android devices, video playback must begin in a user action.
// AdDisplayContainer provides a initialize() API to be called at appropriate
// time.
// This should be called when the user clicks or taps.
AdsController.prototype.initialUserAction = function() {
  this.adDisplayContainer.initialize();
};

AdsController.prototype.requestAds = function(adTagUrl) {
  var adsRequest = new google.ima.AdsRequest();

  adsRequest.adTagUrl = adTagUrl;
  adsRequest.linearAdSlotWidth = this.player.width;
  adsRequest.linearAdSlotHeight = this.player.height;
  adsRequest.nonLinearAdSlotWidth = this.player.width;
  adsRequest.nonLinearAdSlotHeight = this.player.height;
  this.adsLoader.requestAds(adsRequest);
};

AdsController.prototype.onAdsManagerLoaded = function(adsManagerLoadedEvent) {
  this.controller.log('Ads loaded.');
	eventClass.ctViewTime = 0;

	var adContainerSize = {};
	try {
		adContainerSize.width = jQuery("#videoJs .nx_player").width();//"100%";
		adContainerSize.height = jQuery("#videoJs .nx_player").height();//200;
	} catch (e) {
		adContainerSize.width = this.videoPlayerContainer.childNodes[0].offsetWidth;
		adContainerSize.height = this.videoPlayerContainer.childNodes[0].offsetHeight;
	}

	jQuery("#adcontainer").css({"width" : adContainerSize.width, "height" : adContainerSize.height, "position" : "absolute", "top" : "0px", "left" : "0px", "z-index" : "1"});
	jQuery("#adcontainer").children().css({"width" : "360"});


  this.adsManager = adsManagerLoadedEvent.getAdsManager(
      this.player.contentPlayer);
  this.processAdsManager(this.adsManager);
};

AdsController.prototype.processAdsManager = function(adsManager) {
  // Attach the pause/resume events.
  adsManager.addEventListener(
      google.ima.AdEvent.Type.CONTENT_PAUSE_REQUESTED,
      this.onContentPauseRequested,
      false,
      this);
  adsManager.addEventListener(
      google.ima.AdEvent.Type.CONTENT_RESUME_REQUESTED,
      this.onContentResumeRequested,
      false,
      this);
  // Handle errors.
  adsManager.addEventListener(
      google.ima.AdErrorEvent.Type.AD_ERROR,
      this.onAdError,
      false,
      this);
  var events = [google.ima.AdEvent.Type.ALL_ADS_COMPLETED,
                google.ima.AdEvent.Type.CLICK,
                google.ima.AdEvent.Type.COMPLETE,
                google.ima.AdEvent.Type.FIRST_QUARTILE,
                google.ima.AdEvent.Type.LOADED,
                google.ima.AdEvent.Type.MIDPOINT,
                google.ima.AdEvent.Type.PAUSED,
                google.ima.AdEvent.Type.STARTED,
                google.ima.AdEvent.Type.THIRD_QUARTILE,
                google.ima.AdEvent.Type.SKIPPED,
                google.ima.AdEvent.Type.RESUMED,
                google.ima.AdEvent.Type.SKIPPABLE_STATE_CHANGED,
                google.ima.AdEvent.Type.USER_CLOSE];
  for (var index in events) {
//	  console.log(events[index]);
    adsManager.addEventListener(
        events[index],
        this.onAdEvent,
        false,
        this);
  }

  var initWidth, initHeight;
  if (this.controller.fullscreen) {
    initWidth = this.controller.fullscreenWidth;
    initHeight = this.controller.fullscreenHeight;
  } else {
    initWidth = this.player.width;
    initHeight = this.player.height;
  }
  adsManager.init(
    initWidth,
    initHeight,
    google.ima.ViewMode.NORMAL);

  adsManager.start();
};

AdsController.prototype.pause = function() {
  this.controller.log('pause: ');
  if (this.adsManager) {
    this.adsManager.pause();
  }
};

AdsController.prototype.resume = function() {
  this.controller.log('resume: ');
  if (this.adsManager) {
    this.adsManager.resume();
  }
};

AdsController.prototype.onContentPauseRequested = function(adErrorEvent) {
//	alert('콘텐츠가 재개 되어야 할 때 시작 함니다. onContentPauseRequested');
  this.controller.log('onContentPauseRequested: ');
  this.controller.pauseForAd();
};

AdsController.prototype.onContentResumeRequested = function(adErrorEvent) {
//	alert('콘텐츠가 재개 되어야 할 때 시작 함니다. onContentResumeRequested');
  this.controller.log('onContentResumeRequested: ');
  // Without this check the video starts over from the beginning on a
  // post-roll's CONTENT_RESUME_REQUESTED
  if (!this.contentCompleteCalled) {
    this.controller.resumeAfterAd();
  }
};

AdsController.prototype.onAdEvent = function(adEvent) {
	this.controller.log('Ad event: ' + adEvent.type + " , " + window.orientation);
	if (adEvent.type == google.ima.AdEvent.Type.STARTED) {
		jQuery(".nx_btn_area, div.nx_player div.bar, .full_screen, .gradient_bg, .video_down").fadeOut("fast");
		clearInterval(eventClass.controlViewTimeObj);
		jQuery("#adcontainer").show();
	} else if (adEvent.type == google.ima.AdEvent.Type.CLICK) {
		this.controller.adClicked();
	} else if (adEvent.type == google.ima.AdEvent.Type.USER_CLOSE) {
//	  console.log("aaa :: " +  this.player.adContainer);
	  this.player.adContainer.style.display = "none";
	  this.player.adContainer.innerHTML = "";
//	  alert("ad div out");
  }
};


AdsController.prototype.onAdError = function(adErrorEvent) {
  this.controller.log('Ad error: ' + adErrorEvent.getError().toString());
  if (this.adsManager) {
    this.adsManager.destroy();
  }
  // 광고가 없으니 다음을 준비
  this.controller.resumeAfterAd();
};

AdsController.prototype.resize = function(width, height) {
  this.controller.log('resize: ');
  if (this.adsManager) {
    this.adsManager.resize(width, height, google.ima.ViewMode.FULLSCREEN);
  }
};

AdsController.prototype.contentEnded = function() {
  this.controller.log('contentEnded: --');
  this.contentCompleteCalled = true;
  this.adsLoader.contentComplete();
};

jQuery(window).on("orientationchange", function () {
	try {
		setTimeout ( function () {
			if (googleOveray == true) {
			var adContainerSize = {};
				adContainerSize.width = jQuery("#videoJs .nx_player").width();//"100%";
				adContainerSize.height = jQuery("#videoJs .nx_player div").height();//200;

				jQuery("#adcontainer").css({"width" : adContainerSize.width, "height" : adContainerSize.height, "position" : "absolute", "top" : "0px", "left" : "0px", "z-index" : "1"});
				jQuery("#adcontainer").children().css({"width" : adContainerSize.width});
			}
		}, 500);
	} catch(e) {}
});