/*********************************************
*	Name				:	
*	Current Version		:	0.0.1
*	Create by Date		:	
*	Last Update_Date	:	
*	Create by			:	Oh Hyun Sub
*	Description			:	
**********************************************/

// 최근 본 영상
var freeRecent = {
	vData : "",
	data : [],
	view : false,
	set : function(total_num) {
		this.data = '';
		try { this.data = eval(SharedObject.getItem("vMovie")).reverse(); } catch (e) { }
		
		var totCnt = this.data.length;
		if (totCnt ) {
			this.view = true;
			this.vData = "";
			this.vData += "<div class=\"section_wrap gty_line_b1\">";
			this.vData += "<h3><a href=\"javascript:vmov_playall();\">최근 본 영상</a></h3>";
			this.vData += "<a href=\"javascript:watchedVideo_all_DEL('vMovie');\" title=\"삭제하기\" class=\"btn_main_del2\">삭제하기</a>";
			this.vData += "	<div class=\"thmb_group\">";
			try {
				for(var i=0; i<total_num; i++){
					if(this.data[i] && this.data[i].length > 0) {
						if (this.data[i].length==5) {
							var thumb = getVodThumbnail(this.data[i][2],this.data[i][1]);
						}
						else {
							var pData = this.data[i][5];
							var thumb = getVodThumbnail(pData.chuserid, pData.prgid);
						}
						
						this.vData += "<div class=\"rgt_thmb\" style=\"z-index:10;\">";
						this.vData += "	<div class=\"thmb_b70x50\">";
						this.vData += "	<div class=\"th_img_area\" onMouseOver=\"javascript:viewToggle('recent_del"+i+"', 'inline');\"  onMouseOut=\"javascript:viewToggle('recent_del"+i+"', 'none');\">";
						this.vData += "		<p class=\"th_img\" ><img src=\""+thumb+"\" onerror=\"javascript:imgError(this,'http://imgcdn.pandora.tv/static/newprg_thumb.gif');\"></p>";
						this.vData += "			<p class=\"th_num\">" + this.data[i][3] + "</p>";
						this.vData += "		<a href=\"http://channel.pandora.tv/channel/video.ptv?ch_userid=" + this.data[i][2] + "&amp;prgid=" + this.data[i][1] + "&amp;ref=main&amp;lot=recent_1\" class=\"th_btn\" title=\""+this.data[i][0]+"\"><img src=\"http://imgcdn.pandora.tv/ptv_img/newptv/blind_img.gif\" width=\"100\" height=\"62\" onerror=\"javascript:imgError(this,'http://imgcdn.pandora.tv/static/newprg_thumb.gif');\" alt=\""+this.data[i][0]+"\"></a> <a href=\"javascript:\" class=\"th_add\"><span class=\"blind\">공유하기</span></a> <div id=\"recent_del"+i+"\" style=\"display:none;\"><a href=\"javascript:watchedVideo_DEL(" + this.data[i][1] + ",'vMovie');\" class=\"th_del\"><span class=\"blind\" prgid=\""+this.data[i][1]+"\"></span></a></div> </div>";
						this.vData += "		<dl>";
						this.vData += "			<dt class=\"th_h\"><a href=\"http://channel.pandora.tv/channel/video.ptv?ch_userid=" + this.data[i][2] + "&amp;prgid=" + this.data[i][1] + "&amp;ref=main&amp;lot=recent_2\" title=\""+this.data[i][0]+"\">"+this.data[i][0].replace(/\\/g, '')+"</a></dt>";
						this.vData += "			<dd class=\"th_ch\"><a href=\"http://channel.pandora.tv/channel/video.ptv?ch_userid=" + this.data[i][2] + "&amp;prgid=" + this.data[i][1] + "&amp;ref=main&amp;lot=recent_3\" title=\""+this.data[i][2]+"\">"+this.data[i][2]+"</a></dd>";
						this.vData += "		</dl>";
						this.vData += "	</div>";
						this.vData += "</div>";
					}
				}
			}
			catch (e){}
			
			this.vData += "	</div>";
			this.vData += "</div>";
			
			jQuery("#vodRecentList").html(this.vData);
		
		} else if ( this.view == true ) {
			
			this.vData = "";
			this.vData += "<div class=\"section_wrap gty_line_b1\">";
			this.vData += "<h3><a href=\"javascript:vmov_playall();\">최근 본 영상</a></h3>";
			this.vData += "<div class=\"voderror\">";
			this.vData += "		<div class=\"voderror_box mag_delev\"></div>";
			this.vData += "	</div>";
			this.vData += "</div>";
			jQuery("#vodRecentList").html(this.vData);
			
		} else {
			jQuery("#vodRecentList").html('').hide();
		}
		
	}
}

/* 최근본 동영상에 삭제 */
function watchedVideo_DEL(prgid,obj) {
	var tmp = getSharedObject(obj);

	for(var i=0; i<tmp.length; i++) {
		if(tmp[i][1] == prgid || tmp[i][0] == prgid) {
			tmp.splice(i, 1);
		}
		else {
		}
	}

	SharedObject.setItem(obj,jQuery.toJSON(tmp));
	freeRecent.set(6);
}

/* 최근본 동영상에 삭제 */
function getSharedObject(key) {
	return eval(SharedObject.getItem(key)) || [];
}

/* 최근본 동영상에 전체삭제 */
function watchedVideo_all_DEL(obj) {
	
	SharedObject.removeItem(obj);
	
	freeRecent.set(6);
}

function vmov_playall() {
	
	if ( oRecentCookieClass.get("glb_mem[userid]") ){
		window.location.href = "http://channel.pandora.tv/channel/playlist.ptv?ref=vMovie_playAll&ch_userid=" + oRecentCookieClass.get("glb_mem[userid]") + "#SAWC.1";
	} else {
		if(confirm('재생은 로그인 후 이용하실 수 있습니다.\n로그인 하시겠습니까?')) {
			LoginAction.Login();
		}
	}
	
}

var oRecentCookieClass = {
	initialize : function(){
	},

	/* set cookie value */
	set : function (sName, sValue, expireSeconds) {
		var sDomain = ".pandora.tv";
		var todayDate = new Date();
		var ExpireTime = new Date(todayDate.getTime()+expireSeconds*1000);
		document.cookie = sName + "=" + sValue + ";" + ((expireSeconds) ? "expires=" + ExpireTime.toGMTString() + ";" : "") + "domain=" + sDomain + ";path=/;";
	},

	/* get cookie value */
	get : function (sName) {
		var aCookie = document.cookie.split("; ");
		for (var i=0; i<aCookie.length; i++) {
			var aCrumb = aCookie[i].split("=");
			if (sName == aCrumb[0]) {
				return aCrumb[1];
			}
		}
		return null;
	},

	/* delete cookie */
	destroy : function (sName) {
		this.set(sName, "", 0);
	},

	/* update cookie */
	update : function (expireSeconds) {
		var CookieList = document.cookie.split("; ");
		for(var i=0;i<CookieList.length;i++) {
			var Cookies = CookieList[i].split("=");
			if(Cookies[0] == "SavedID") {
				continue;
			}
			this.set(Cookies[0], Cookies[1], expireSeconds);
		}
	}
};

function getVodThumbnail(argUserid, argPrgid) {
	argUserid = argUserid.toLowerCase();
	var noPrgid = 30800000 ; /* 로컬 통합 정책시 적용되는 기준 프로그램 아이디...*/
	var arrSizeDir = new Array("_channel_img_sm", "_channel_img");
	var path = "http://imguser.pandora.tv/pandora/";

	if(arguments[2] != undefined && (arguments[2].toUpperCase() == "M")) {
		path += arrSizeDir[1] + "/";
	} else {
		path += arrSizeDir[0] + "/";
	}

	if(argUserid && argPrgid) {
		for(var i=0;i<2;i++) {
			path += argUserid.substr(i, 1) + "/";
		}

		path += argUserid + "/";
		if(argPrgid > noPrgid) {
			var leng = String(argPrgid).length;
			path += String(argPrgid).substring(leng, leng-2) + "/";
		}
		path += "vod_thumb_" + argPrgid + ".jpg";

	} else {
		path += "g/u/guest/guest.gif";
	}
	return path;
}


var m = {
		'\b': '\\b',
		'\t': '\\t',
		'\n': '\\n',
		'\f': '\\f',
		'\r': '\\r',
		'"' : '\\"',
		'\\': '\\\\'
	},
	s = {
		'array': function (x) {
			var a = ['['], b, f, i, l = x.length, v;
			for (i = 0; i < l; i += 1) {
				v = x[i];
				f = s[typeof v];
				if (f) {
					v = f(v);
					if (typeof v == 'string') {
						if (b) {
							a[a.length] = ',';
						}
						a[a.length] = v;
						b = true;
					}
				}
			}
			a[a.length] = ']';
			return a.join('');
		},
		'boolean': function (x) {
			return String(x);
		},
		'null': function (x) {
			return "null";
		},
		'number': function (x) {
			return isFinite(x) ? String(x) : 'null';
		},
		'object': function (x) {
			if (x) {
				if (x instanceof Array) {
					return s.array(x);
				}
				var a = ['{'], b, f, i, v;
				for (i in x) {
					v = x[i];
					f = s[typeof v];
					if (f) {
						v = f(v);
						if (typeof v == 'string') {
							if (b) {
								a[a.length] = ',';
							}
							a.push(s.string(i), ':', v);
							b = true;
						}
					}
				}
				a[a.length] = '}';
				return a.join('');
			}
			return 'null';
		},
		'string': function (x) {
			if (/["\\\x00-\x1f]/.test(x)) {
				x = x.replace(/([\x00-\x1f\\"])/g, function(a, b) {
					var c = m[b];
					if (c) {
						return c;
					}
					c = b.charCodeAt();
					return '\\u00' +
						Math.floor(c / 16).toString(16) +
						(c % 16).toString(16);
				});
			}
			return '"' + x + '"';
		}
	};

jQuery.toJSON = function(v) {
	var f = isNaN(v) ? s[typeof v] : s['number'];
	if (f) return f(v);
};

//jQuery.parseJSON = function(v, safe) {
//	if (safe === undefined) safe = jQuery.parseJSON.safe;
//	if (safe && !/^("(\\.|[^"\\\n\r])*?"|[,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t])+?$/.test(v)){
//		return undefined;
//	}
//	return eval('('+v+')');
//};
//
//jQuery.parseJSON.safe = false;