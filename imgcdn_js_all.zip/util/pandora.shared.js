/*********************************************
*	Name				:	
*	Current Version		:	0.0.1
*	Create by Date		:	
*	Last Update_Date	:	
*	Create by			:	ray.kim
*	Description			:	
**********************************************/

var SharedObject = {
	_globalStore : null,

	/* flash version */
	_version : null,

	/* public */
	isLoaded : false,

	/* private */
	isIE : !!(window.attachEvent && !window.opera),

	_isLoaded : function(v) {
		this.isLoaded = true;
		this._version = v;
	},

	/* private */
	_create : function() {
		var tag = "";
		var codeBase = 'http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0';//9,0,115,0';
		var classid = 'clsid:d27cdb6e-ae6d-11cf-96b8-444553540000';

		switch(this.isIE) {
			case true :
					tag +='<object id="globalStorage__" codebase="'+ codeBase +'" width="1" height="1" align="middle" classid="'+classid+'">';
					tag +='<param name="movie" value="http://imgcdn.pandora.tv/gimg/so/_shared.swf" />';
					tag +='<param name="quality" value="high" />';
					tag +='<param name="play" value="true" />';
					tag +='<param name="loop" value="true" />';
					tag +='<param name="scale" value="showall" />';
					tag +='<param name="wmode" value="window" />';
					tag +='<param name="devicefont" value="false" />';
					tag +='<param name="bgcolor" value="#000000" />';
					tag +='<param name="menu" value="true" />';
					tag +='<param name="allowFullScreen" value="true" />';
					tag +='<param name="allowScriptAccess" value="always" />';
					tag +='<param name="salign" value="" />';
					tag +='<embed id="globalStorage__" name="globalStorage__" width="0" height="0" src="http://imgcdn.pandora.tv/gimg/so/_shared.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" align="middle" play="true" loop="true" scale="showall" wmode="window" devicefont="false" bgcolor="#000000" menu="true" allowFullScreen="true" allowScriptAccess="always" salign="" type="application/x-shockwave-flash"></embed>';
					tag +='</object>';
			break;
			default:
					tag +='<embed id="globalStorage__" name="globalStorage__" width="0" height="0" src="http://imgcdn.pandora.tv/gimg/so/_shared.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" align="middle" play="true" loop="true" scale="showall" wmode="window" devicefont="false" bgcolor="#000000" menu="true" allowFullScreen="true" allowScriptAccess="always" salign="" type="application/x-shockwave-flash"></embed>';
			break;
		}
		
		try{ 
			document.getElementById("sharedDiv").innerHTML = tag;
		}catch(e){
			var divPanLoader = document.createElement("DIV");
			document.body.appendChild(divPanLoader);
			divPanLoader.innerHTML = '<div id="sharedDiv">'+tag+'</div>';
		}
	},


	/* public */
	setup: function(){
		/* exist Shared Object Movie */
		if(this._globalStore != null) return true;

		this._create();

		//this._globalStore = (this.isIE) ? window['globalStorage__'] : document['globalStorage__'];
		this._globalStore = document['globalStorage__'];
	},

	/** public
	* SharedObject.data[key] = value; use in Action script
	* @param {String} key
	* @param {String} value
	* @param {String} so	Shared-Object filename
	*/
	setItem : function(key, value, so) {
		var value = encodeURIComponent(value);
		return this._globalStore.setItem(key, value, so);
	},

	/** public
	 *
	 * @param {String} key
	 * @param {String} so	Shared-Object filename
	 */
	getItem : function(key, so) {
		return decodeURIComponent(this._globalStore.getItem(key, so));
	},

	/** public
	 *
	 * @param {String} key
	 * @param {String} so	Shared-Object filename
	 */
	removeItem : function(key, so) {
		return this._globalStore.removeItem(key, so);
	}
}