function Nethru_getCookieVal(offset)
{
    var endstr = document.cookie.indexOf (";", offset);
    if (endstr == -1)
        endstr = document.cookie.length;
    return unescape(document.cookie.substring(offset, endstr));
}

function Nethru_SetCookie(name, value){
   var argv = Nethru_SetCookie.arguments;
   var argc = Nethru_SetCookie.arguments.length;
   var expires = (2 < argc) ? argv[2] : null;
   var path = (3 < argc) ? argv[3] : null;
   var domain = (4 < argc) ? argv[4] : null;
   var secure = (5 < argc) ? argv[5] : false;

   document.cookie = name + "=" + escape (value) +
        ((expires == null) ? "" : ("; expires="+expires.toGMTString())) +
     ((path == null) ? "" : ("; path=" + path)) +
     ((domain == null) ? "" : ("; domain=" + domain)) +
        ((secure == true) ? "; secure" : "");

}

function Nethru_GetCookie(name){
   var arg = name + "=";
   var alen = arg.length;
   var clen = document.cookie.length;
   var i = 0;
   while (i < clen)
      {
      var j = i + alen;
      if (document.cookie.substring(i, j) == arg)
         return Nethru_getCookieVal (j);
      i = document.cookie.indexOf(" ", i) + 1;
      if (i == 0)
         break;
      }
  return null;
}

function Nethru_makePersistentCookie(name,length,path,domain)
{
    var today = new Date();
    var expiredDate = new Date(2100,1,1);
    var cookie;
    var value;

    cookie = Nethru_GetCookie(name);
    if ( cookie ) {
        return 1;
    }

    var values = new Array();
    for ( i=0; i < length ; i++ ) {
        values[i] = "" + Math.random();
    }

    value = today.getTime();

    // use first decimal
    for ( i=0; i < length ; i++ ) {
        value += values[i].charAt(2);
    }

    Nethru_SetCookie(name,value,expiredDate,path,domain);
}

var Nethru_domain  = 'pandora.tv';
Nethru_makePersistentCookie("PCID",10,"/",Nethru_domain);
Nethru_makePersistentCookie("RC",10,"/",Nethru_domain);

// 구글 코드 삽입
try {
	var googleCode = "";

	if (document.location.href.indexOf("pandora.tv/video.ptv") > -1) {
		googleCode = "UA-17291434-21";
	} else if (document.location.href.indexOf("pandora.tv/ranking") > -1) {
		googleCode = "UA-17291434-23";
	} else if (document.location.href.indexOf("http://www.pandora.tv/election2012") > -1) {
		googleCode = "UA-17291434-33";
	}else if (document.location.href.indexOf("http://www.pandora.tv") > -1) {
		googleCode = "UA-17291434-1";
	}else if (document.location.href.indexOf("http://jp.pandora.tv") > -1) {
		googleCode = "UA-17291434-1";
	}else if (document.location.href.indexOf("http://en.pandora.tv") > -1) {
		googleCode = "UA-17291434-1";
	}else if (document.location.href.indexOf("http://cn.pandora.tv") > -1) {
		googleCode = "UA-17291434-1";
	} else if (document.location.href.indexOf("http://channel.pandora.tv/channel/video.ptv") > -1) {
		googleCode = "UA-17291434-2";
	} else if (document.location.href.indexOf("http://jp.channel.pandora.tv/channel/video.ptv") > -1) {
		googleCode = "UA-17291434-2";
	} else if (document.location.href.indexOf("http://en.channel.pandora.tv/channel/video.ptv") > -1) {
		googleCode = "UA-17291434-2";
	} else if (document.location.href.indexOf("http://cn.channel.pandora.tv/channel/video.ptv") > -1) {
		googleCode = "UA-17291434-2";
	} else if (document.location.href.indexOf("/php/embed.fr1.ptv") > -1) {
		googleCode = "UA-17291434-42";
	} else if (document.location.href.indexOf("http://search.pandora.tv") > -1) {
		googleCode = "UA-17291434-3";
	} else if (document.location.href.indexOf("http://jp.search.pandora.tv") > -1) {
		googleCode = "UA-17291434-3";
	} else if (document.location.href.indexOf("http://en.search.pandora.tv") > -1) {
		googleCode = "UA-17291434-3";
	} else if (document.location.href.indexOf("http://cn.search.pandora.tv") > -1) {
		googleCode = "UA-17291434-3";
	} else if (document.location.href.indexOf("http://info.pandora.tv") > -1) {
		googleCode = "UA-17291434-4";
	} else if (document.location.href.indexOf("http://interface.pandora.tv") > -1) {
		googleCode = "UA-17291434-5";
	} else if (document.location.href.indexOf("http://groups.pandora.tv") > -1) {
		googleCode = "UA-17291434-6";
	} else if (document.location.href.indexOf("http://live.pandora.tv") > -1) {
		googleCode = "UA-17291434-7";
	} else if (document.location.href.indexOf("http://mobile.pandora.tv") > -1) {
		googleCode = "UA-17291434-8";
	} else if (document.location.href.indexOf("http://event.pandora.tv") > -1) {
		googleCode = "UA-17291434-9";
	} else if (document.location.href.indexOf("http://cupiplay.pandora.tv") > -1) {
		googleCode = "UA-17291434-10";
	} else if (document.location.href.indexOf("http://download.pandora.tv") > -1) {
		googleCode = "UA-17291434-11";
	} else if (document.location.href.indexOf("http://atv.pandora.tv") > -1) {
		googleCode = "UA-17291434-12";
	} else if (document.location.href.indexOf("http://lab.pandora.tv") > -1) {
		googleCode = "UA-17291434-13";
	} else if (document.location.href.indexOf("http://brand.pandora.tv") > -1) {
		googleCode = "UA-17291434-14";
	} else if (document.location.href.indexOf("http://blog.pandora.tv") > -1) {
		googleCode = "UA-17291434-15";
	} else if (document.location.href.indexOf("http://m.pandora.tv") > -1) {
		googleCode = "UA-17291434-16";
	} else if (document.location.href.indexOf("http://fancast.pandora.tv") > -1) {
		googleCode = "UA-17291434-18";
	} else if (document.location.href.indexOf("http://www.fancast.pandora.tv") > -1) {
		googleCode = "UA-17291434-18";
	} else if (document.location.href.indexOf("http://member.pandora.tv") > -1) {
		googleCode = "UA-17291434-25";
	} else if (document.location.href.indexOf("http://www.pandora.tv/video.ptv?c1=99") > -1) {
		googleCode = "UA-17291434-26";
	} else if (document.location.href.indexOf("http://balnews.pandora.tv") > -1) {
		googleCode = "UA-17291434-34";
	} else if (document.location.href.indexOf("http://everyon.pandora.tv") > -1) {
		googleCode = "UA-17291434-30";
	} else if (document.location.href.indexOf("http://game.pandora.tv") > -1) {
		googleCode = "UA-17291434-41";
	}

	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', googleCode]);
	_gaq.push(['_trackPageview']);

	(function() {
	var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
} catch(e) {}

// 구글 코드 삽입
try {
	var googleCode = "UA-17291434-17";

	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', googleCode]);
	_gaq.push(['_trackPageview']);

	(function() {
	var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
} catch(e) {}
