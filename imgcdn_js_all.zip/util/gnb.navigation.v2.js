	/************************************************
	*  Name              :  gnb.navigation.js
	*  Current Version   :  0.0.0.1
	*  Create by Date    :  2010-11-30
	*  Create by         :  ray.kim
	*  Last Update Date  :  2010-11-30
	*  Last Update By    :  ray.kim
	*  Description       :
	*************************************************/

	gnbNavigation = {
		_html : '',
		_infoHost : 'http://www.pandora.tv/',
		_channelHost : 'http://channel.pandora.tv/',
		_uploadHost : 'http://up.pandora.tv/',
		_apiHost : 'http://interface.pandora.tv/',
		_naviMemLang : null,
		_profileLang : null,
		_clientLang : 'ko',
		_userid : '',
		_ch_userid : '',
		_chstate : '',
		_mychannel : '',
		_setLang : function () {
			if(this.getCookie('clientLang')) this._clientLang = this.getCookie('clientLang');
			if(this.getCookie('glb_mem[userid]')) this._userid = this.getCookie('glb_mem[userid]');
			if(chInfoJson.ch_userid) this._ch_userid = chInfoJson.ch_userid;
			if(chInfoJson.chstate) this._chstate = chInfoJson.chstate;
			if(chInfoJson.mychannel) this._mychannel = chInfoJson.mychannel;

			switch (this._clientLang) {
				case "ko" :
					this._naviMemLang = ["구독시청자","우수시청자","특별시청자"];
					this._profileLang = ["프로필 보기","쪽지 보내기","홈페이지 바로가기","즐겨찾기에 추가","위젯 만들기","RSS 구독하기","선물 보내기", "채널정보 더보기","프로필","일반 채널"//0 ~ 9
										,"브랜드 채널","이름순정렬","추가순정렬","구독채널관리 바로가기","구독하기","구독회원관리","프로그램","플레이리스트","게시판","방명록"//10 ~ 19
										,"관리자","영상업로드","채널","닫기","대표이미지","채널 소개말","구독된 채널이 없습니다.","자주가는 채널을 추가해 보세요.", "받은 쪽지함","최근답글"
										,"채널 홈","쪽지","선물","이 채널을 구독하시겠습니까?", "채널을 탈퇴 하시겠습니까?", "로그인이 필요합니다. 지금 로그인 하시겠습니까?"];
				break;
				case "cn" :
					this._naviMemLang = ["登入收视会员","优秀收视会员","特别收视会员"];
					this._profileLang = ["查看简历","发送小纸条","主页","加入收藏","制造wizhe","订阅RSS","发礼物","浏览频道信息","简介（在这里交）","一般频道"//0 ~ 9
										,"品牌频道","根据名字排列","根据添加顺序排列","马上进行企业频道管理","加入","加入会员管理","节目","播放清单","公告","留言"//10 ~ 19
										,"チャンネル管理","上传视频","频道","关闭","代表形象","频道介绍","没有加入的频道请添加你经常去的频道","", "便条箱","最近的评论"
										,"我的主頁","便条","Gift", "要加入这频道吗?", "想要退出这个频道", "您需要先登录才能在目录里进行保存。现在要登录吗?"];
				break;
				case "jp" :
					this._naviMemLang = ["参加チャンネル","優秀視聴者","特別視聴者"];
					this._profileLang = ["See Profile","Send Message","Go to Homepage","Add to Favorites","Create Widgets","Subscribe to RSS Feeds","Send Presents","More Information on the Channel","Profile","General Channel"//0 ~ 9
										,"ブランドチャンネル","名前順整列","追加順整列","加入チャンネルへ","加入する","加入会員管理","プログラム","プレイリスト","掲示板","足あと"//10 ~ 19
										,"チャンネル管理","動画アップロード","チャンネル","閉じる","代表イメージ","チャンネル紹介","加入されたチャンネルがありません。","よく訪れるチャンネルを追加してみてください。", "メッセージ受信箱","最新のコメント"
										,"Home","メッセージ","Gift","上のチャンネルに加入しますか。", "チャンネルを脱会しますか?", "ログインが必要なサービスです。\nログインページへ移動しますか？"];
				break;
				default :
					this._naviMemLang = ["Subscribers","Silver Members","Gold Members"];
					this._profileLang = ["See Profile","Send Message","Go to Homepage","Add to Favorites","Create Widgets","Subscribe to RSS Feeds","Send Presents","More Information on the Channel","Profile","General Channel" //0 ~ 9
										,"Brand Channel","Sort by Title","Sort by Date","Manage My Subscribed Channels","Subscribe","Manage Viewers","Program","Playlist","Board","Guestbook" //10 ~ 19
										,"Admin","Upload Video","Channel","Close","My channel image","My channel introduction","No data found.","You can add favorite channel.", "Message Inbox","Most Recent Comments"
										,"Home","Message","Gift","Subscribe this channel?", "Unsubscribe this channel?", "You have to login to subscribe, login now?"];
				break;
			}
		},

		/* set cookie value */
		setCookie : function (sName, sValue, expireSeconds) {
			var sDomain = ".pandora.tv";
			var todayDate = new Date();
			var ExpireTime = new Date(todayDate.getTime()+expireSeconds*1000);
			document.cookie = sName + "=" + sValue + ";" + ((expireSeconds) ? "expires=" + ExpireTime.toGMTString() + ";" : "") + "domain=" + sDomain + ";path=/;";
		},

		/* get cookie value */
		getCookie : function (sName) {
			var aCookie = document.cookie.split("; ");

			for (var i=0; i<aCookie.length; i++) {
				var aCrumb = aCookie[i].split("=");
				if (sName == aCrumb[0]) {
					return aCrumb[1];
				}
			}
			return null;
		},

		// 채널구독정보
		chstate : function () {
			var join_mem = '';

			switch(this._chstate){
				case "10001":
					join_mem = '<a class="btn_ch_join">' + this._naviMemLang[0] + '</a>';		//"구독시청자";
					break;

				case "10002":
					join_mem = "<a class='btn_ch_join'>" + this._naviMemLang[1] + "</span></a>";		//"우수시청자";
					break;

				case "10003":
					join_mem = "<a class='btn_ch_join'>" + this._naviMemLang[2] + "</span></a>";		//"특별시청자";
					break;

				default:
					join_mem = '<a class="btn_ch_join" href="javascript:chJoin();">' + this._profileLang[14] + '</a>';
					break;
			}
		/*	
			if( this._mychannel != 1 && this._chstate == chInfoJson.upload_pub )
				join_mem += "<a href='" + this._uploadHost + "/channel/upload.ptv?ch_userid=" + this._ch_userid + "' class='btn_ch_join'>이 채널에 업로드</a>";
		*/
			if(this._mychannel == 1) join_mem = "<a href='" + this._channelHost + "/manager/?ch_userid=" + this._userid + "&menu=audience' class='btn_ch_join'>" + this._profileLang[15] + "</a><a href='" + this._channelHost + "/manager/?ch_userid=" + this._userid + "' class='btn_ch_join'>관리자</a>";

			return join_mem;
		},

		getMusician : function (obj) {
			switch(obj) {
				case "20001":
					musician = 'chTendency_Producer';
					break;
				case "20002":
					musician = 'chTendency_Musician';
					break;
				case "20003":
					musician = 'chTendency_Comedian';
					break;
				case "20004":
					musician = 'chTendency_Dancer';
					break;
				case "20005":
					musician = 'chTendency_Gamer';
					break;
				case "20006":
					musician = 'chTendency_Animania';
					break;
				case "20007":
					musician = 'chTendency_Sportsman';
					break;
				case "20008":
					musician = 'chTendency_Reporter';
					break;
				case "20009":
					musician = 'chTendency_Livecaster';
					break;
				case "20010":
					musician = 'chTendency_Premium';
					break;
				case "20011":
					musician = 'chTendency_SBS';
					break;
			}

			return musician;
		},

		// 즐겨찾기 추가
		favorite : function () {
			var addthis_title = chInfoJson.chname + " " + chInfoJson.meta_title;
			addthis_title = addthis_title.replace(/\^/g, " ");
			var addthis_url = "http://www.pandora.tv/my." + this._ch_userid;

			addthis_url = decodeURIComponent(addthis_url);
			addthis_title = decodeURIComponent(addthis_title);
			if (document.all) window.external.AddFavorite(addthis_url,addthis_title);
			else window.sidebar.addPanel(addthis_title,addthis_url,'');
		},

		draw : function (target, menu) {
			this._setLang();

			if(chInfoJson.hompyUrl){
				var urlHtml = chInfoJson.hompyUrl.split("http://");

				if(!urlHtml[1]){
					var hompyUrl = "http://" + chInfoJson.hompyUrl;
				} else {
					var hompyUrl = chInfoJson.hompyUrl;
				}

				var newhomeURL = hompyUrl;
			}

			if ( chInfoJson.chnameLink && chInfoJson.chnameLink != "http://" ){
				var chNameLink = '<a href="'+chInfoJson.chnameLink+'" target="_blank" style="overflow: hidden; position: relative; width: 580px; font-size: 24px; font-weight: bold; letter-spacing: -1px;">'+ chInfoJson.chname +'</a>';
			} else {
				var chNameLink =  chInfoJson.chname ;
			}
			
			this._html += '	<div class="section_profile ' + ( chInfoJson.ch_type == "20001" ? 'ty_medal' : '' ) + '">';
			if( chInfoJson.ch_type != 0 )
				this._html += '		<div class="profile_medal"><img src="http://imgcdn.pandora.tv/ptv_img/newptv/ico_' + chInfoJson.ch_type + '.png" alt="테마채널"></div>';
			this._html += '		<div class="profile_img"><img class="profile" src="' + chInfoJson.logobase + '" onerror="javascript:imgError(this,\'http://imgcdn.pandora.tv/static/newprg_thumb.gif\');" width="45" height="45"></div>';
			this._html += '		<dl>';
			this._html += '			<dt style="display:block;">' + chNameLink + '</dt>';
			this._html += '			<dd class="id">' + chInfoJson.nickname + '</dd>';
			this._html += '			<dd class="info"><a ' + ((this._mychannel == 1) ? 'href="' + this._channelHost + 'manager/?ch_userid=' + this._userid + '&menu=rMemoList&page=1"' : 'href="javascript:gMemoFunc(event, \'' + this._ch_userid + '\');"' ) + '>쪽지' + ((this._mychannel == 1) ? '(' + chInfoJson.new_msg_cnt + ')' : '') + '</a></dd>';
		if( navigator.userAgent.toLowerCase().indexOf('chrome') < 0 ){
			this._html += '			<dd class="info"><a href="javascript:gnbNavigation.favorite();">즐겨찾기 추가</a></dd>';
		}
		if(this._mychannel == 1) {
		//	this._html += '			<dd class="info"><a href="' + this._channelHost + 'manager/?ch_userid=' + this._userid + '">관리자</a></dd>';
		}
			this._html += '		</dl>';
			this._html += '	</div>';
			
			this._html += '	<div class="nav_ch">';
			this._html += '		<a href="/channel/?ch_userid=' + this._ch_userid + '" class="ch_btn ' + ( ( menu == 'home' )?'active':'' ) + '"> ' + this._profileLang[30] + '</a>';
			this._html += '		<a href="/channel/video.ptv?ch_userid=' + this._ch_userid + '" class="ch_btn ' + ( ( menu == 'program' )?'active':'' ) + '">' + this._profileLang[16] + '</a>';
			this._html += '		<a href="/channel/playlist.ptv?ch_userid=' + this._ch_userid + '" class="ch_btn ' + ( ( menu == 'playlist' )?'active':'' ) + '">' + this._profileLang[17] + '</a>';
			this._html += '		<a href="/channel/board.ptv?ch_userid=' + this._ch_userid + '" class="ch_btn ' + ( ( menu == 'board' )?'active':'' ) + '">' + this._profileLang[18] + '</a>';
			this._html += '		<a href="/channel/guest.ptv?ch_userid=' + this._ch_userid + '" class="ch_btn ' + ( ( menu == 'guest' )?'active':'' ) + '">' + this._profileLang[19] + '</a>';

			if ( this._ch_userid == "live_gg" || this._ch_userid == "live_seoul" ) //2014.09.03 live 섹션 히든처리 (경기도, 서울시 채널은 제외)
			{
				this._html += '		<a href="/channel/video.ptv?ch_userid=' + this._ch_userid + '&liv=lv" class="ch_btn ' + ( ( menu == 'live' )?'active':'' ) + '">LIVE</a>';
			}
			
			this._html += '		<div class="nav_ch_rgt">' + this.chstate() + '</div>';

			if( chInfoJson.chLive_of == "on" ){
				this._html += '		<div class="live_on" id="liveIcon"><img src="http://imgcdn.pandora.tv/ptv_img/newptv/ch/liveOn_txt.gif" alt="on air" /></div>';
			}
			this._html += '	</div>';

	//		var strUploadurl = ( this._userid ) ? this._uploadHost + 'channel/upload.ptv?ch_userid=' + this._ch_userid : "javascript:newUploadLogin();";
			var strUploadurl = ( this._userid ) ? "javascript:VodUpFn.viewFn(1, '" + this._ch_userid + "');": "javascript:newUploadLogin();";

				

			if( chInfoJson.upload_pub == "10005" ){
	//			this._html += '<a class="btn_echup" href="' + strUploadurl + '">이 채널에 업로드</a>';
				this._html += '<a class="btn_copyup0529" href="' + strUploadurl + '"><img align="테마 채널에 내 동영상 올리기" src="http://imgcdn.pandora.tv/ptv_img/newptv/btn_ch_upload.jpg"/></a>';
			}else{
				this._html += '<div class="new_adsambox02" id="new_adsambox02"></div>';
			}
			




			try {
				jQuery("#" + target).html(this._html);
			}
			catch (e) {}


			if( chInfoJson.upload_pub != "10005" ){
		//		console.log('222');
				// 광고 임시 주석처리 by 한욱 2013-06-13
				//loadJs.loadJS("http://ads.pandora.tv/NetInsight/text/pandora/pandora_channel/main@channel_right");
			}


		}
	}

	function newUploadLogin(){
		if(confirm('로그인 후 동영상 업로드가 가능합니다.\n로그인 하시겠습니까?')){
			LoginAction.Login();
		}
	}

	function leadingZeros(n, digits) {
		var zero = '';
		n = n.toString();

		if (n.length < digits) {
		for (i = 0; i < digits - n.length; i++)
			zero += '0';
		}

		return zero + n;
	}
	
	/* 채널 구독 및 탈퇴 Start */
	function chJoin() {
		if(gnbNavigation.getCookie('glb_mem[userid]')) {
			if (confirm(gnbNavigation._profileLang[33])) {
				var obj = jQuery.toJSON({'ch_userid':chInfoJson.ch_userid, 'login_userid':gnbNavigation.getCookie('glb_mem[userid]')});
				jQuery.ajax({
					type : 'post',
					url : "/json/v003/GAccount.dll/Join",
					data : {'json':obj},
					dataType : 'json',
					success : function(res) {
						var msg = "";
						//success
						if (res.IsRes == 1) {
							location.reload();
						// fail
						} else {
							switch (res.IsCode) {
								case 1 :
									msg = "";//"로그인을 하셔야 합니다.";joinLang[4]
									break;
								case 2 :
									msg = "";//"이미 구독된 채널 입니다.";joinLang[5]
									break;
								default :
									msg = "";//"다시 한번더 시도 해 주십시요";joinLang[6]
									break;
							}
						}

					},
					exception : function(res){
						throw new Error("Exception : channel join fail");
					}
				});
			}
		} else {
			if (confirm(gnbNavigation._profileLang[35])) { //joinLang[4]); // '로그인을 먼저 하셔야 합니다. 지금 로그인 하시겠습니까?');
				//gnbTop.ptvLogin('login');
				LoginAction.Login();
			}
		}
	}

	function chOut() {
		// login check
		if(gnbNavigation.getCookie('glb_mem[userid]')) {
			if (confirm(gnbNavigation._profileLang[34])) {
				var obj = jQuery.toJSON({'ch_userid':chInfoJson.ch_userid, 'login_userid':gnbNavigation.getCookie('glb_mem[userid]')});

				jQuery.ajax({
					type : 'post',
					url : "/json/v003/GAccount.dll/Out",
					data : {'json':obj},
					dataType : 'json',
					success : function(res) {
						var msg = "";
						//success
						if (res.IsRes == 1) {
							location.reload();
						// fail
						} else {
							switch (res.IsCode) {
								case 1 :
									msg = ""; // "로그인을 하신후 탈퇴가 가능 합니다.";outLang[1]
									break;
								case 2 :
									msg = ""; // "이미 구독된 채널 입니다.";outLang[2]
									break;
								default :
									msg = ""; // "다시 한번더 시도 해 주십시요";outLang[3]
									break;
							}
						}

					},
					exception : function(res){
						throw new Error("Exception : channel join fail");
					}
				});
			}
		}
	}
	/* 채널 구독 및 탈퇴 End */

var VodUpFn = {
	_page : 1,
	_totpage : 0,
	_categ_id :'' ,
	viewFn : function (goPage, ch_userid){
		var schWord = jQuery("input[name='schVodWord']").val();
		this._page = 1;
		jQuery.ajax({
			type : 'get',
			url : "../channel_v1/video.ptv?m=getVodCopy",
			data : {'page':parseInt(1, 10), 'ch_userid':ch_userid, 'schWord':schWord},
			dataType : 'html',
			success : function(res) {
				//success
				jQuery("#Layer").html("");
				if (res) {
					jQuery("#Layer").css({"left":"0px", "top":"0px", "height":"100%", "display":"block"});
				//	console.log("Layer : " + jQuery("#Layer").html());
					jQuery("#Layer").html(jQuery("#Layer").html() + res);
					jQuery(".videocopy_pop").css({"left":"250px", "top":"150px"});
					
					VodUpFn.vodListFn(ch_userid);

					window.onscroll = function(){					
						var x = ((jQuery(window).width() - 600) / 2) + jQuery(window).scrollLeft() -500;
						var y = ((jQuery(window).height() - 600) / 2) + jQuery(window).scrollTop() - 150;
						x = 0;
						jQuery("#Layer").css({"top":y+"px","left":x+"px"});
					};
				// fail
				} else {
					//alert("json Error");
				}
			},
			exception : function(res){
				throw new Error("Exception : my vod list fail");
			}
		});
	}, 

	chkprgAll : function (){
		var chkprgall = jQuery("#chkprgall").prop("checked");
		
			var chk_len =document.getElementsByName("chkprg").length
			for (var i=0;i<chk_len ;i++ ){
				document.getElementsByName("chkprg")[i].checked = chkprgall;
			}
		
	},


	viewCancel : function (){
		jQuery("#Layer").html("");
		jQuery("#Layer").css({"display":"none"});
	}, 

	vodSaveFn : function (){

		var tar_userid = jQuery("input[name='tar_userid']").val();
		var tmpCategCode = jQuery("select[name='cagegCode']").val();

		var tmpArrCategCode = tmpCategCode.split("|");
		var tar_categid = tmpArrCategCode[1];
		var tar_par_categid = tmpArrCategCode[0];

		var org_info = new Array();
		var chkCnt = jQuery("input[name='chkprg']:checked").length > 0 ? jQuery("input[name='chkprg']:checked").length : 0;

		for( var i = 0; i < chkCnt; i++ ){
			org_info[i] = new Array();
			org_info[i][0] = gnbNavigation.getCookie('glb_mem[userid]');
			org_info[i][1] = jQuery(jQuery("input[name='chkprg']:checked")[i]).val();
		}

		if( chkCnt > 0 ){	
			var submitFrm = document.createElement("form");
			submitFrm.name = "ifrm";
			submitFrm.id = "ifrm";
			submitFrm.method = "post";

			jQuery("#ifrm").remove();

			document.body.appendChild(submitFrm);

			var jsonStr = jQuery.toJSON({"tar_userid":tar_userid,"tar_categid":tar_categid,"tar_par_categid":tar_par_categid,"org_info":org_info,"req_mode":"1"});
			jQuery("#ifrm").append("<input type='hidden' name='json' value='" + jsonStr + "'>");

			jQuery("#ifrm").attr("action", "http://up.pandora.tv/json/v003/GPFileUpLoadCopy.dll");
			jQuery("#ifrm").attr("target", "vodCopyIfr");
			jQuery("#ifrm").submit();
			jQuery('#upload_txt').css('display','block');
			alert('정상 요청되었습니다.');
		}else { alert('선택된 영상이 없습니다.'); }
	},

	vodListFn : function (ch_userid){

		var schWord = jQuery("input[name='schVodWord']").val();
		var pageNum = ( this._page <= 0 )? 1 : this._page++;
		var now_cate = jQuery("select[name='mycagegCode']").val().split("|");

	
		//	alert(now_cate[1]);
		//	alert(this._categ_id);
		if (this._categ_id !=now_cate[1]  ){
			this._page = 1;
			pageNum =1;

			this._categ_id=now_cate[1];	
			//alert(this._categ_id);

			jQuery.ajax({
				type : 'get',
				url : "../channel_v1/video.ptv?m=getVodCodyList",
				data : {'page':parseInt(pageNum, 10), 'ch_userid':ch_userid, 'schWord':schWord  ,'categ_id':this._categ_id},
				dataType : 'html',
				success : function(res) {
					//success
					if (res) {
						jQuery("#CopyVodList").html("");
						jQuery("#CopyVodList").html(res);
						//console.log("page = " + VodUpFn._page);
					// fail
					} else {
						//alert("json Error");
					}
					if( VodUpFn._totpage <= pageNum ){
						jQuery(".vp_more").hide();
					}
				},
				exception : function(res){
					throw new Error("Exception : my vod list fail");
				}
			});
		}else{
			//alert(pageNum);
			jQuery.ajax({
				type : 'get',
				url : "../channel_v1/video.ptv?m=getVodCodyList",
				data : {'page':parseInt(pageNum, 10), 'ch_userid':ch_userid, 'schWord':schWord  ,'categ_id':this._categ_id},
				dataType : 'html',
				success : function(res) {
					//success
					if (res) {
						jQuery("#CopyVodList").append(res);
					//	console.log("page = " + VodUpFn._page);
					// fail
					} else {
						//alert("json Error");
					}

					if( VodUpFn._totpage <= pageNum ){
						jQuery(".vp_more").hide();
					}
				},
				exception : function(res){
					throw new Error("Exception : my vod list fail");
				}
			});		
		}



	},
	
	vodSaveResultFn : function (vres){
		//vres = eval(vres);
		//console.log(vres);
		if( vres.res == "SUCC" ){
			alert('정상적으로 처리 되었습니다.');
			jQuery('#upload_txt').css('display','none');
			this.viewCancel();
			location.href = "/channel/video.ptv?ch_userid=" + chInfoJson.ch_userid;
		}else{
		//	console.log(vres);
			alert('Copy Error : ' + vres.res + ', PrgID : ' + vres.prgid);
			this.viewCancel();
		}
	}
}
