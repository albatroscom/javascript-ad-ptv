	////////////////////////////////////////////////////////
	/* icf(확장, 일반, 쉐이크) 광고 관련 함수들 */
	var exticfPlay = false;
	var extConf = "";
	var exicf = "";
	var extIcfSet = "";
	var extIcfJson = {};

	/* 공유창 일시 정지 기능 때문에 추가 된 변수 */
	var play_ing = false;
	var share_ing = false;
	var start_ing = false;

	var movieCenterAd = false;
	var adSettime = "";
	var skipBtn = "";
	var skipTxt = "";

	var newIcfCountDownTime = 15;
	var newIcfCountDownObj = 0;
	var divTopSize = '60px';

	function startPlay() { playerSet.startPlay();}

	function extendIcfAction(json) {
		if (exticfPlay == true) {
			playerSet.startPlay();
			return;
		}

		try { clearTimeout(playerSet._adStart); } catch(e) {}
		try { clearTimeout(extConf); } catch(e) {}

		extIcfJson = json;

		try { jQuery(".admov").css("display", "block"); } catch(e) {}
		if (json["coupleKey"]) {
			$(document).ready(
				function() { loadJsClass.loadJS("http://ads.pandora.tv/NetInsight/text/pandora/pandora_channel/main@cn_top?martial=" + json["coupleKey"]);} 
			);
		}

		if (json["topAdInfo"]) {
			try {
				document.getElementById("topAdCouple").innerHTML = "<div style=\"background-color: " + json["topAdInfo"]["imgbackground-color"] + " ;overflow: hidden;\"><a href=\"" + json["topAdInfo"]["clickUrl"] + "\" target=\"_blank\" onfocus=\"blur()\"><img src=\"" + json["topAdInfo"]["imgUrl"] + "\" width=\"" + json["topAdInfo"]["imgWidth"] + "\" border=\"0\" style=\"display: block;margin: " + json["topAdInfo"]["imgAlign"] + ";max-width: " + json["topAdInfo"]["imgmax-width"] + ";\"></a></div>";
			} catch(e) {
			}
		}

		switch (json["kind"].toString()) {
			case "1" : // 일반 icf 광고 (icfDiv) flv만 할것임
				//alert('일반 icf 시작 , ' + json["exticfurl"]);
				if (json["exticfurl"]) {
					jQuery("#psh_top").css({"z-index":"1"});
					var html = playerSet.getAdPlayer('videoURL='+encodeURIComponent(json["exticfurl"])+'&clickthru='+ encodeURIComponent(json["clickUrl"]), 'exicf', 'icf');
					jQuery("#flvIcf").css({"top":"0px","left":"0px",'height':'390px','width':'640px', 'border-top':'0px solid #ffffff','border-bottom':'0px solid #ffffff'});
					jQuery("#flvIcf").html(html);
					jQuery("#flvIcf").show();
				} else {

					playerSet.startPlay();
				}
			break;
/*
			case "2" : // 2012이전 확장 icf 광고 (flvIcf)
				//alert('확장 icf 시작 , ' + json["exticfurl"]);
				// player pause는 플레이어에서 pause 하고 던저 준다.
				if (json["exticfurl"]) {
					var swfVal = json["exticfurl"] + '?lang='+chInfoJson['clientLang']+'&clickthru='+ encodeURIComponent(json["clickUrl"]);
					var html = playerSet.getAdPlayer(swfVal, 'exicf');

					jQuery("#flvIcf").css({'text-align': 'center', 'position': 'absolute', 'top': '-15px', 'left': '0px', 'height': '390px', 'z-index': '899','width': '980px', 'border':'none', 'border-top':'15px solid #ffffff','border-bottom':'15px solid #ffffff'});
					jQuery("#flvIcf").html(html);
					jQuery("#flvIcf").show();
				} else {
					playerSet.playerSet.startPlay();
				}
			break;
*/

			case "2" : // 확장 icf 광고 (flvIcf)
				//alert('확장 icf 시작 , ' + json["exticfurl"]);
				// player pause는 플레이어에서 pause 하고 던저 준다.
				if (json["exticfurl"]) {
					jQuery("#psh_top").css("z-index", "3");
					jQuery("#watch-video").css("z-index", "999");
					var html = playerSet.getAdPlayer('videoURL='+encodeURIComponent(json["exticfurl"]) + '&clickthru='+ encodeURIComponent(json["clickUrl"]) + '&imageURL=' + encodeURIComponent(json["rightadurl"]), 'exicf', 'icf');
					
					//jQuery("#flvIcf").css({'text-align': 'center', 'position': 'absolute', 'top': '-15px', 'left': '0px', 'height': '390px', 'z-index': '899','width': '980px', 'border':'none', 'border-top':'15px solid #ffffff','border-bottom':'15px solid #ffffff'});
					jQuery("#flvIcf").css({'text-align': 'center', 'position': 'absolute', 'top': '0px', 'left': '0px', 'height': '390px', 'z-index': '899','width': '980px', 'border':'none'});
					jQuery("#flvIcf").html(html);
					jQuery("#flvIcf").show();
				} else {
					playerSet.startPlay();
				}
			break;

			case "3" : // 쉐이크 icf 광고 (shakeIcf)
				if (json["exticfurl"]) {
					playerSet._icfCnt = 1;
					var html = playerSet.getAdPlayer(json["exticfurl"] + '?clickthru='+ encodeURIComponent(json["clickUrl"]), 'exicf');
					jQuery("#flvIcf2").html(html);

					if(json["width"]) jQuery("#flvIcf2").css({"width":json["width"]+"px"});
					else jQuery("#flvIcf2").css({"width":"980px"});

					if(json["height"]) jQuery("#flvIcf2").css({"height":json["height"]+"px"});
					else jQuery("#flvIcf2").css({"height":"880px"});
					jQuery("#flvIcf2").show();
				} else {
					playerSet.startPlay();
				}
			break;

			case "5" : // 빈광고 바로 플레이
				//var html = playerSet.getAdPlayer('http://imgcdn.pandora.tv/gplayer/icf_player_google.swf?lang='+chInfoJson['clientLang']+'&prgid=', 'exicf');
				jQuery("#psh_top").css({"z-index":"1"});
				var html = playerSet.getAdPlayer('http://imgcdn.pandora.tv/gplayer/newPlayer_2012/GoogleIMA_Player.swf?lang='+chInfoJson['clientLang']+'&prgid=', 'exicf');
				jQuery("#flvIcf").css({"top":"0px","left":"0px",'height':'390px','width':'640px', 'border-top':'0px solid #ffffff','border-bottom':'0px solid #ffffff'});
				jQuery("#flvIcf").html(html);
				jQuery("#flvIcf").show();
			break;

			case "8" : // real click
				try { $(".bar").stop(); } catch(e) {}
				jQuery("#psh_top").css({"z-index":"1"});
				jQuery("#flvIcf").css({"top":"0px","left":"0px",'height':'390px','width':'640px', 'border-top':'0px solid #ffffff','border-bottom':'0px solid #ffffff', 'background-color':'#000000'});
				jQuery("#flvIcf").html('<table align="center" width="100%"><tr><td style="padding-top:23px;padding-left:0px;"><iframe src="http://ads.realclick.co.kr/ad_headcopy/pandora4_b1.html" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" topmargin="0" leftmargin="0" allowtransparency="true" width="310" height="300"></iframe></td></tr></table><div class="ad_anibox"><!-- 진행바 초기는 left:-644px; 100%는 left:-28px; --><div style="left:-644px;" class="bar"></div><a class="btn_skip" style="display:none;"><span class="blind">skip</span></a></div>');
				jQuery("#flvIcf").show();

				// 스킵 없이 7초 
				adSettime = setTimeout ( function(){
					playerSet.startPlay();
				},7000);

				// 스킵 없이 7초 
				$(".bar").animate({left: '+=630px'}, 7000, 'linear');
			break;

			case "18" : // 나스미디어 2012-02-22
				try { $(".bar").stop(); } catch(e) {}
				jQuery("#psh_top").css({"z-index":"1"});
				jQuery("#flvIcf").css({"top":"0px","left":"0px",'height':'390px','width':'640px', 'border-top':'0px solid #ffffff','border-bottom':'0px solid #ffffff', 'background-color':'#000000'});
				jQuery("#flvIcf").html('<table align="center" width="100%"><tr><td style="padding-top:23px;padding-left:0px;"><iframe src="' + json["exticfurl"] + '" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" topmargin="0" leftmargin="0" allowtransparency="true" width="310" height="300"></iframe></td></tr></table><div class="ad_anibox"><!-- 진행바 초기는 left:-644px; 100%는 left:-28px; --><div style="left:-644px;" class="bar"></div><a class="btn_skip" style="display:none;"><span class="blind">skip</span></a></div>');
				jQuery("#flvIcf").show();

				// 스킵 없이 7초 
				adSettime = setTimeout ( function(){
					playerSet.startPlay();
				},7000);

				// 스킵 없이 7초 
				$(".bar").animate({left: '+=630px'}, 7000, 'linear');
			break;

			case "19" : // 이미지 2012-02-22
				try { $(".bar").stop(); } catch(e) {}
				jQuery("#psh_top").css({"z-index":"1"});
				jQuery("#flvIcf").css({"top":"0px","left":"0px",'height':'390px','width':'640px', 'border-top':'0px solid #ffffff','border-bottom':'0px solid #ffffff', 'background-color':'#000000'});
				jQuery("#flvIcf").html('<div><a href="' + json["clickUrl"] + '" target="_blank"><img src="' + json["exticfurl"] + '" /></a></div><div class="ad_anibox"><!-- 진행바 초기는 left:-644px; 100%는 left:-28px; --><div style="left:-644px;" class="bar"></div><a class="btn_skip" style="display:none;"><span class="blind">skip</span></a></div>');
				jQuery("#flvIcf").show();

				// 스킵 없이 7초 
				adSettime = setTimeout ( function(){
					playerSet.startPlay();
				},7000);

				// 스킵 없이 7초 
				$(".bar").animate({left: '+=630px'}, 7000, 'linear');
			break;

			case "21" : // 일반형 icf 시리즈 광고
				jQuery("#psh_top").css({"z-index":"1"});
				if (json["exticfurl"]) {
					var html = playerSet.getAdPlayer('videoURL='+encodeURIComponent(json["exticfurl"]) + '&clickthru='+ encodeURIComponent(json["clickUrl"]) + '&flvParam1=' + encodeURIComponent(jQuery.toJSON(json["flvParam1"])) + '&flvParam2=' + encodeURIComponent(jQuery.toJSON(json["flvParam2"])) + '&flvParam3=' + encodeURIComponent(jQuery.toJSON(json["flvParam3"])) + '&flvParam4=' + encodeURIComponent(jQuery.toJSON(json["flvParam4"])), 'exicf', 'icf');

					jQuery("#flvIcf").css({"top":"0px","left":"0px",'height':'390px','width':'640px', 'border-top':'0px solid #ffffff','border-bottom':'0px solid #ffffff'});
					jQuery("#flvIcf").html(html);
					jQuery("#flvIcf").show();
				} else {
					playerSet.startPlay();
				}
			break;

			case "22" : // 일반형 icf 시리즈 광고
//				playerSet.startPlay();
				jQuery("#psh_top").css({"z-index":"1"});
				if (json["exticfurl"]) {
					var ccd = '00';
					try {
						if( dawinCateCode ) {
							ccd = dawinCateCode;
						} else {
							ccd = '00';
						}
					} catch(e) {
						//console.log(e);
					}

					//document.getElementById("adcheck_icast").src="http://i80.icast-ad.com/imp?ccd=680&scd=1778&acd=5891&tid=1&mcd=01040601&type=02120201";
					//document.getElementById("adcheck_icast").src="http://ads.pandora.tv/NetInsight/click/pandora/pandora_channel/main@data_dawin?cmpnno%3D1577%26adsno%3D7%26locno%3D686%26ctvno%3D7977%26clkno%3D7534";
					
					var _playUrl = '';
					//_playUrl += 'http://imgcdn.pandora.tv/gplayer/AdsRequest.swf';
					_playUrl += 'http://vplayer.dawin.tv/pandora/AdsRequest.swf';
					_playUrl += '?gcd=01040100';
					_playUrl += '&mcd=85';
					_playUrl += '&pcd=1';
					_playUrl += '&scd=02020201';
					_playUrl += '&ccd='+ccd;
					_playUrl += '&js=yes';
					_playUrl += '&adWidth=640';
					_playUrl += '&adHeight=360';
					_playUrl += '&volume=70';
					
					var html = playerSet.getAdPlayer(_playUrl, 'exicf', 'Dicf');
					
					jQuery("#flvIcf").css({"top":"0px","left":"0px",'height':'390px','width':'640px', 'border-top':'0px solid #ffffff','border-bottom':'0px solid #ffffff', 'background-color':'#EEEEEE'});
					jQuery("#flvIcf").html(html);
					jQuery("#flvIcf").show();
					jQuery("#log").attr("src", "http://log.sv.pandora.tv/icfad2?mode=" + ( playby_channel == "www" ? "2" : "1" ));
				} else {
					playerSet.startPlay();
				}
			break;

/////////////////////////////////////////////////////////////////////// 일본 추가
			case "25" : // 일본 ICF ub 광고 추가 2013-12-03
				jQuery("#psh_top").css({"z-index":"1"});

				$("#flvIcf").show();
				//alert("ssp_icf");
				$("#flvIcf").html('<div id="icfDivLayer" style="text-align:center;padding-top:'+divTopSize+';" width="100%"><table style="width:100%;"><tr><td><img src="http://imgcdn.pandora.tv/pan_img/event/k1_img/del.gif" onClick="extendIcfClear();" style="cursor:pointer;"><IFRAME FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO WIDTH=300 HEIGHT=250 SRC="http://www.pandora.tv/adver.adingo.ptv?adType=icf_ub_01"></IFRAME></td></tr></table></div>');

				setTimeout ( function(){
					extendIcfClear();
				},7000);
			break;

			case "30" : // 판도라 신규 icf 광고
				if (chSamrtCheck == "1") {
					if (vodPlayOk == true) //영상 재생중임
					{
						return;
					}

					clearTimeout(extIcfLoad);

					console.log("exticfJson Call :: 1");
					eventClass.adPandora(extIcfJson);

				} else {
					/* smith.oh 2014-04-23 추가 추후에 .playerSet.getAdPlayer를 수정 해야 할것임*/
					if (json["adSkip"] == "p" || json["adSkip"] == "all") {
						playerSet.startPlay();
						return;
					}
					/*
					var argRegexS = "[\\?|&]debug="
					var argRegex = new RegExp( argRegexS );  
					var argResult = argRegex.exec( window.location.href ).split(",");
					alert(argResult);
					var argResults = argResult.toString().split(",");
					alert(results[0]);
					*/
					var objName = "myContent";
					var swfUrl	= "http://imgcdn.pandora.tv/gplayer/PtvIcf.swf";
					var _playObj = "";
					if(navigator.userAgent.toLowerCase().indexOf("msie") != -1) {
						_playObj += '<object id="'+objName+'" style="visibility:visible" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,2,0,0" width="640" height="390" align="middle" type="application/x-shockwave-flash" data="' + swfUrl + '" >';
						_playObj += '<param name="movie" value="' + swfUrl + '" />';
						_playObj += '<param name="flashvars" value="dataObject=' + encodeURIComponent(JSON.stringify(json)) + '" />';
						_playObj += '<param name="bgcolor" value="#000000" />';
						_playObj += '<param name="quality" value="high" />';
						_playObj += '<param name="scale" value="noScale" />';
						_playObj += '<param name="wmode" value="direct" />';
						_playObj += '<param name="allowFullScreen" value="true" />';
						_playObj += '<param name="allowScriptAccess" value="always" />';
						_playObj += '</object>';
					} else {
						_playObj += '<embed name="'+objName+'" id="'+objName+'" style="visibility:visible" pluginspage="http://www.macromedia.com/go/getflashplayer" width="640" height="390" align="middle"';
						_playObj += 'src="'+swfUrl+'"';
						_playObj += 'flashvars="dataObject=' + encodeURIComponent(JSON.stringify(json)) + '"';
						_playObj += 'quality="high"';
						_playObj += 'play="true"';
						_playObj += 'loop="true"';
						_playObj += 'scale="noScale"';
						_playObj += 'wmode="transparent"';
						_playObj += 'devicefont="false"';
						_playObj += 'bgcolor="#000000"';
						_playObj += 'menu="true"';
						_playObj += 'allowFullScreen="true"';
						_playObj += 'allowScriptAccess="always"';
						_playObj += 'salign="T" type="application/x-shockwave-flash">';
						_playObj += '</embed>';
					}
					jQuery("#flvIcf").html(_playObj);
					jQuery("#flvIcf").css({"background":"#000000"});
					jQuery("#flvIcf").show();
					console.log(_playObj);
				}
			break;

			case "100" : // 구글광고
				jQuery("#psh_top").css({"z-index":"1"});

				var divTopSize = '60px';

				$("#flvIcf").show();
				//alert("ssp_icf");
				$("#flvIcf").html('<div id="icfDivLayer" style="text-align:center;padding-top:'+divTopSize+';" width="100%"><table style="width:100%;"><tr><td><img src="http://imgcdn.pandora.tv/pan_img/event/k1_img/del.gif" onClick="extendIcfClear();" style="cursor:pointer;"><IFRAME FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO WIDTH=300 HEIGHT=250 SRC="http://www.pandora.tv/adver.adingo.ptv?adType=icf_ub_01"></IFRAME></td></tr></table></div>');

				setTimeout ( function(){
					extendIcfClear();
				},7000);
/*	당장에 구글 광고 아직 안나옴 차후에 교체
				jQuery("#psh_top").css({"z-index":"1"});
				var html = flashHtml('videoURL='+encodeURIComponent(json["exticfurl"])+'&playertype=jpchannel&clickthru='+ encodeURIComponent(json["clickUrl"]), 'exicf', 'icf');
				$("#flvIcf").show();
				setTimeout(function () {$("#flvIcf").html(html);}, 10);
*/
			break;

			default : // 아무값이 없을 경우 그냥 플레이 하도록 한다. (ray.kim-2011-01-03)
				playerSet.startPlay();
			break;
		}

		if(json["kind"].toString() != "21" && json["kind"].toString() != "") {
			try {/* rt >= 15*60*/
				if ( json["kind"].toString() != "3") {
					$("#icfNoticeDiv").show();
					var nimgsrc = 'http://imgcdn.pandora.tv/ptv_img/newptv/info_ad_after.png';
					
					if (playby_channel == "www"){
						if ( parseInt(rt, 10) >= parseInt(playby_time*60 , 10 )*1000 ) {
							nimgsrc = 'http://imgcdn.pandora.tv/ptv_img/newptv/info_ad_after' + playby_cnt + '.png';
						}
					}else{
						if ( parseInt(rt, 10) >= parseInt(playby_time*60, 10) ) {
							nimgsrc = 'http://imgcdn.pandora.tv/ptv_img/newptv/info_ad_after' + playby_cnt + '.png';
						}
					}

					$("#icfNoticeDiv").html('<img class="dsc2" src="' + nimgsrc + '" alt="광고 후 영상이 재생됩니다." />');
				}
			} catch(e) {console.log(e)}
		}

		try {
			if (json["checkUrl"]) adCheck(json["checkUrl"]);
		} catch(e) {}
	}

	function newIcfCountDown( runtime ) {

		if ( isNaN(runtime) == false )
		{
			runtime = Math.round(runtime);

			if (runtime > 15) {
				runtime = 15;
				skipTxt = "초 후 광고 SKIP이 가능합니다.";
			} else {
				skipTxt = "초 후 영상이 재생됩니다.";
			}

			$("#icfNoticeDiv").html('<span style="font-weight:bold;"><span id="icfTimeZone">15</span>'+skipTxt+'</span>');
			$("#icfNoticeDiv").show();

			newIcfCountDownObj = setInterval(function() { 
				if (runtime > 1) {
					runtime = runtime - 1;
					$("#icfTimeZone").html(runtime);
				} else {
					clearInterval(newIcfCountDownObj);
					$("#icfNoticeDiv").hide();
				}
			}, 1000);
		}
	}

	function extendIcfClear() {
		clearInterval(adSettime);
		clearInterval(skipBtn);
		playerSet.startPlay();
	}

	// 플로팅 광고(확장광고 완료 후 호출)
	function extIcfFloatAd() {
		if (extIcfJson["kind"] == "2" && extIcfJson["floatadurl"]) {
			var html = playerSet.getAdPlayer(extIcfJson["floatadurl"] + '?clickthru='+ encodeURIComponent(extIcfJson["clickUrl"]), 'exicf');
			jQuery("#flvIcfFloat").html(html);
			jQuery("#flvIcfFloat").show();
		}
	}

	var ext_load = 0;
	function icfPlayer(ads_icfs) {
		try {
			jQuery("icf").InitIcfList(ads_icfs);
		} catch (e) {
			if (ext_lode<100) {
				ext_lode++;
				setTimeout(function () {
					icfPlayer(ads_icfs)
				}, 3000);
			}else {
				playerSet.startPlay();
			}
		}
	}
	/* icf(확장, 일반, 쉐이크) 광고 함수들 */

	// 슈퍼밴 닫기 (ray.kim : 2010-09-28)
	function EndFlash() {
		playerSet.startPlay();

		return true;
	}

	/*
	mmn AD 관련 함수 2010-09-09 smith.oh 작업
	웹에서 falsh에 slide 광고를 전달 이후 광고에서 type 값이 8일때 플래시에서 ui함수인 microAdSlide를 호출 해 준다.
	이후 광고 정책은 x버튼을 누르기 전까지 무조건 떠 있다가 x버튼을 누르면 ad 버튼만 남아 있으면 댄다.
	함수명은 일본광고를 먼저 진행을 해서 걍 똑같이 쓰기로 결정
	*/

	var microAdSlide_kind = "";
	function microAdSlide(kind,opt) {
		switch (opt) {
			case "allhide" :
				jQuery("#microAdDiv").hide();
				jQuery("#microAdDiv1").hide();
				jQuery("#microAdDiv").html("");
			break;
			case "hide" :
				jQuery("#microAdDiv").hide();
				jQuery("#microAdDiv1").show();
				//jQuery("#microAdDiv").html("");
				microAdSlide_kind = kind;
			break;
			default : // close();
				kind = microAdSlide_kind ? microAdSlide_kind : kind;
				switch (kind) {
					case "sbs" :
						jQuery("#microAdDiv").html("<table><tr><td align=right width=400><img src=\"http://imgcdn.pandora.tv/ptv_img/icon_network_close.gif\" style=\"cursor:pointer;\" onclick=\"javascript:microAdSlide('sbs','hide');\" /></td></tr><tr><td style=\"text-align:center;\" align=center><iframe scrolling=\"no\" height=\"60\" frameborder=\"0\" width=\"400\" topmargin=\"0\" leftmargin=\"0\" allowtransparency=\"true\" src=\"http://ads1.sbs.co.kr/RealMedia/ads/adstream_sx.ads/www.sbs.co.kr/etc@x72\" marginheight=\"0\" marginwidth=\"0\" style=\"display: inline;\"></iframe></td></tr></table>");
						jQuery("#microAdDiv1").html('<img src="http://imgcdn.pandora.tv/ptv_img/icon_network_ad.gif" onclick="javascript:microAdSlide(\'sbs\');" style="cursor:pointer;" />');
/*
						if (cookieSet.GetCookie('extSet') == "1") {
							jQuery("#microAdDiv").css({"bottom":"70px","left":"200px"});
						}else{
							jQuery("#microAdDiv").css({"bottom":"50px","left":"100px"});
						}
*/
					break;

					case "12" :
						jQuery("#microAdDiv").html("<table><!-- <tr><td align=right width=430><img src=\"http://imgcdn.pandora.tv/ptv_img/icon_network_close.gif\" style=\"cursor:pointer;\" onclick=\"javascript:microAdSlide('micro','hide');\" /></td></tr> --><tr><td style=\"text-align:center;\" align=center><iframe scrolling=\"no\" height=\"70\" frameborder=\"0\" width=\"430\" topmargin=\"0\" leftmargin=\"0\" allowtransparency=\"true\"  src=\"http://ads.realclick.co.kr/ad_photo/pandora3_pt1.html\" marginheight=\"0\" marginwidth=\"0\" style=\"display: inline;\"></iframe></td></tr></table>");
/*
						if (cookieSet.GetCookie('extSet') == "1") {
							jQuery("#microAdDiv").css({"bottom":"70px","left":"210px"});
						}else{
							jQuery("#microAdDiv").css({"bottom":"50px","left":"130px"});
						}
*/
					break;

					case "13" : // about
						var url = '/php/ad_XML_parser.ptv';
						var vData = $.ajax({ url: url, async: false }).responseText;

						jQuery("#microAdDiv").html(vData);
						jQuery("#microAdDiv").css({"bottom":"50px","left":"130px","width":"450px"});
					break;

					case "18" : // 2011-12-26 : dy.bueon
						$("#microAdDiv").html("<table><tr><td align=right width=468><img src=\"http://imgcdn.pandora.tv/ptv_img/icon_network_close.gif\" style=\"cursor:pointer;\" onclick=\"javascript:microAdSlide('18','hide');\" /></td></tr><tr><td style=\"text-align:center;\" align=center><iframe scrolling=\"no\" height=\"60\" frameborder=\"0\" width=\"468\" topmargin=\"0\" leftmargin=\"0\" allowtransparency=\"true\"  src=\"http://channel.pandora.tv/channel/ad_frame.ptv?adtype=misha\" marginheight=\"0\" marginwidth=\"0\" style=\"display: inline;\"></iframe></td></tr></table>");

//						jQuery("#microAdDiv").css({"bottom":"50px","left":"90px","width":"468px"});
					break;

					case "002" : // 2011-12-26 : taylor.baek
						jQuery("#adSkipOverlay").html("<iframe src='http://jp.channel.pandora.tv/ad.overlay.iframe.ptv?id=002' width='468' height='60' scrolling='no' frameborder='0'></" + "iframe>");
						getAdTimeOverlay(1);

//						jQuery("#microAdDiv").css({"bottom":"50px","left":"90px","width":"468px"});
					break;

					case "003" : // 2011-12-26 : taylor.baek
						jQuery("#adSkipOverlay").html("<iframe src='http://jp.channel.pandora.tv/ad.overlay.iframe.ptv?id=003' width='468' height='60' scrolling='no' frameborder='0'></" + "iframe>");
						getAdTimeOverlay(1);

//						jQuery("#microAdDiv").css({"bottom":"50px","left":"90px","width":"468px"});
					break;

					case "004" : // 2011-12-26 : taylor.baek
						jQuery("#adSkipOverlay").html("<iframe src='http://jp.channel.pandora.tv/ad.overlay.iframe.ptv?id=004' width='468' height='60' scrolling='no' frameborder='0'></" + "iframe>");
						getAdTimeOverlay(1);

//						jQuery("#microAdDiv").css({"bottom":"50px","left":"90px","width":"468px"});
					break;

					default :
						/*
						jQuery("#microAdDiv").html("<table style=\"width:100%;\"><tr><td align=right width=234><img src=\"http://imgcdn.pandora.tv/ptv_img/icon_network_close.gif\" style=\"cursor:pointer;\" onclick=\"javascript:microAdSlide('micro','hide');\" /></td></tr><tr><td style=\"text-align:center;\" align=center><iframe scrolling=\"no\" height=\"60\" frameborder=\"0\" width=\"234\" topmargin=\"0\" leftmargin=\"0\" allowtransparency=\"true\"  src=\"http://view.atdmt.com/DKO/iview/257580630/direct/01?click=\" marginheight=\"0\" marginwidth=\"0\" style=\"display: inline;\"><a href=\"http://clk.atdmt.com/DKO/go/257580630/direct/01/\" target=\"_blank\"><img border=\"0\" src=\"http://view.atdmt.com/DKO/view/257580630/direct/01/\" alt=\"\" /></a></iframe></td></tr></table>");
						jQuery("#microAdDiv").css({"top":"270px","left":"220px"});
						*/
					break;
				}

				jQuery("#microAdDiv1").hide();
				jQuery("#microAdDiv").show();
			break;
		}
	}
	////////////////////////////////////////////////////////

	/* 영상 일시 정지 광고 */
	function vodPauseFunc( strV ){
		// strV : play, pause
		var Flag = ( strV == "play" ) ? "none" : "block";
		if( Flag == "block" ){
			if ( ( location.host == "channel1.pandora.tv" || location.host == "channel.pandora.tv" ) && cookieSet.GetCookie('extSet') == "1") {
				jQuery("#pause_banner_Big").css({"top":"100px", "left":"340px"});
			}else{
				jQuery("#pause_banner_Big").css({"top":"20px", "left":"170px"});
			}
			jQuery("#pause_banner").html("<iframe width=\"300\" height=\"250\" src=\"http://channel.pandora.tv/channel_v1/ad_frame.ptv?adtype=pauseAd\" border=\"0\" frameBorder=\"0\" marginWidth=\"0\" marginHeight=\"0\" scrolling=\"no\" allowTransparency=\"\" leftMargin=\"0\" topMargin=\"0\"></iframe>");
		}
		jQuery("#pause_banner_Big").css("display", Flag);
	}
	/* 영상 일시 정지 광고 */

	/* 로그인페이지 광고 함수*/
	var loginAdJson = {};
	function loginAdAction(json) {
		loginAdJson = json;
				jQuery("#new_adsambox01").css("display", "block");
				jQuery("#new_adsambox01").html("<a href=\"" + json["clickUrl"] + "\" target=\"_blank\" ><img src=\"" + json["imgurl"] + "\" border=\"0\"></a>");
	}
	/* 로그인페이지 광고 함수*/
	
	/* 채널 탑 광고 함수 */
	var channelTopAdJson = {};
	function channelTopAdAction(json) {
		channelTopAdJson = json;
				jQuery("#new_adsambox02").css("display", "block");
				jQuery("#new_adsambox02").html("<a href=\"" + json["clickUrl"] + "\" target=\"_blank\" ><img src=\"" + json["imgurl"] + "\" border=\"0\"></a>");
	}
	/* 채널 탑 광고 함수 */

	/* 채널 왼쪽 광고 함수 */
	var channelLeftAdJson = {};
	function channelLeftAdAction(json) {
/*	
		if (cookieSet.GetCookie('channelLeftAd')!="1"){
				channelLeftAdJson = json;
				jQuery("#new_adsambox03").css("display", "block");
				jQuery("#new_adsambox03").html("<a href=\"" + json["clickUrl"] + "\" target=\"_blank\" ><img src=\"" + json["imgurl"] + "\" border=\"0\" style=\"display: block; margin:0; padding;\"></a><a href=\"" + "javascript:channelLeftAdClose()" + "\"  ><img src=\"" + json["imgurl2"] + "\" border=\"0\"></a>");
		}

var channelLeftAdJson = { "kind":"2", "miniurl":"", "exturl":"", "clickUrl":"", "checkUrl":"", "closeTime":"" } document.domain = "pandora.tv"; window.top.channelLeftAdAction(channelLeftAdJson);
*/		

		switch (json["kind"].toString()) {
			case "2" :
				jQuery("#new_adsambox03").html('<iframe name=\"channel_left_ad\" id=\"channel_left_ad\" src=\"http://channel.pandora.tv/channel_v1/ad_channel_left.ptv\" width=\"128\" scrolling=\"no\" height=\"608\" border=\"0\" frameborder=\"0\" margin=\"0\"  marginwidth=\"0\" marginheight=\"0\" vspace=\"0\" hspace=\"0\" allowtransparency=\"true\">');
			break;
		}


	}

	function channelLeftAdClose() {
		var sName ="channelLeftAd";
		var sValue = "1";
		var sDomain = ".pandora.tv";
		var todayDate = new Date();
		todayDate.setDate( todayDate.getDate() + 1 );
		document.cookie = sName + "=" + sValue + ";" +   "expires=" + todayDate.toGMTString() + "domain=" + sDomain + ";path=/;";
		jQuery("#new_adsambox03").css("display", "none");
	}
	/* 채널 왼쪽 광고 함수 */


	////////////////////////////////////////////////////////
	/* 미니 광고 함수 */

	 


	var miniAdJson = {};
	function miniAdAction(json) {
		miniAdJson = json;
		switch (json["kind"].toString()) {
			
			case "2" : // 플래시
				var url = json["miniurl"] + '?clickthru='+ encodeURIComponent(json["clickUrl"]);
				jQuery(".area_ad").css("display", "block");
				jQuery("#cbannerAd").animate({height:"250px"}, 500);
				jQuery("#cbannerAd").css({"width":"300px","height":"250px"});
				jQuery("#cbannerAd").html(playerSet.getAdPlayer(url, 'icf'));
			break;

			case "3" : // 이미지 비확장
				jQuery(".area_ad").css("display", "block");
				jQuery("#cbannerAd").animate({height:"250px"}, 500);
				jQuery("#cbannerAd").css({"width":"300px","height":"250px"});
				jQuery("#cbannerAd").html("<a href=\"" + json["clickUrl"] + "\" target=\"_blank\" onmouseOver=\"miniAdExtStart()\"><img src=\"" + json["miniurl"] + "\" border=\"0\"></a>");
			break;

			case "4" : // 미니ICF
				var url = "http://imgcdn.pandora.tv/gplayer/icf_player_mini.swf?videoURL=" + encodeURIComponent(json["miniurl"]) + '&clickthru='+ encodeURIComponent(json["clickUrl"]);
				url += "&imageURL=" + encodeURIComponent(json["exturl"]) + "&delayTime=" + json['closeTime'];
//				playerSet._playWidth = "300px";
				playerSet._playHeight = "390px";

				jQuery("#cbannerAd").html(playerSet.getAdPlayer(url, 'icf'));
				jQuery("#cbannerAd").css({"display":"block"});
				mini_loadFn();
			break;

			case "6" : // 2011-10-28 : dy.bueon
				jQuery("#cbannerAd").css({"width":"300px","height":"250px"});
				jQuery("#cbannerAd").css({"display":"block"});
				jQuery("#cbannerAd").html("<iframe src='" + json["miniurl"] + "' width='300' height='250' frameborder=0 marginwidth=0 marginheight=0 topmargin=0 scrolling=no align=center></iframe>");
			break;

			case "7" : // 2012-05-10 : dy.bueon ( criteo )
				jQuery("#cbannerAd").css({"width":"300px","height":"250px"});
				jQuery("#cbannerAd").css({"display":"block"});
				jQuery("#cbannerAd").html("<iframe src='" + json["miniurl"] + "' width='300' height='250' frameborder=0 marginwidth=0 marginheight=0 topmargin=0 scrolling=no align=center></iframe>");
			break;


			case "8" :
				var htm_str ="";
				htm_str +="<table width=\"300\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
				htm_str +="  <tr>";
				htm_str +="    <td width=\"300\" height=\"250\" align=\"center\">";
				htm_str +="<object classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" id=\"id_8EE54E97AFF16052699B0012107496\" codebase=\"http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0\" width=\"300\" height=\"250\" align=\"middle\"><param value=\"transparent\" name=\"wmode\" /><param name=\"quality\" value=\"high\" /><param name=\"movie\" value=\""+json["miniurl"]+"\" /><param name=\"allowScriptAccess\" value=\"always\"/><param name=\"allowFullScreen\" value=\"true\"/><embed src=\""+json["miniurl"]+"\" width=\"300\" height=\"250\" id=\"id_8EE54E97AFF16052699B0012107496\" name=\"id_8EE54E97AFF16052699B0012107496\" allowFullScreen=\"true\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\" allowScriptAccess=\"always\"  wmode=\"transparent\" /></object>";
				htm_str +="   </td>";
				htm_str +="  </tr>";
				htm_str +="</table>";
				jQuery("#cbannerAd").html(htm_str);
				jQuery("#cbannerAd").css({"display":"block"});
			break;

			case "9" :
				var htm_str ="";
				htm_str ="<div style='height:250px;'><OBJECT classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" ";
				htm_str +="codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0\" ";
				htm_str +=" WIDTH=\"300\" HEIGHT=\"250\" id=\"mx\" ALIGN=\"\"> ";
				htm_str +="<param name=\"wmode\" value=\"transparent\"/></param> ";
				htm_str +="<PARAM NAME=movie VALUE=\"http://imgcdn.pandora.tv/gplayer/playerROS240.swf?icf_url="+json["miniurl"];
				htm_str +="&click_url="+json["clickUrl"]+"\">";
				htm_str +="<PARAM NAME=quality VALUE=high><PARAM NAME=bgcolor VALUE=#000000> ";
				htm_str +="<param name=\"allowScriptAccess\" value=\"always\"/><EMBED class=\"embed_1\" ";
				htm_str +="src=\"http://imgcdn.pandora.tv/gplayer/playerROS240.swf?icf_url="+json["miniurl"];
				htm_str +="&click_url="+json["clickUrl"]+"\"quality=high wmode=transparent ";
				htm_str +="bgcolor=\"#000000\" NAME=\"mx\" ALIGN=\"\" WIDTH=\"300\" HEIGHT=\"250\" ";
				htm_str +=" TYPE=\"application/x-shockwave-flash\" allowScriptAccess=\"always\" ";
				htm_str +="PLUGINSPAGE=\"http://www.macromedia.com/go/getflashplayer\"></EMBED></OBJECT></div> ";
				htm_str +="<img src=\""+json["checkUrl"]+"\" width=\"0\" height=\"0\" border=\"0\" style=\"display:none\">";
				jQuery("#cbannerAd").html(htm_str);
				jQuery("#cbannerAd").css({"display":"block"});

			break;

			
		}

		try { if (json["checkUrl"]) adCheck(json["checkUrl"]); } catch(e) {}
	}

	var hh = 250;
	var hcnt = 50;
	var i = 1;
	var add = 0;

	function mini_loadFn() {
		if (i * hcnt > hh) { return; }
		add = i * hcnt;
		jQuery("#cbannerAd").css({"height":add});
		i++;
		setTimeout(function() {mini_loadFn();}, 0);
	}


	function miniICF_open(){	// 확장
		miniICF_ViewFn();
	}

	function miniICF_close(){
		miniICF_CloseFn();
	}

	
	function miniICF_ViewFn() {
		var add = hh + hcnt;

		if (add > 390) {jQuery("#cbannerAd").css({"height":390}); document.icf.miniICF_start(); return; }
		jQuery("#cbannerAd").css({"height":add});

		hcnt += 10;
		setTimeout(function() {miniICF_ViewFn();}, 0);
	}

	function miniICF_CloseFn(){
		var add = hh + hcnt;

		if (add < 250) {jQuery("#cbannerAd").css({"height":250}); return; }

		jQuery("#cbannerAd").css({"height":add});

		hcnt -= 10;
		setTimeout(function() {miniICF_CloseFn();}, 0);
	}

	// 미니 확장
	function miniAdExtStart() {
		if (miniAdJson["exturl"]) {
			try { jQuery("#exicf").webMute('0'); } catch(e) {}
			try { jQuery("#flvPlayer").webMute('0'); } catch(e) {}

			var url = miniAdJson["exturl"] + '?clickthru='+ encodeURIComponent(miniAdJson["clickUrl"]);

			jQuery("#cbannerAdExt").css({"width":"300px","height":"390px"});
			jQuery("#cbannerAdExt").html(playerSet.getAdPlayer(url, 'icf'));
			jQuery("#cbannerAdExt").show();

			//setTimeout(function () {
				jQuery("#cbannerAd").hide();
			//}, 1000);
		}
	}
	// 닫기 버튼일 경우
	function miniAdExtEnd() {
		try { jQuery("#exicf").webMute('1'); } catch(e) {}
		try { jQuery("#flvPlayer").webMute('1'); } catch(e) {}

		jQuery("#cbannerAdExt").html("");
		jQuery("#cbannerAdExt").hide();
		jQuery("#cbannerAd").show();
	}
	// 마우스아웃일 경우
	function miniAdOutEnd() {
		if(miniAdJson["closeTime"] > 0) {
			try { jQuery("#exicf").webMute('1'); } catch(e) {}
			try { jQuery("#flvPlayer").webMute('1'); } catch(e) {}
			try {
				setTimeout( function() {
					jQuery("#cbannerAdExt").html("");
					jQuery("#cbannerAdExt").hide();
					jQuery("#cbannerAd").show();
				}, miniAdJson["closeTime"] );
			} catch(e) {}
		}
	}
	/* 미니 광고 함수 */
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	/* ICF Ending Still : 광고 재생 */
	var endingJson = {};
	var setstartStill;
	function endingAction(json) {
		jQuery("#flvIcf").css({"width" : "640px"});

		document.enddingPlayer.endingStart();
	}
	/* ICF Ending Still : 광고 재생 */
	////////////////////////////////////////////////////////

	////////////////////////////////////////////// 일본
	// ICF pause Still : 광고 재생
	function pauseIcfAction( val ) {
		if( val == 'true' ) {
			$(".admov").show();
			$("#endingDiv").show();
			var divTopSize = '20px';
			if( chPalyerExtSet == 'L' ) {
				divTopSize = '80px';
			}

			var flag = Math.floor( (Math.random() * (2 - 1 + 1)) + 1);
			var _url = "";
			if(flag == 1)
				_url = "adType=beniEnding";
			else
				_url = "keycode=1000000269";

			_url = "keycode=1000000269";

			$("#endingDiv").html('<div id="endingDivLayer" style="position:absolute;top:'+divTopSize+';width:100%;"><div style="text-align:center;"><table style="width:100%;" border="2"><tr><td><img src="http://imgcdn.pandora.tv/pan_img/event/k1_img/del.gif" onClick="loginEndingActionHidden();"><IFRAME FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO WIDTH=300 HEIGHT=250 SRC="http://www.pandora.tv/adver.adingo.ptv?'+_url+'"></IFRAME></td></tr></table></div></div>');
		} else {
			loginEndingActionHidden();
		}
		
	}
	
	function loginEndingActionHidden() {
//		$("icfAreaDiv").style.height	= "100%";
//		$("icfAreaDiv").style.display	= "none";
		$(".admov").hide();
		$("#endingDiv").hide();
		$("#endingDiv").html("");
	}

	/* 플래시 생성*/
	function flashHtml(url, objName, type, strWidth, strHeight) {
		var clientLang = chInfoJson['clientLang'];
		strWidth = ( strWidth ) ? strWidth : "100%";
		strHeight = ( strHeight ) ? strHeight : "100%";

		if (!type || type == undefined) {
			furl = url;
		} else {
			furl = "http://imgcdn.pandora.tv/gplayer/icf_player_2.swf?lang=" + clientLang + "&"+url+"&v003";
		}

		if (navigator.userAgent.toLowerCase().indexOf("msie") != -1) {
			var html = '<object name="'+objName+'" id="'+objName+'" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"'
				html+= 'codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="' + strWidth + '" height="' + strHeight + '">'
				html+= '<param name="wmode" value="transparent"></param>'
				html+= '<param name=movie value="' + furl + '"></param>';
				html+= '<param name=quality value=high></param>'
				html+= '<param name=bgcolor value=#FFFFFF></param>';
				html+= '<param name="allowScriptAccess" value="always"></param>';
				html+= '<param name="allowFullScreen" value="true"></param>';
				html+= '</object>';
		} else {
			var html = '<embed src="' + furl + '"';
				html+= 'quality="high" wmode="transparent" bgcolor="#FFFFFF" id="'+objName+'" name="'+objName+'" align="" width="' + strWidth + '" height="' + strHeight + '" type="application/x-shockwave-flash"';
				html+= 'PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer" allowScriptAccess="always" allowFullScreen="true"></embed>';
		}

		return html;
	}
